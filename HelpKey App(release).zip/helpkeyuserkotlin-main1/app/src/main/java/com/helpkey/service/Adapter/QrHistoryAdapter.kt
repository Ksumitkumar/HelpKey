package com.helpkey.service.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.helpkey.service.Models.UserCardPaymentHistoryModel
import com.helpkey.service.databinding.QrHistoryLayoutBinding
import java.util.ArrayList

class QrHistoryAdapter(
    val context: Context,
   val userCardPaymentHistoryModel: ArrayList<UserCardPaymentHistoryModel>
): RecyclerView.Adapter<QrHistoryAdapter.ViewHolder>() {
    inner class ViewHolder(val binding: QrHistoryLayoutBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QrHistoryAdapter.ViewHolder {
        val binding = QrHistoryLayoutBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return  userCardPaymentHistoryModel.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var qrcodeHistory=userCardPaymentHistoryModel[position]
        holder.binding.servicename.setText(qrcodeHistory.servicename)
        holder.binding.cardNo.setText(qrcodeHistory.cardNo)
        holder.binding.address.setText(qrcodeHistory.address)
        holder.binding.totalAmount.setText(qrcodeHistory.totalAmount)
        holder.binding.discount.setText(qrcodeHistory.discount)
        holder.binding.discountedAmount.setText(qrcodeHistory.discountedAmount)
        holder.binding.date.setText(qrcodeHistory.updatedAt)


    }
}