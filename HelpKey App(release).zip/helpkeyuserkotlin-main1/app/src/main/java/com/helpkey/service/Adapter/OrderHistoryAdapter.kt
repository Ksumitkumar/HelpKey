package com.helpkey.service.Adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.helpkey.service.Models.OrderhistoryModel
import com.helpkey.service.UserActivity.FullOrderDetails
import com.helpkey.service.databinding.OrderLayoutBinding

class OrderHistoryAdapter(val list: ArrayList<OrderhistoryModel>, val context: Context) :
    RecyclerView.Adapter<OrderHistoryAdapter.ViewHoder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHoder {
        val view = OrderLayoutBinding.inflate(LayoutInflater.from(context), parent, false)
        return ViewHoder(view)

    }

    override fun onBindViewHolder(holder: ViewHoder, position: Int) {

        holder.binding.orderId.text = list[position].order_no
        holder.binding.orderTime.text = list[position].order_date
        holder.itemView.setOnClickListener {
            var intent = Intent(context, FullOrderDetails::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            intent.putExtra("orderid",list[position].id.toString())
            intent.putExtra("mobile",list[position].mobile.toString())
            context.startActivity(intent)
            Log.e("orderid", list[position].order_no.toString())

        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class ViewHoder(var binding: OrderLayoutBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}