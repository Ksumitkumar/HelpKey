package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class DeleteServiceModel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("user_id")
    @Expose
    var userId: String? = null

    @SerializedName("vendorservice_id")
    @Expose
    var vendorserviceId: String? = null

    @SerializedName("servicename")
    @Expose
    var servicename: String? = null

    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null

    @SerializedName("coverimage")
    @Expose
    var coverimage: String? = null

    /**
     * No args constructor for use in serialization
     *
     */
    constructor() {}

    /**
     *
     * @param createdAt
     * @param servicename
     * @param vendorserviceId
     * @param id
     * @param userId
     * @param status
     * @param updatedAt
     * @param coverimage
     */
    constructor(
        id: Int?,
        userId: String?,
        vendorserviceId: String?,
        servicename: String?,
        status: String?,
        createdAt: String?,
        updatedAt: String?,
        coverimage: String?
    ) : super() {
        this.id = id
        this.userId = userId
        this.vendorserviceId = vendorserviceId
        this.servicename = servicename
        this.status = status
        this.createdAt = createdAt
        this.updatedAt = updatedAt
        this.coverimage = coverimage
    }
}