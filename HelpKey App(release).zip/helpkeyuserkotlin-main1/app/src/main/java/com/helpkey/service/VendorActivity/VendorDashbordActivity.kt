package com.helpkey.service.VendorActivity

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.squareup.picasso.Picasso
import com.helpkey.service.Adapter.VendorserviceAdapter
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.Refresh
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.VendorAllOrderRequestModel
import com.helpkey.service.R
import com.helpkey.service.UserActivity.AboutWebviewActivity
import com.helpkey.service.UserActivity.CategoryviewallActivity
import com.helpkey.service.UserActivity.ProfileActivity
import com.helpkey.service.UserActivity.SelectuserTypeActivity
import com.helpkey.service.databinding.ActivityVendorDashbordBinding
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import kotlin.collections.ArrayList

class VendorDashbordActivity : AppCompatActivity(),Refresh {

    lateinit var binding: ActivityVendorDashbordBinding

    var prefrenceManager: PrefrenceManger1? = null
    private var fusedLocationClient: FusedLocationProviderClient? = null
    private var lastLocation: Location? = null
    private val TAG = "LocationProvider"
    private val REQUEST_PERMISSIONS_REQUEST_CODE = 34
    var vendorAllOrderRequestModel1: ArrayList<VendorAllOrderRequestModel> =
        ArrayList()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVendorDashbordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefrenceManager = PrefrenceManger1(applicationContext)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)



        profile_view()
//        poppup()
        venderservices()
        Vendorcompleteorderservices()
        VendorUncompleteOrderServices()
        vendorCancelService()
        venderPendinngServices()

        if (!checkPermissions()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions()
            }
        } else {
            getLastLocation()
        }

        binding.vendorhomelayou.vendorSwipe.setOnRefreshListener(SwipeRefreshLayout.OnRefreshListener {
            profile_view()
//        poppup()
            venderservices()
            Vendorcompleteorderservices()
            VendorUncompleteOrderServices()
            vendorCancelService()
            venderPendinngServices()

            if (!checkPermissions()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions()
                }
            } else {
                getLastLocation()
            }
        })

        binding.vendorhomelayou.opendrawer.setOnClickListener(View.OnClickListener {
            binding.drawerLayout.openDrawer(GravityCompat.START)
        })


        binding.vendorhomelayou.todayorder.setOnClickListener {
            Constracter.manegestatus = "0"
            val intent = Intent(this, VendorTodayOrderActivity::class.java)
            startActivity(intent)
        }

        binding.vendorhomelayou.prductItem.setOnClickListener {
            Constracter.manegestatus = "0"
            val inten = Intent(this, Product_itemActivity::class.java)
            inten.putExtra("VendordashAddress", "completeServices")
            startActivity(inten)
        }

        binding.vendorhomelayou.soldItem.setOnClickListener {
            Constracter.manegestatus = "1"
            val inten = Intent(this, Product_itemActivity::class.java)
            inten.putExtra("VendordashAddress", "uncomplete")
            startActivity(inten)
        }

        binding.vendorhomelayou.allorderrecived.setOnClickListener {
            Constracter.manegestatus = "0"
            val inten = Intent(this, Product_itemActivity::class.java)
            inten.putExtra("VendordashAddress", "allServices")
            startActivity(inten)
        }

        binding.layoutNavbar.myservice.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this, VendorServicesActivity::class.java)
            intent.putExtra("type", "2")
            startActivity(intent)
        }

        binding.layoutNavbar.mypoint.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this, VendorServicesActivity::class.java)
            intent.putExtra("type", "1")
            startActivity(intent)
        }

        binding.layoutNavbar.qrScanner.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this, QrscannerActivity::class.java)
            startActivity(intent)
        }
        binding.vendorhomelayou.viewAll.setOnClickListener {
            Constracter.manegestatus = "0"
            val intent = Intent(this, ViewAllActivity::class.java)
            startActivity(intent)

        }

        binding.layoutNavbar.profile.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this, ProfileActivity::class.java)
            intent.putExtra("address", "vendor")
            startActivity(intent)
        }
        binding.layoutNavbar.logout.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            LogoutDialog()
        }

        binding.layoutNavbar.myOrder.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this, VendorTodayOrderActivity::class.java)
            startActivity(intent)
        }


        binding.layoutNavbar.addHelpkeypoint.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this, AddServiceActivity::class.java)
            intent.putExtra("serviceUpdate", "1")
            intent.putExtra("cat_id", "1")
            startActivity(intent)
        }

        binding.layoutNavbar.addHelpkeyservice.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this, AddServiceActivity::class.java)
            intent.putExtra("serviceUpdate", "2")
            intent.putExtra("cat_id", "2")
            startActivity(intent)
        }

        binding.layoutNavbar.payHelpkey.setOnClickListener {
            startActivity(Intent(this@VendorDashbordActivity,PayHelpkeyActivity::class.java))
        }

        binding.layoutNavbar.help.setOnClickListener {
            var intent = Intent(this@VendorDashbordActivity, CategoryviewallActivity::class.java)
            intent.putExtra("address", "help")
            startActivity(intent)
        }

        binding.layoutNavbar.about.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this@VendorDashbordActivity, AboutWebviewActivity::class.java)
            startActivity(intent)
        }


    }

    private fun LogoutDialog() {
        val builder = AlertDialog.Builder(this)
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView: View =
            LayoutInflater.from(applicationContext).inflate(R.layout.exitdialog, viewGroup, false)
        builder.setView(dialogView)
        builder.setCancelable(true)
        val alertDialog = builder.create()
        ((alertDialog.window ?: return).attributes ?: return).gravity = Gravity.BOTTOM
        val exit = dialogView.findViewById<Button>(R.id.exit)
        val logout = dialogView.findViewById<Button>(R.id.logoutbtn)
        val logoutNo=dialogView.findViewById<Button>(R.id.logoutNobtn)
        val txt = dialogView.findViewById<TextView>(R.id.txt)
        exit.visibility = View.GONE

        logout.visibility=View.VISIBLE
        logoutNo.setOnClickListener {
            alertDialog.dismiss()
        }

        txt.text = "Are you sure to want to logout from this app?"

        logout.setOnClickListener {
            alertDialog.dismiss()
            (prefrenceManager ?: return@setOnClickListener).clearSharedPreference()
            var intent = Intent(this@VendorDashbordActivity, SelectuserTypeActivity::class.java)
            startActivity(intent)
            super.onBackPressed()
            finishAffinity()
        }
        alertDialog.show()
    }

    private fun poppup() {
        val builder = AlertDialog.Builder(this)
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView: View =
            LayoutInflater.from(applicationContext)
                .inflate(R.layout.welcome_aleartdialog, viewGroup, false)
        builder.setView(dialogView)
        builder.setCancelable(true)
        val alertDialog = builder.create()
        val oky = dialogView.findViewById<Button>(R.id.oky)

        oky.setOnClickListener {
            alertDialog.dismiss()
        }
        alertDialog.show()
    }

    override fun onBackPressed() {
        binding.drawerLayout.closeDrawer(GravityCompat.START)
        exitshowDialog()
    }

    private fun exitshowDialog() {
        val builder = AlertDialog.Builder(this)
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView: View = LayoutInflater.from(applicationContext)
            .inflate(R.layout.exitdialog, viewGroup, false)
        builder.setView(dialogView)
        builder.setCancelable(true)
        val alertDialog = builder.create()
        val exit = dialogView.findViewById<Button>(R.id.exit)
        val logout = dialogView.findViewById<Button>(R.id.logoutbtn)
        val logoutNo = dialogView.findViewById<Button>(R.id.logoutNobtn)
        logout.visibility = View.VISIBLE
        logoutNo.setOnClickListener {
            alertDialog.dismiss()
        }

        logout.setOnClickListener {
            alertDialog.dismiss()
            super.onBackPressed()
            val a = Intent(Intent.ACTION_MAIN)
            a.addCategory(Intent.CATEGORY_HOME)
            a.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(a)
            finishAffinity()
        }
        alertDialog.show()
    }

    fun profile_view() {
        val getDataServices: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataServices.view_profile(
            prefrenceManager?.getUserid(applicationContext)
        )
        Log.e("vendoruserid", prefrenceManager?.getUserid(applicationContext).toString())
        call.enqueue(object : Callback<JsonArray> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e("vendorprofile_response", jsonArray.toString())
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.vendorhomelayou.vendorSwipe.isRefreshing = false
                        val jsonArray1 = jsonObject.getJSONObject("data")
                        binding.layoutNavbar.VendorName.text = jsonArray1.getString("username")
                        binding.layoutNavbar.VendorEmail.text = jsonArray1.getString("email")
                        prefrenceManager?.setName(
                            jsonArray1.getString("username"),
                            applicationContext
                        )
                        prefrenceManager?.setemail(
                            jsonArray1.getString("email"),
                            applicationContext
                        )

                        Picasso.get()
                            .load(
                                "https://panels.helpkey.in/public/images/profileImage/" + jsonArray1.getString(
                                    "image"
                                )
                            )
                            .into(binding.layoutNavbar.profileImage)
//                        binding.navbar.qrCode.visibility = View.VISIBLE
//                        binding.navbar.view1.visibility = View.VISIBLE

                    } else {

                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("vendorprofile_error", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("vendorprofile_error", t.toString())

            }

        })

    }

    fun venderservices() {
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.VendorOrderRequest(
                prefrenceManager?.getUserid(applicationContext)
            )

        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                binding.vendorhomelayou.vendorSwipe.isRefreshing = false
                try {
                    Log.e("Vallrequest_response", response.body().toString())

                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.vendorhomelayou.vendorSwipe.isRefreshing = false
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Log.e("Vallrequest", jsonObject.toString())
                        var vendorAllOrderRequestModel: ArrayList<VendorAllOrderRequestModel> =
                            ArrayList()
                        vendorAllOrderRequestModel.clear()
                        for (i in 0 until jsonArray1.length()) {
                            val vendarSModel: VendorAllOrderRequestModel = Gson().fromJson(
                                jsonArray1.getString(i).toString(),
                                VendorAllOrderRequestModel::class.java
                            )
                            vendorAllOrderRequestModel.add(vendarSModel)


                        }
                        binding.vendorhomelayou.newRequest.text =
                            vendorAllOrderRequestModel.size.toString()

                        Log.e("servicecount1", vendorAllOrderRequestModel.size.toString())

                    } else {


                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("Vallrequest_ex", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("Vallrequest_error", t.toString())
            }
        })
    }

    fun Vendorcompleteorderservices() {
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.Vendorcompleteorderservices(
                prefrenceManager?.getUserid(applicationContext).toString()

            )

        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                binding.vendorhomelayou.vendorSwipe.isRefreshing = false
                try {
                    Log.e("Vallrequest_response", response.body().toString())

                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.vendorhomelayou.vendorSwipe.isRefreshing = false
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Log.e("Vallrequest", jsonObject.toString())
                        var vendorAllOrderRequestModel: ArrayList<VendorAllOrderRequestModel> =
                            ArrayList()
                        vendorAllOrderRequestModel.clear()
                        for (i in 0 until jsonArray1.length()) {
                            val vendarSModel: VendorAllOrderRequestModel = Gson().fromJson(
                                jsonArray1.getString(i).toString(),
                                VendorAllOrderRequestModel::class.java
                            )
                            vendorAllOrderRequestModel.add(vendarSModel)


                        }
                        binding.vendorhomelayou.completeService.text =
                            vendorAllOrderRequestModel.size.toString()

                        Log.e("servicecount1", vendorAllOrderRequestModel.size.toString())

                    } else {


                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("Vallrequest_ex", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("Vallrequest_error", t.toString())
            }
        })
    }

    fun VendorUncompleteOrderServices() {
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.VendorUncompleteOrderServices(
                prefrenceManager?.getUserid(applicationContext).toString()
            )

        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e("Vallrequest_response", response.body().toString())
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.vendorhomelayou.vendorSwipe.isRefreshing = false
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Log.e("Vallrequest", jsonObject.toString())
                        var vendorAllOrderRequestModel: ArrayList<VendorAllOrderRequestModel> =
                            ArrayList()
                        vendorAllOrderRequestModel.clear()
                        for (i in 0 until jsonArray1.length()) {
                            val vendarSModel: VendorAllOrderRequestModel = Gson().fromJson(
                                jsonArray1.getString(i).toString(),
                                VendorAllOrderRequestModel::class.java
                            )
                            vendorAllOrderRequestModel.add(vendarSModel)


                        }
                        binding.vendorhomelayou.Uncompleted.text =
                            vendorAllOrderRequestModel.size.toString()

                        Log.e("servicecount1", vendorAllOrderRequestModel.size.toString())

                    } else {

                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("Vallrequest_ex", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("Vallrequest_error", t.toString())
            }
        })
    }

    fun vendorCancelService() {
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.vendorcancelService(
                prefrenceManager?.getUserid(applicationContext).toString()

            )

        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e("Vallrequest_response", response.body().toString())

                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.vendorhomelayou.vendorSwipe.isRefreshing = false
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Log.e("Vallrequest", jsonObject.toString())
                        var vendorAllOrderRequestModel: ArrayList<VendorAllOrderRequestModel> =
                            ArrayList()
                        vendorAllOrderRequestModel.clear()
                        for (i in 0 until jsonArray1.length()) {
                            val vendarSModel: VendorAllOrderRequestModel = Gson().fromJson(
                                jsonArray1.getString(i).toString(),
                                VendorAllOrderRequestModel::class.java
                            )
                            vendorAllOrderRequestModel.add(vendarSModel)


                        }
                        binding.vendorhomelayou.cancelService.text =
                            vendorAllOrderRequestModel.size.toString()

                        Log.e("servicecount1", vendorAllOrderRequestModel.size.toString())

                    } else {


                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("Vallrequest_ex", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("Vallrequest_error", t.toString())
            }
        })
    }

    fun venderPendinngServices() {
        vendorAllOrderRequestModel1.clear()
        binding.vendorhomelayou.empaty.visibility = View.GONE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.vendorUncompleteService(
                prefrenceManager?.getUserid(applicationContext)
            )

        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e("Vallrequest_response", response.body().toString())

                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.vendorhomelayou.vendorSwipe.isRefreshing = false
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Log.e("Vallrequest", jsonObject.toString())
                        for (i in 0 until jsonArray1.length()) {
                            val vendarSModel: VendorAllOrderRequestModel = Gson().fromJson(
                                jsonArray1.getString(i).toString(),
                                VendorAllOrderRequestModel::class.java
                            )
                            vendorAllOrderRequestModel1.add(vendarSModel)

                        }

                        val adpter3 =
                            VendorserviceAdapter(vendorAllOrderRequestModel1, applicationContext)
                        val layoutManager = LinearLayoutManager(applicationContext)
                        layoutManager.orientation = LinearLayoutManager.VERTICAL
                        binding.vendorhomelayou.vendorserviceRecylview.layoutManager = layoutManager
                        binding.vendorhomelayou.vendorserviceRecylview.setHasFixedSize(true)
                        binding.vendorhomelayou.vendorserviceRecylview.adapter = adpter3

                    } else {
                        binding.vendorhomelayou.empaty.visibility = View.VISIBLE
                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("Vallrequest_ex", e.toString())
                    binding.vendorhomelayou.empaty.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("Vallrequest_error", t.toString())
                binding.vendorhomelayou.empaty.visibility = View.VISIBLE
            }
        })
    }

    private fun getLastLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        fusedLocationClient?.lastLocation!!.addOnCompleteListener(this) { task ->
            if (task.isSuccessful && task.result != null) {
                lastLocation = task.result
                Log.e("fdkj", (lastLocation)!!.latitude.toString())
                Log.e("fdkj", (lastLocation)!!.longitude.toString())
                Constracter.lat = (lastLocation)!!.latitude.toString()
                Constracter.log = (lastLocation)!!.longitude.toString()
                binding.vendorhomelayou.vendorSwipe.isRefreshing = false
                try {
                    val geocoder = Geocoder(this, Locale.getDefault())
                    val list: List<Address> =
                        geocoder.getFromLocation(
                            (lastLocation)!!.latitude,
                            (lastLocation)!!.longitude,
                            1
                        )!!
                    binding.apply {
                        Log.e("jfks", list[0].getAddressLine(0))

                        binding.vendorhomelayou.dil.text = list[0].getAddressLine(0)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("loaction_error",e.toString())
                }

            } else {
                Log.w(TAG, "getLastLocation:exception", task.exception)
                //showMessage("No location detected. Make sure location is enabled on the device.")
            }
        }
    }

    private fun showSnackbar(
        mainTextStringId: String, actionStringId: String,
        listener: View.OnClickListener
    ) {
        Toast.makeText(this@VendorDashbordActivity, mainTextStringId, Toast.LENGTH_LONG).show()
    }

    private fun checkPermissions(): Boolean {
        val permissionState = ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        return permissionState == PackageManager.PERMISSION_GRANTED
    }

    private fun startLocationPermissionRequest() {
        ActivityCompat.requestPermissions(
            this@VendorDashbordActivity,
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION),
            REQUEST_PERMISSIONS_REQUEST_CODE
        )
    }

    private fun requestPermissions() {
        val shouldProvideRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (shouldProvideRationale) {
            Log.i(TAG, "Displaying permission rationale to provide additional context.")
            showSnackbar("Location permission is needed for core functionality", "Okay",
                View.OnClickListener {
                    startLocationPermissionRequest()
                })
        } else {
            Log.i(TAG, "Requesting permission")
            startLocationPermissionRequest()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Log.i(TAG, "onRequestPermissionResult")
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            when {
                grantResults.isEmpty() -> {
                    Log.i(TAG, "User interaction was cancelled.")
                }
                grantResults[0] == PackageManager.PERMISSION_GRANTED -> {
                    getLastLocation()
                }
                else -> {
                    showSnackbar("Permission was denied", "Settings",
                        View.OnClickListener {
                            val intent = Intent()
                            intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                            val uri = Uri.fromParts(
                                "package",
                                Build.DISPLAY, null
                            )
                            intent.data = uri
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                        }
                    )
                }
            }
        }
    }

    override fun onRestart() {
        super.onRestart()
        profile_view()
        venderservices()
        Vendorcompleteorderservices()
        VendorUncompleteOrderServices()
        vendorCancelService()
        venderPendinngServices()
        getLastLocation()
    }

    override fun refresh() {

    }
}