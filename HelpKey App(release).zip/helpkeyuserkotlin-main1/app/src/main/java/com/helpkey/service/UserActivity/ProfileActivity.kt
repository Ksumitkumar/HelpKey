package com.helpkey.service.UserActivity

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.squareup.picasso.Picasso
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityProfileBinding
import org.json.JSONArray
import org.json.JSONException
import retrofit2.Call
import retrofit2.Response

class ProfileActivity : AppCompatActivity() {
    lateinit var binding: ActivityProfileBinding
    var prefrenceManager: PrefrenceManger1? = null
    var address = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefrenceManager = PrefrenceManger1(applicationContext)
        address = intent.getStringExtra("address").toString()
        binding.number.text = buildString {
            append("+91 ")
            append(prefrenceManager?.getmobilno(applicationContext))
        }

        binding.back.setOnClickListener {
            finish()
        }
        binding.edite.setOnClickListener {
            var intent = Intent(this@ProfileActivity, EditeActivity::class.java)
            intent.putExtra("address", address)
            startActivity(intent)
        }
        profile_view()
    }

    fun profile_view() {
        val getDataServices: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataServices.view_profile(
            prefrenceManager?.getUserid(applicationContext)
        )
        Log.e("userid", prefrenceManager?.getUserid(applicationContext).toString())
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e(
                        "profile_response",
                        jsonArray.toString() + " " + call.request().url().toString())
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonArray1 = jsonObject.getJSONObject("data")
                        binding.email.text = jsonArray1.getString("email")
                        binding.number.text = "+91 " + jsonArray1.getString("mobile")
                        binding.name.text = jsonArray1.getString("username")
                        binding.address.text =
                            jsonArray1.getString("address") + ", " + jsonArray1.getString("city") + ", " + jsonArray1.getString(
                                "pin_code"
                            ) + ", " + jsonArray1.getString("state") + ", " + jsonArray1.getString("country")
                        Picasso.get()
                            .load(
                                "https://panels.helpkey.in/public/images/profileImage/" + jsonArray1.optString(
                                    "image"
                                ))
                            .placeholder(R.drawable.ic_baseline_person_24)
                            .into(binding.profileImage)
                        binding.shimmerViewContainer.hideShimmer()
                    } else {
                        binding.shimmerViewContainer.hideShimmer()

                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("profile_error", e.toString())
                    binding.shimmerViewContainer.hideShimmer()
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("profile_error", t.toString())
                binding.shimmerViewContainer.hideShimmer()
            }
        })
    }
    override fun onRestart() {
        super.onRestart()
        profile_view()
    }
    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}