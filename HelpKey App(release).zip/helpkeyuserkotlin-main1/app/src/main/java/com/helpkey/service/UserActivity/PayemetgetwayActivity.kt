package com.helpkey.service.UserActivity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.razorpay.Checkout
import com.razorpay.PaymentData
import com.razorpay.PaymentResultWithDataListener
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.R
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response

class PayemetgetwayActivity : AppCompatActivity(), PaymentResultWithDataListener {

    val TAG: String = VerchualcardPaymentActivity::class.toString()
    var orderid = ""
    var prefrenceManager: PrefrenceManger1? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payemetgetway)
        orderid = intent.getStringExtra("orderid").toString()

        prefrenceManager = PrefrenceManger1(applicationContext)


        Checkout.preload(applicationContext)


        startPayment()


    }

    private fun startPayment() {

        val co = Checkout()

        try {
            val options = JSONObject()
            options.put("name", "HelpKey App")
            options.put("description", prefrenceManager?.getName(applicationContext))
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png")
            options.put("theme.color", "#3399cc")
            options.put("currency", "INR")
            options.put(
                "amount",
                intent.getStringExtra("price") + "00"
            )//pass amount in currency subunits
            val prefill = JSONObject()
            prefill.put("email", prefrenceManager?.getemail(applicationContext))
            prefill.put("contact", prefrenceManager?.getmobilno(applicationContext))
            options.put("prefill", prefill)
            co.open(this@PayemetgetwayActivity, options)
            Log.e("opstion", options.toString())
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("exception_err", e.toString())
        }
    }

    override fun onPaymentSuccess(razorpayPaymentID: String?, paymentData: PaymentData?) {

        if (paymentData != null) {
            try {
                Log.e(
                    "successPayment_res",
                    paymentData.paymentId + paymentData.data + paymentData.signature
                )
                order_success(razorpayPaymentID.toString())
            } catch (e: Exception) {
                Log.e("successPayment_exe", e.toString())
            }
        }
    }

    override fun onPaymentError(p0: Int, p1: String?, paymentData: PaymentData?) {
        Log.e("successError_exe", "${paymentData.toString()} $p0 ${p1.toString()}")
    }


    fun order_success(txn_id: String) {
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataService.order_update_pay(
            prefrenceManager?.getUserid(applicationContext),
            orderid,
            "PayU Online",
            txn_id
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {

                try {
                    // Log.e("book_res", response.body().toString()+" "+PaymentMethod+" "+totalamount)
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val intent =
                            Intent(this@PayemetgetwayActivity, ThankyouActivity::class.java)
                        intent.putExtra("orderid", orderid)
                        intent.putExtra("book", "product")
                        startActivity(intent)
                    } else {
                        val intent =
                            Intent(this@PayemetgetwayActivity, CartActivity::class.java)
                        startActivity(intent)
                    }


                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("book_ex", e.toString())

                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("book_res", t.toString())

            }
        })
    }
}