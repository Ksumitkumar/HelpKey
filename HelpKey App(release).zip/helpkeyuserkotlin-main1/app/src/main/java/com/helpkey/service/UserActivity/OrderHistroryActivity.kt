package com.helpkey.service.UserActivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.helpkey.service.Adapter.OrderHistoryAdapter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.OrderhistoryModel
import com.helpkey.service.databinding.ActivityOrderHistroryBinding
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response

class OrderHistroryActivity : AppCompatActivity() {

    lateinit var binding: ActivityOrderHistroryBinding
    var prefrenceManager: PrefrenceManger1? = null
    val orderhistoryModels: ArrayList<OrderhistoryModel> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefrenceManager = PrefrenceManger1(applicationContext)
        binding = ActivityOrderHistroryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.back.setOnClickListener {
            finish()
        }
        orderHistory()

    }


    fun orderHistory() {
        binding.shimmerViewContainer.startShimmer()
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.order_details(
                prefrenceManager?.getUserid(applicationContext)
            )
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("hist_res", response.body().toString())
                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progressBar.visibility = View.GONE
                        binding.shimmerViewContainer.hideShimmer()
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        for (i in 0 until jsonArray1.length()) {
                            val cardOrderHistory: OrderhistoryModel = Gson().fromJson(
                                jsonArray1.getString(i).toString(),
                                OrderhistoryModel::class.java
                            )
                            orderhistoryModels.add(cardOrderHistory)
                        }

                    } else {
                        binding.progressBar.visibility = View.GONE
                        binding.empaty.visibility = View.VISIBLE

                    }
                    val orderHistory = OrderHistoryAdapter(orderhistoryModels, applicationContext)
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.recylviewOrder.layoutManager = layoutManager
                    binding.recylviewOrder.setHasFixedSize(true)
                    binding.recylviewOrder.adapter = orderHistory

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("hist_ex", e.toString())
                    binding.progressBar.visibility = View.GONE


                }
            }


            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("hist_error", t.toString())
                binding.progressBar.visibility = View.GONE

            }

        })
    }
}