package com.helpkey.service.UserActivity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Paint
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.squareup.picasso.Picasso
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityProductFulldetailsBinding
import org.json.JSONArray
import retrofit2.Call
import retrofit2.Response


class ProductFulldetailsActivity : AppCompatActivity() {
    lateinit var binding: ActivityProductFulldetailsBinding
    var serviceid = ""
    var prefrenceManager: PrefrenceManger1? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityProductFulldetailsBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        prefrenceManager = PrefrenceManger1(this@ProductFulldetailsActivity)

        binding.back.setOnClickListener { finish() }

        serviceid = intent.getStringExtra("id").toString()
        binding.productName.text = intent.getStringExtra("productname")
        binding.discount.text = intent.getStringExtra("discount")
        binding.price.text = buildString {
            append("Rs. ")
            append(intent.getStringExtra("price"))
        }
        binding.number.text = buildString {
            append("+91 ")
            append(intent.getStringExtra("mobile"))
        }
        binding.number.paintFlags = binding.number.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        binding.address.text = intent.getStringExtra("address")
        binding.description.text = intent.getStringExtra("description")
        Picasso.get()
            .load("https://panels.helpkey.in/public/images/serviceimage/" + intent.getStringExtra("img"))
            .placeholder(R.drawable.logo)
            .into(binding.productImage)

        binding.number.setOnClickListener {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CALL_PHONE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CALL_PHONE),
                    100
                )
            } else {
                val intent = Intent(
                    Intent.ACTION_DIAL,
                    Uri.fromParts("tel", binding.number.text.toString(), null)
                )
                startActivity(intent)
            }
        }
        binding.addBookNow.setOnClickListener {
            add_cart(serviceid)
        }
    }

    fun add_cart(service_id: String) {
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataService.add_to_cart(
            prefrenceManager?.getUserid(this@ProductFulldetailsActivity),
            service_id
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e(
                    "addcart_res",
                    response.body()
                        .toString() + "  " + prefrenceManager?.getUserid(this@ProductFulldetailsActivity) + " " + service_id
                )
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val intent =
                            Intent(this@ProductFulldetailsActivity, CartActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        startActivity(intent)

                    } else {
                        Toast.makeText(
                            this@ProductFulldetailsActivity,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: Exception) {
                    Log.e("addcart_error", e.toString())
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("addcart_error", t.toString())
            }

        })

    }
}