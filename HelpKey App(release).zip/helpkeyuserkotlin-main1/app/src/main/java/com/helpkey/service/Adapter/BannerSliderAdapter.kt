package com.helpkey.service.Adapter

import BannersModel
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.viewpager.widget.PagerAdapter
import com.squareup.picasso.Picasso
import com.helpkey.service.R


class BannerSliderAdapter(var list: List<BannersModel>, var context: Context) : PagerAdapter() {

    lateinit var layoutInflater: LayoutInflater

    override fun getCount(): Int {
        return list.size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view == `object`

    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        layoutInflater = LayoutInflater.from(context)
        val view = layoutInflater.inflate(R.layout.item, container, false)
        val img = view.findViewById<ImageView>(R.id.card_logo)
        Picasso.get().load("http://panels.helpkey.in/images/banner/"+ list[position].image).into(img)
        container.addView(view, 0)
        return view
    }


    @Deprecated("Deprecated in Java")
    override fun destroyItem(container: View, position: Int, `object`: Any) {


    }


}