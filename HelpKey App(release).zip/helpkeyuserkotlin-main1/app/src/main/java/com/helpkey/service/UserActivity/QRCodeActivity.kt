package com.helpkey.service.UserActivity

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.squareup.picasso.Picasso
import com.helpkey.service.Adapter.QrHistoryAdapter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.UserCardPaymentHistoryModel
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityOrcodeBinding
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.util.ArrayList


class QRCodeActivity : AppCompatActivity() {
    var userCardPaymentHistoryModel: ArrayList<UserCardPaymentHistoryModel> = ArrayList()
    lateinit var binding: ActivityOrcodeBinding
    var prefrenceManager: PrefrenceManger1? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrcodeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefrenceManager = PrefrenceManger1(applicationContext)

        binding.back.title = "My QR Code"
        binding.back.setNavigationOnClickListener {
            if (binding.qrLayout.isVisible) {
                finish()
            } else {
                binding.back.title = "My QR Code"
                binding.qrLayout.visibility = View.VISIBLE
                binding.qrHistory.visibility = View.GONE
            }
        }
        binding.name.text = prefrenceManager?.getName(applicationContext)
        binding.email.text = prefrenceManager?.getemail(applicationContext)

        binding.history.setOnClickListener {
            if (binding.qrLayout.isVisible) {
                binding.back.title = "History"
                binding.qrLayout.visibility = View.GONE
                binding.qrHistory.visibility = View.VISIBLE
                qrHistory()
            }
        }
        profileCheck()
    }

    private fun profileView() {
        binding.progressBar.visibility = View.VISIBLE
        val getDataServices: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataServices.view_profile(
            prefrenceManager?.getUserid(applicationContext)
        )
        Log.e("userid", prefrenceManager?.getUserid(applicationContext).toString())
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e("profile_response", jsonArray.toString())
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progressBar.visibility = View.GONE
                        val jsonArray1 = jsonObject.getJSONObject("data")
                        binding.name.text = jsonArray1.optString("username")
                        binding.email.text = jsonArray1.optString("email")

                        Picasso.get()
                            .load(
                                "https://panels.helpkey.in/public/images/profileImage/" + jsonArray1.optString(
                                    "image"
                                )
                            ).placeholder(R.drawable.ic_baseline_person_24)
                            .into(binding.profileImage)
                        val qrCodeWriter = QRCodeWriter()
                        try {
                            val bitMatrix =
                                qrCodeWriter.encode(
                                    "https://panels.helpkey.in/user_cart/${prefrenceManager?.getUserid(this@QRCodeActivity)}/profile", BarcodeFormat.QR_CODE, 200, 200
                                )
                            val bitmap = Bitmap.createBitmap(200, 200, Bitmap.Config.RGB_565)
                            for (x in 0..199) {
                                for (y in 0..199) {
                                    bitmap.setPixel(
                                        x,
                                        y,
                                        if (bitMatrix[x, y]) Color.BLACK else Color.WHITE
                                    )
                                }
                            }
                            binding.qrImg.setImageBitmap(bitmap)
                        } catch (e: Exception) {
                            binding.progressBar.visibility = View.GONE
                            e.printStackTrace()
                        }

                    } else {
                        binding.progressBar.visibility = View.GONE
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    binding.progressBar.visibility = View.GONE
                    Log.e("profile_error", e.toString())
                    Toast.makeText(this@QRCodeActivity, "Please Update Profile", Toast.LENGTH_SHORT)
                        .show()
                    if (e.toString() == "org.json.JSONException: No value for username") {
                        showDialog()
                    }
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("profile_error", t.toString())
                binding.progressBar.visibility = View.GONE
            }

        })

    }

    private fun profileCheck() {
        val getDataServices: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataServices.verify_profile(
            prefrenceManager?.getUserid(applicationContext)
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e("chek_response", jsonArray.toString())
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        if (jsonObject.getString("message") == "User profile update") {
                            profileView()
                        } else {
                            profileView()
//                            showDialog()
                        }
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("chek_error", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("check_error", t.toString())
            }
        })

    }

    private fun qrHistory() {
        userCardPaymentHistoryModel.clear()
      binding.empaty.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.vendorqrCodetransationhistory(prefrenceManager?.getUserid(applicationContext))
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("History_res", response.body().toString())
                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progressBar.visibility = View.GONE
                        val jsonArray = jsonObject.getJSONArray("data")
                        Log.e("data", jsonArray.toString())
                        if (jsonArray.length() > 0) {
                            for (i in 0 until jsonArray.length()) {
                                val history: UserCardPaymentHistoryModel = Gson().fromJson(
                                    jsonArray.getString(i).toString(),
                                    UserCardPaymentHistoryModel::class.java
                                )
                                userCardPaymentHistoryModel.add(history)
                            }
                        } else {
                            binding.progressBar.visibility = View.GONE
                            binding.empaty.visibility = View.VISIBLE
                        }
                    } else {
                        binding.progressBar.visibility = View.GONE
                      binding.empaty.visibility = View.VISIBLE
                    }

                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    val qrHistoryAdapter = QrHistoryAdapter(this@QRCodeActivity,userCardPaymentHistoryModel)
                    binding.qrHistoryRecy.setHasFixedSize(true)
                    binding.qrHistoryRecy.itemAnimator = DefaultItemAnimator()
                    binding.qrHistoryRecy.adapter = qrHistoryAdapter

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("History_exe", e.toString())
                    binding.progressBar.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("History_error", t.toString())
                binding.progressBar.visibility = View.GONE
            }

        })

    }

    private fun showDialog() {
        val builder = AlertDialog.Builder(this@QRCodeActivity)
        val viewGroup = this@QRCodeActivity.findViewById<ViewGroup>(android.R.id.content)
        val dialogView: View = LayoutInflater.from(this@QRCodeActivity)
            .inflate(R.layout.bookedservices_aleartdialog, viewGroup, false)
        builder.setView(dialogView)
        builder.setCancelable(true)
        val alertDialog = builder.create()
        val yes = dialogView.findViewById<TextView>(R.id.yes)
        val gotoCart = dialogView.findViewById<TextView>(R.id.goto_cart)

        yes.setOnClickListener {
            val intent = Intent(this@QRCodeActivity, DashbordActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            alertDialog.dismiss()
        }

        gotoCart.setOnClickListener {
            val intent = Intent(this@QRCodeActivity, EditeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            alertDialog.dismiss()
        }

        alertDialog.show()
    }
}