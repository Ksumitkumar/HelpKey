package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class FamliyCardModel {

    @SerializedName("id")
    @Expose
    var id: String? = null

    @SerializedName("card_type")
    @Expose
    var card_type: String? = null


    @SerializedName("name")
    @Expose
    var name: String? = null


    @SerializedName("work")
    @Expose
    var work: String? = null

    @SerializedName("address")
    @Expose
    var address: String? = null

    @SerializedName("photo")
    @Expose
    var photo: String? = null

    @SerializedName("virtual_card_no")
    @Expose
    var virtual_card_no: String? = null

    @SerializedName("card_validity")
    @Expose
    var card_validity: String? = null

    @SerializedName("card_status")
    @Expose
    var card_status: String? = null


    constructor(
        id: String?,
        card_type: String?,
        name: String?,
        work: String?,
        address: String?,
        photo: String?,
        virtual_card_no: String?,
        card_validity: String?,
        card_status: String?
    ) {
        this.id = id
        this.card_type = card_type
        this.name = name
        this.work = work
        this.address = address
        this.photo = photo
        this.virtual_card_no = virtual_card_no
        this.card_validity = card_validity
        this.card_status = card_status
    }
}