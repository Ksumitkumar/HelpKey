package com.helpkey.service.Adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.text.Html
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.squareup.picasso.Picasso
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.Refresh
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.VenderServicesModel
import com.helpkey.service.R
import com.helpkey.service.VendorActivity.AddServiceActivity
import com.helpkey.service.VendorActivity.VendorServicesActivity
import com.helpkey.service.databinding.VenderMyservicesLayoutBinding
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class VendorMyServicesAdapter(
    var list: ArrayList<VenderServicesModel>,
    var context: Context,
    var refresh: Refresh
): RecyclerView.Adapter<VendorMyServicesAdapter.MyViewHolder>() {

    var stattype = ""
    var txtagreement = ""
    var serviceid = ""
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): VendorMyServicesAdapter.MyViewHolder {
        val binding = VenderMyservicesLayoutBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false)
        return MyViewHolder(binding)
    }


    @SuppressLint("ResourceAsColor")
    override fun onBindViewHolder(holder: VendorMyServicesAdapter.MyViewHolder, position: Int) {

        stattype = list[position].type.toString()
        holder.binding.serviceName.text = list[position].servicename
        holder.binding.id.text = "ID: HK0" + list[position].id.toString()
        holder.binding.serviceAggriment.text =
            Html.fromHtml("<font color=#0173B7>  <b><u>Please sign Agreement</u></b></font>")
        try {
            Log.e("kdk", Html.fromHtml(list[position].agreement).toString())
        }catch (e:Exception){
            Log.e("kdk", e.toString())
        }

        if (list[position].agreement==null) {
            holder.binding.serviceAggriment.visibility = View.GONE
        }
        else if (list[position].percentageStatus == "Done") {
            holder.binding.serviceAggriment.visibility = View.GONE
        } else {
            holder.binding.serviceAggriment.setOnClickListener {
                serviceid = list[position].id.toString()
                if (list[position].agreement==null) {
                    holder.binding.serviceAggriment.visibility = View.GONE
                } else {
                    txtagreement=Html.fromHtml(list[position].agreement).toString()

                    agreementDialog(txtagreement,serviceid)
                }
            }
        }

        if (list[position].status.equals("Active")) {
            holder.binding.serviceStatus.text = list[position].status
            holder.binding.serviceStatus.setTextColor(Color.parseColor("#1D9F00"))
            holder.binding.aggriment.text = "Agreement ✔"
        } else if (list[position].status == "Deactive" && list[position].percentageStatus == "Done") {
            holder.binding.serviceStatus.text = list[position].status
            holder.binding.serviceStatus.setTextColor(Color.RED)
            holder.binding.aggriment.text = "Wait for agreement final"
            holder.binding.aggriment.setTextColor(Color.parseColor("#1D9F00"))

        } else if (list[position].agreement == null && list[position].percentageStatus == null) {
            holder.binding.serviceStatus.text = list[position].status
            holder.binding.serviceStatus.setTextColor(Color.RED)
            holder.binding.aggriment.text = "Please wait for verification"
            holder.binding.aggriment.setTextColor(Color.RED)

        } else {
            holder.binding.serviceStatus.text = list[position].status
            holder.binding.serviceStatus.setTextColor(Color.RED)
            holder.binding.aggriment.visibility = View.GONE
        }

        if (stattype == "1") {
            holder.binding.servicePrice.visibility = View.GONE
            Picasso.get().load(
                "https://panels.helpkey.in/public/images/serviceimage/" +
                        list[position].serviceimage
            )
                .placeholder(R.drawable.pointimg)
                .into(holder.binding.img)

        } else {
            holder.binding.servicePrice.text = "₹ " + list[position].price
            holder.binding.aggriment.visibility = View.GONE
            Picasso.get().load(
                "https://panels.helpkey.in/public/images/serviceimage/" +
                        list[position].serviceimage
            )
                .placeholder(R.drawable.serviceimg)
                .into(holder.binding.img)
        }


        holder.binding.delete.setOnClickListener {
            val mdliog = LayoutInflater.from(VendorServicesActivity.activity)
                .inflate(R.layout.delete_service_cofiarmation, null)
            val muBulder = AlertDialog.Builder(VendorServicesActivity.activity)
                .setView(mdliog)
            val maliert = muBulder.show()
            val yes = mdliog.findViewById<TextView>(R.id.yes)
            val no = mdliog.findViewById<TextView>(R.id.no)
            val txt = mdliog.findViewById<TextView>(R.id.txt)
            yes.setOnClickListener {
                deletevenderservices(list[position].vendorId.toString(),list[position].id.toString(), it)
                maliert.dismiss()
            }

            no.setOnClickListener { maliert.dismiss() }

        }

        holder.binding.editservices.setOnClickListener {
            val intate = Intent(context, AddServiceActivity::class.java)
            intate.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            intate.putExtra("serviceUpdate", list[position].type.toString())
            intate.putExtra("sname", list[position].servicename)
            intate.putExtra("vname", list[position].vendorName)
            intate.putExtra("pname", list[position].price.toString())
            intate.putExtra("aname", list[position].address)
            intate.putExtra("cname", list[position].category)
            intate.putExtra("scname", list[position].subcategory)
            intate.putExtra("dname", list[position].description)
            intate.putExtra("pimg", list[position].serviceimage)
            intate.putExtra("cimg", list[position].coverimage)
            intate.putExtra("id", list[position].id.toString())
            intate.putExtra("cat_id", list[position].type)
            context.startActivity(intate)
        }

    }

    override fun getItemCount(): Int {
        return list.size
    }


    inner class MyViewHolder(var binding: VenderMyservicesLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {

    }

    fun deletevenderservices(ids: String,vid: String, it: View) {
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.vendorservicesdelete(ids,vid)
        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("deleteService_respose", response.body().toString() + " " + ids+vid)

                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {

                        Toast.makeText(context,jsonObject.getString("message"),Toast.LENGTH_SHORT).show()

                    } else {

                        Toast.makeText(context,jsonObject.getString("message"),Toast.LENGTH_SHORT).show()

                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("deleteService_ex", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("deleteService_error", t.toString())
            }

        })

    }

    private fun agreementDialog(txts:String,id:String) {

        val mdliog = LayoutInflater.from(VendorServicesActivity.activity)
            .inflate(R.layout.agreement_aleartdialog, null)
        val muBulder = AlertDialog.Builder(VendorServicesActivity.activity)
            .setView(mdliog)
        val maliert = muBulder.show()
        val yes = mdliog.findViewById<TextView>(R.id.oky)
        val back = mdliog.findViewById<TextView>(R.id.back)
        val txt = mdliog.findViewById<TextView>(R.id.txt_view)
        val checkBox = mdliog.findViewById<CheckBox>(R.id.agree)
        txt.text = txts
//        txt.text = Html.fromHtml(R.string.html.toString())
        yes.setOnClickListener {
            if (checkBox.isChecked) {
                update_vendor_service_agreement(id)
                maliert.dismiss()
            } else {
                Toast.makeText(VendorServicesActivity.activity,"Please Conform Agreement",Toast.LENGTH_SHORT).show()
            }
        }
        back.setOnClickListener { maliert.dismiss() }
    }

    fun update_vendor_service_agreement(serviceid:String) {
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.update_vendor_service_agreement(
                serviceid,
            "Done")
        call.enqueue( object : Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    Log.e("agreement_response",response.body().toString()+" $serviceid "+call.request().url().toString())
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    var res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        refresh.refresh()
                        Toast.makeText(VendorServicesActivity.activity,"${jsonObject.getString("message")}",Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(VendorServicesActivity.activity,"${jsonObject.getString("message")}",Toast.LENGTH_SHORT).show()
                    }
                } catch (e:JSONException) {
                    e.printStackTrace()
                    Log.e("agreement_exe",e.toString())
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("agreement_error",t.toString())

            }

        })
    }
}