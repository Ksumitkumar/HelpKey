package com.helpkey.service.UserActivity

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.helpkey.service.Adapter.UserOrderServicesAdapter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.UserOrderServiceModel
import com.helpkey.service.databinding.ActivityFullOrderDetailsBinding
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response

class FullOrderDetails : AppCompatActivity() {

    var prefrenceManager: PrefrenceManger1? = null
    var userOrderServiceModel: ArrayList<UserOrderServiceModel> = ArrayList()
    var total = 0L
    var Subtraction = 0L
    var totalamount = 0L
    lateinit var binding: ActivityFullOrderDetailsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFullOrderDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefrenceManager = PrefrenceManger1(applicationContext)
        binding.mtoolbar.setNavigationOnClickListener(View.OnClickListener { finish() })

        fullorderdetail()
    }

    fun fullorderdetail() {
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.Singleorderdetail(
                intent.getStringExtra("orderid").toString()
            )

        call.enqueue(object : retrofit2.Callback<JsonObject> {
            @SuppressLint("ResourceAsColor")
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e(
                        "singleorder_response",
                        response.body().toString() + " " + response.raw().request().url()
                    )
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progressBar.visibility = View.GONE
                        binding.linear.visibility = View.VISIBLE
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        val jsonObject1 = jsonArray1.getJSONObject(0)
                        val totalprice = jsonObject1.getString("total_amount").toString()
                        for (i in 0 until jsonArray1.length()) {
                            Log.e("skjf", jsonArray1.getString(i).toString())
                            val myOrder: UserOrderServiceModel = Gson().fromJson(
                                jsonArray1.getString(i).toString(),
                                UserOrderServiceModel::class.java
                            )

                            total += (myOrder.serviceCost?.toLong() ?: 0)
                            userOrderServiceModel.add(myOrder)

                        }
                        Subtraction = totalprice.toLong() - total
                        totalamount = total + Subtraction
                        Log.e("subtration", Subtraction.toString())
                        if (totalprice!! <= 0.toString()) {
                            binding.visitcostLayout.visibility = View.GONE
                            binding.orderTotalAmmount.text = "Appointment Booked"
                        } else {
                            binding.visitCost.text = "₹ $Subtraction"
                            binding.orderTotalAmmount.text = "₹ $totalamount"
                        }

                        binding.orderId.text = jsonObject1.getString("order_no")
                        if (jsonObject1.getString("payment_method").equals("cod")) {
                            binding.orderPaymethod.text = "Cash on delivery"
                            binding.paystatusliner.visibility = View.GONE
                        } else {
                            binding.orderPaymethod.text = "Pay Online"
                            binding.paystatusliner.visibility = View.VISIBLE
                        }
                        if (jsonObject1.getString("payment_status").equals("false")) {
                            binding.orderPaystatus.text = "Failed"
                            binding.orderPaystatus.setTextColor(Color.parseColor("#e10028"))
                        } else {
                            binding.orderPaystatus.text = "Success"
                            binding.orderPaystatus.setTextColor(Color.parseColor("#008640"))
                        }
                        binding.orderTimes.text = jsonObject1.getString("created_at")

                        if (jsonObject1.getString("order_status").equals("Completed")) {
                            binding.orderStatus.text = jsonObject1.getString("order_status")
                            binding.orderStatus.setTextColor(Color.parseColor("#008640"))
                        }else{
                            binding.orderStatus.text = jsonObject1.getString("order_status")
                        }
                        binding.orderAddress.text = jsonObject1.getString("delivery_address")
                        binding.addressType.text = jsonObject1.getString("address_type")
                        binding.number.text = "+91 " + jsonObject1.getString("mobile")
                        binding.number.paintFlags = binding.number.paintFlags or Paint.UNDERLINE_TEXT_FLAG
                        binding.number.setOnClickListener {
                            if (ContextCompat.checkSelfPermission(
                                    this@FullOrderDetails,
                                    Manifest.permission.CALL_PHONE
                                ) != PackageManager.PERMISSION_GRANTED
                            ) {
                                ActivityCompat.requestPermissions(
                                    this@FullOrderDetails,
                                    arrayOf(Manifest.permission.CALL_PHONE),
                                    100
                                )
                            } else {
                                val intent = Intent(
                                    Intent.ACTION_DIAL,
                                    Uri.fromParts("tel", binding.number.text.toString(), null)
                                )
                                startActivity(intent)
                            }
                        }
                        Log.e("singleorder", jsonObject.toString())


                    } else {

                    }
                    var adpter1 =
                        UserOrderServicesAdapter(userOrderServiceModel, applicationContext)
                    val linearLayoutManager = LinearLayoutManager(applicationContext)
                    linearLayoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.userServiceOrder.layoutManager = linearLayoutManager
                    binding.userServiceOrder.setHasFixedSize(true)
                    binding.userServiceOrder.itemAnimator = DefaultItemAnimator()
                    binding.userServiceOrder.adapter = adpter1

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("singleorder_ex", e.toString())
                    binding.progressBar.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("singleorder_error", t.toString())
                binding.progressBar.visibility = View.GONE
            }
        })
    }
}