package com.helpkey.service.Adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.squareup.picasso.Picasso
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Models.SearchItemModel
import com.helpkey.service.UserActivity.ProductActivity
import com.helpkey.service.UserActivity.ProductFulldetailsActivity
import com.helpkey.service.databinding.RecviewVendorBinding
import java.util.*
import kotlin.collections.ArrayList

class SearchItemAdapter(var list: ArrayList<SearchItemModel>, var context: Context) : RecyclerView.Adapter<SearchItemAdapter.ViewHolder>() {
    var prefrenceManager: PrefrenceManger1? = null
    inner class ViewHolder(var binding: RecviewVendorBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = RecviewVendorBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.title.text = list[position].servicename?.substring(0, 1)!!.toUpperCase(Locale.ROOT) + list[position].servicename?.substring(1)!!.toLowerCase()
        holder.binding.discirption.text = list[position].description?.substring(0, 1)!!.toUpperCase(Locale.ROOT) + list[position].description?.substring(1)!!.toLowerCase()
        holder.binding.location.text = list[position].address.toString()
        Picasso.get()
            .load("https://panels.helpkey.in/public/images/serviceimage/" + list[position].serviceimage)
            .placeholder(com.helpkey.service.R.drawable.service).into(holder.binding.img)

        holder.binding.card.setOnClickListener {
            if (list[position].type.equals("1")) {
                var intent = Intent(context, ProductActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                Constracter.point = "1"
                intent.putExtra("vendor_id",list[position].vendorId.toString())
                intent.putExtra("name",list[position].servicename.toString())
                intent.putExtra("mobile",list[position].mobile.toString())
                intent.putExtra("address",list[position].address.toString())
                intent.putExtra("dicount",list[position].discount.toString())
                intent.putExtra("description",list[position].description.toString())
                intent.putExtra("cimg",list[position].coverimage.toString())
                intent.putExtra("simg",list[position].serviceimage.toString())
                intent.putExtra("discount",list[position].percentage.toString())
                context.startActivity(intent)
            } else {
                val intent = Intent(context, ProductFulldetailsActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                intent.putExtra("id",list[position].id.toString())
                intent.putExtra("img",list[position].serviceimage.toString())
                intent.putExtra("productname",list[position].servicename.toString())
                intent.putExtra("description",list[position].description.toString())
                intent.putExtra("price",list[position].price.toString())
                context.startActivity(intent)
            }
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }
}