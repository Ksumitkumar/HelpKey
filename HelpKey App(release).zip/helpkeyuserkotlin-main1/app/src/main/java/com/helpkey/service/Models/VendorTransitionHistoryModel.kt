package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class VendorTransitionHistoryModel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("vendor_id")
    @Expose
    var vendorId: String? = null

    @SerializedName("vendorservice_id")
    @Expose
    var vendorserviceId: String? = null

    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("txn_id")
    @Expose
    var txnId: String? = null

    @SerializedName("amount")
    @Expose
    var amount: String? = null

    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("servicepoint")
    @Expose
    var servicepoint: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null

    @SerializedName("servicename")
    @Expose
    var servicename: String? = null
}