package com.helpkey.service.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.helpkey.service.Models.VendorAllOrderRequestModel
import com.helpkey.service.R
import com.helpkey.service.databinding.VendorserviceRecylviewBinding
import kotlin.math.min

class VendorserviceAdapter(
    var list: ArrayList<VendorAllOrderRequestModel>,
    var context: Context,

): RecyclerView.Adapter<VendorserviceAdapter.ViewHolder>() {
    inner class ViewHolder(var binding: VendorserviceRecylviewBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = VendorserviceRecylviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        holder.binding.serviceName.text = list[position].servicename
        holder.binding.servicePrice.text = "₹ "+list[position].serviceCost
        Picasso.get()
            .load("https://panels.helpkey.in/public/images/serviceimage/" + list[position].serviceimage)
            .placeholder(R.drawable.logo).into(holder.binding.serviceImg)
    }
    override fun getItemCount(): Int {
        return min(4,list.size)
    }
}