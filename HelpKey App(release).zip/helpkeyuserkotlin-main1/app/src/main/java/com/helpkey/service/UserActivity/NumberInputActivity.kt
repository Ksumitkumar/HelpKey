package com.helpkey.service.UserActivity

import android.R
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.VendorActivity.VendorDashbordActivity
import com.helpkey.service.databinding.ActivityNumberInputBinding
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import retrofit2.create

class NumberInputActivity : AppCompatActivity() {
    var address = ""
    companion object {
        var usertype = ""
    }
    var login = ""
    var prefrenceManager: PrefrenceManger1? = null
    lateinit var binding: ActivityNumberInputBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNumberInputBinding.inflate(layoutInflater)
        setContentView(binding.root)
        login = "login"
        prefrenceManager = PrefrenceManger1(applicationContext)
        address = intent.getStringExtra("selectuser").toString()
        usertype = prefrenceManager?.gettype(applicationContext).toString()
        binding.loginText.visibility=View.GONE
        binding.back.setOnClickListener { finish() }
        mainhandle()
    }

    fun mainhandle() {
        binding.number.visibility = View.VISIBLE
        binding.referralCode.visibility = View.GONE
        binding.password.visibility = View.VISIBLE
        binding.email.visibility = View.GONE
        binding.mobile.visibility = View.GONE

        binding.logIn.setOnClickListener {
            binding.logIn.setTextColor(Color.parseColor("#2196F3"))
            binding.signIn.setTextColor(Color.RED)
            binding.forgetPassword.setTextColor(Color.RED)
            binding.referralCode.visibility = View.GONE
            binding.txtlogin.text = "Login"
            binding.otp.text = "Login"
            val animation: Animation =
                AnimationUtils.loadAnimation(applicationContext, R.anim.slide_in_left)
            binding.txtlogin.startAnimation(animation)
            binding.number.visibility = View.VISIBLE
            binding.referralCode.visibility = View.GONE
            binding.password.visibility = View.VISIBLE
            binding.email.visibility = View.GONE
            binding.mobile.visibility = View.GONE
            when (login) {
                "login" -> {
                    binding.logIn.isEnabled = false
                    binding.signIn.isEnabled = true
                    binding.forgetPassword.isEnabled = true
                }
                "signup" -> {
                    binding.signIn.isEnabled = false
                    binding.logIn.isEnabled = true
                    binding.forgetPassword.isEnabled = true
                    binding.loginText.visibility=View.VISIBLE
                }
                "password" -> {
                    binding.forgetPassword.isEnabled = false
                    binding.logIn.isEnabled = true
                    binding.signIn.isEnabled = true
                    binding.loginText.visibility=View.VISIBLE
                }
            }
        }

        binding.signIn.setOnClickListener {
            binding.signIn.setTextColor(Color.parseColor("#2196F3"))
            binding.logIn.setTextColor(Color.RED)
            binding.forgetPassword.setTextColor(Color.RED)
            binding.referralCode.visibility = View.VISIBLE
            binding.txtlogin.text = "Sign up"
            binding.otp.text = "Sign up"
            val animation: Animation =
                AnimationUtils.loadAnimation(applicationContext, R.anim.slide_out_right)
            binding.txtlogin.startAnimation(animation)
            binding.number.visibility = View.GONE
            binding.referralCode.visibility = View.VISIBLE
            binding.password.visibility = View.VISIBLE
            binding.email.visibility = View.VISIBLE
            binding.mobile.visibility = View.VISIBLE
            when (login) {
                "login" -> {
                    binding.logIn.isEnabled = false
                    binding.signIn.isEnabled = true
                    binding.forgetPassword.isEnabled = true
                    binding.loginText.visibility=View.GONE

                }
                "signup" -> {
                    binding.signIn.isEnabled = false
                    binding.logIn.isEnabled = true
                    binding.forgetPassword.isEnabled = true
                    binding.loginText.visibility=View.VISIBLE
                }
                "password" -> {
                    binding.forgetPassword.isEnabled = false
                    binding.logIn.isEnabled = true
                    binding.signIn.isEnabled = true
                    binding.loginText.visibility=View.VISIBLE
                }
            }
        }

        if (address == "User") {
            binding.number.visibility = View.VISIBLE
            binding.referralCode.visibility = View.GONE
            binding.password.visibility = View.VISIBLE
            binding.email.visibility = View.GONE
            binding.mobile.visibility = View.GONE
            binding.logIn.setOnClickListener {
                binding.logIn.setTextColor(Color.parseColor("#2196F3"))
                binding.signIn.setTextColor(Color.RED)
                binding.forgetPassword.setTextColor(Color.RED)
                binding.referralCode.visibility = View.GONE
                val animation: Animation =
                    AnimationUtils.loadAnimation(applicationContext, R.anim.slide_in_left)
                binding.txtlogin.startAnimation(animation)
                binding.txtlogin.text = "Login"
                binding.otp.text = "Login"
                login = "login"
                binding.number.visibility = View.VISIBLE
                binding.referralCode.visibility = View.GONE
                binding.password.visibility = View.VISIBLE
                binding.email.visibility = View.GONE
                binding.mobile.visibility = View.GONE
                when (login) {
                    "login" -> {
                        binding.logIn.isEnabled = false
                        binding.signIn.isEnabled = true
                        binding.forgetPassword.isEnabled = true
                        binding.loginText.visibility=View.GONE
                    }
                    "signup" -> {
                        binding.signIn.isEnabled = false
                        binding.logIn.isEnabled = true
                        binding.forgetPassword.isEnabled = true
                        binding.loginText.visibility=View.VISIBLE
                    }
                    "password" -> {
                        binding.forgetPassword.isEnabled = false
                        binding.logIn.isEnabled = true
                        binding.signIn.isEnabled = true
                        binding.loginText.visibility=View.VISIBLE
                    }
                }
            }
            binding.signIn.setOnClickListener {
                binding.signIn.setTextColor(Color.parseColor("#2196F3"))
                binding.logIn.setTextColor(Color.RED)
                binding.forgetPassword.setTextColor(Color.RED)
                binding.referralCode.visibility = View.VISIBLE
                binding.loginText.visibility=View.GONE
                val animation: Animation =
                    AnimationUtils.loadAnimation(applicationContext, R.anim.slide_out_right)
                binding.txtlogin.startAnimation(animation)
                binding.txtlogin.text = "Sign up"
                binding.otp.text = "Sign up"
                login = "signup"
                binding.number.visibility = View.GONE
                binding.referralCode.visibility = View.VISIBLE
                binding.password.visibility = View.VISIBLE
                binding.email.visibility = View.VISIBLE
                binding.mobile.visibility = View.VISIBLE
                when (login) {
                    "login" -> {
                        binding.logIn.isEnabled = false
                        binding.signIn.isEnabled = true
                        binding.forgetPassword.isEnabled = true
                        binding.loginText.visibility=View.GONE
                    }
                    "signup" -> {
                        binding.signIn.isEnabled = false
                        binding.logIn.isEnabled = true
                        binding.forgetPassword.isEnabled = true
                        binding.loginText.visibility=View.VISIBLE
                    }
                    "password" -> {
                        binding.forgetPassword.isEnabled = false
                        binding.logIn.isEnabled = true
                        binding.signIn.isEnabled = true
                        binding.loginText.visibility=View.VISIBLE
                    }
                }
            }
        } else {

            binding.logIn.setOnClickListener {
                login = "login"
                binding.logIn.setTextColor(Color.parseColor("#2196F3"))
                binding.signIn.setTextColor(Color.RED)
                binding.forgetPassword.setTextColor(Color.RED)
                val animation: Animation =
                    AnimationUtils.loadAnimation(applicationContext, R.anim.slide_in_left)
                binding.txtlogin.startAnimation(animation)
                binding.txtlogin.text = "Login"
                binding.otp.text = "Login"
                binding.number.visibility = View.VISIBLE
                binding.referralCode.visibility = View.GONE
                binding.password.visibility = View.VISIBLE
                binding.email.visibility = View.GONE
                binding.mobile.visibility = View.GONE
                when (login) {
                    "login" -> {
                        binding.logIn.isEnabled = false
                        binding.signIn.isEnabled = true
                        binding.forgetPassword.isEnabled = true
                        binding.loginText.visibility=View.GONE

                    }
                    "signup" -> {
                        binding.signIn.isEnabled = false
                        binding.logIn.isEnabled = true
                        binding.forgetPassword.isEnabled = true
                        binding.loginText.visibility=View.VISIBLE
                    }
                    "password" -> {
                        binding.forgetPassword.isEnabled = false
                        binding.logIn.isEnabled = true
                        binding.signIn.isEnabled = true
                        binding.loginText.visibility=View.VISIBLE
                    }
                }
            }

            binding.signIn.setOnClickListener {
                login = "signup"
                binding.signIn.setTextColor(Color.parseColor("#2196F3"))
                binding.logIn.setTextColor(Color.RED)
                binding.forgetPassword.setTextColor(Color.RED)

                val animation: Animation =
                    AnimationUtils.loadAnimation(applicationContext, R.anim.slide_out_right)
                binding.txtlogin.startAnimation(animation)
                binding.txtlogin.text = "Sign up"
                binding.otp.text = "Sign up"
                binding.number.visibility = View.GONE
                binding.referralCode.visibility = View.GONE
                binding.password.visibility = View.VISIBLE
                binding.email.visibility = View.VISIBLE
                binding.mobile.visibility = View.VISIBLE
                when (login) {
                    "login" -> {
                        binding.logIn.isEnabled = false
                        binding.signIn.isEnabled = true
                        binding.forgetPassword.isEnabled = true
                        binding.loginText.visibility=View.GONE


                    }
                    "signup" -> {
                        binding.signIn.isEnabled = false
                        binding.logIn.isEnabled = true
                        binding.forgetPassword.isEnabled = true
                        binding.loginText.visibility=View.VISIBLE
                    }
                    "password" -> {
                        binding.forgetPassword.isEnabled = false
                        binding.logIn.isEnabled = true
                        binding.signIn.isEnabled = true
                        binding.loginText.visibility=View.VISIBLE
                    }
                }
            }

            binding.referralCode.visibility = View.GONE
        }

        binding.forgetPassword.setOnClickListener {
            login = "password"
            val animation: Animation =
                AnimationUtils.loadAnimation(applicationContext, R.anim.slide_in_left)
            binding.txtlogin.startAnimation(animation)
            binding.txtlogin.text = "Forget Password"
            binding.forgetPassword.setTextColor(Color.parseColor("#2196F3"))
            binding.signIn.setTextColor(Color.RED)
            binding.logIn.setTextColor(Color.RED)
            binding.number.visibility = View.GONE
            binding.referralCode.visibility = View.GONE
            binding.password.visibility = View.GONE
            binding.email.visibility = View.GONE
            binding.mobile.visibility = View.VISIBLE
            binding.otp.text = "Send OTP"
            when (login) {
                "login" -> {
                    binding.logIn.isEnabled = false
                    binding.signIn.isEnabled = true
                    binding.forgetPassword.isEnabled = true
                    binding.loginText.visibility=View.GONE
                }
                "signup" -> {
                    binding.signIn.isEnabled = false
                    binding.logIn.isEnabled = true
                    binding.forgetPassword.isEnabled = true
                    binding.loginText.visibility=View.VISIBLE
                }
                "password" -> {
                    binding.forgetPassword.isEnabled = false
                    binding.logIn.isEnabled = true
                    binding.signIn.isEnabled = true
                    binding.loginText.visibility=View.VISIBLE
                }
            }
        }


        binding.otp.setOnClickListener {
            if (login == "login") {
//                Toast.makeText(this@NumberInputActivity, login, Toast.LENGTH_SHORT).show()
                login()
            } else if (login == "password") {
                forgetpassword()
//                Toast.makeText(this@NumberInputActivity, "Password", Toast.LENGTH_SHORT).show()
            } else {
//                Toast.makeText(this@NumberInputActivity, "singnup", Toast.LENGTH_SHORT).show()
                if (address == "User") {

//                    Toast.makeText(this@NumberInputActivity, "user", Toast.LENGTH_SHORT).show()
                    otp_verification()
                    if (validation()) {

                    } else {
                    }
                } else {
//                    Toast.makeText(this@NumberInputActivity, "vendor", Toast.LENGTH_SHORT).show()
                    vendorotp_verification()
                    if (validation()) {

                    } else {

                    }
                }
            }

        }
    }


    fun validation(): Boolean {
        if (binding.number.text.toString().trim().isEmpty()) {
            binding.number.error = "Enter The mobile Number"
            binding.number.requestFocus()
        } else if (binding.number.text.toString().trim().length < 10) {
            binding.number.error = "Enter  The 10 Digit Number"
            binding.number.requestFocus()
        } else if (binding.password.text.toString().trim().isEmpty()) {
            binding.password.error = "Enter Password Number"
            binding.password.requestFocus()
        } else {
            return true
        }
        return false
    }

    fun otp_verification() {
        binding.progress.visibility = View.VISIBLE
        val getDataServices: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataServices.send_otp(
            binding.mobile.text.toString(),
            binding.email.text.toString(),
            binding.password.text.toString(),
            usertype,
            binding.referralCode.text.toString()
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                binding.progress.visibility = View.GONE
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e("number_response", jsonArray.toString())
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    val message=jsonObject.getString("message")
                    if (res.equals("success")) {
                        Toast.makeText(
                            this@NumberInputActivity,
                            "" + message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        val jsonObject1 = jsonArray1.getJSONObject(0)
                        prefrenceManager!!.setMobileno(
                            binding.number.text.toString(),
                            applicationContext
                        )



                        prefrenceManager!!.setUserId(
                            jsonObject1.getString("id"),
                            applicationContext
                        )
                        prefrenceManager!!.setMobileno(
                            jsonObject1.getString("mobile"),
                            applicationContext
                        )


                        val i = Intent(this@NumberInputActivity, OtpActivity::class.java)
                        i.putExtra("otp", jsonObject1.getString("otp"))
                        i.putExtra("message", jsonObject.getString("message"))
                        i.putExtra("mobile", jsonObject1.getString("mobile"))
                        i.putExtra("id", jsonObject1.getString("id"))
                        startActivity(i)
                    } else {
                        Toast.makeText(
                            applicationContext,
                            "" + message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                        binding.progress.visibility = View.GONE
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("number_error", e.toString())
                    binding.progress.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("number_error", t.toString())
                binding.progress.visibility = View.GONE
            }

        })

    }

    fun vendorotp_verification() {
        binding.progress.visibility = View.VISIBLE
        val getDataServices: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataServices.send_otp(
            binding.mobile.text.toString(),
            binding.email.text.toString(),
            binding.password.text.toString(),
            usertype,
            ""
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                binding.progress.visibility = View.GONE
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e("number_response", jsonArray.toString())
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    val message1 = jsonObject.getString("message")
                    if (res.equals("success")) {
                        Toast.makeText(
                            this@NumberInputActivity,
                            "" + message1.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        val jsonObject1 = jsonArray1.getJSONObject(0)



                        prefrenceManager!!.setUserId(
                            jsonObject1.getString("id"),
                            applicationContext
                        )
                        prefrenceManager!!.setMobileno(
                            jsonObject1.getString("mobile"),
                            applicationContext
                        )
                        val i = Intent(this@NumberInputActivity, OtpActivity::class.java)
                        i.putExtra("otp", jsonObject1.getString("otp"))
                        i.putExtra("message", jsonObject.getString("message"))
                        i.putExtra("mobile", jsonObject1.getString("mobile"))
                        i.putExtra("id", jsonObject1.getString("id"))
                        startActivity(i)
                    } else {
                        Toast.makeText(
                            this@NumberInputActivity,
                            "" + message1.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                        binding.progress.visibility = View.GONE
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("number_error", e.toString())
                    binding.progress.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("number_error", t.toString())
                binding.progress.visibility = View.GONE
            }
        })
    }
    fun login() {
        binding.progressBar.visibility = View.VISIBLE
        val login: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = login.login(
            binding.number.text.toString(), binding.password.text.toString(),
            usertype.toString()
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    Log.e("login_response", response.body().toString())
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {

                        binding.progressBar.visibility = View.GONE
                        val dataArray = jsonObject.getJSONArray("data")
                        val data = dataArray.getJSONObject(0)

                        if (address == "User") {
                            prefrenceManager!!.setMobileno(
                                data.getString("mobile"),
                                applicationContext
                            )
                            prefrenceManager!!.setUserId(
                                data.getString("id"),
                                applicationContext
                            )

                            Toast.makeText(
                                this@NumberInputActivity,
                                "${jsonObject.getString("message")}",
                                Toast.LENGTH_SHORT
                            ).show()
                            startActivity(
                                Intent(
                                    this@NumberInputActivity,
                                    DashbordActivity::class.java
                                )
                            )
                            finish()
                        } else {
                            prefrenceManager!!.setMobileno(
                                data.getString("mobile"),
                                applicationContext
                            )
                            prefrenceManager!!.setUserId(
                                data.getString("id"),
                                applicationContext
                            )
                            Toast.makeText(
                                this@NumberInputActivity,
                                "${jsonObject.getString("message")}",
                                Toast.LENGTH_SHORT
                            ).show()
                            startActivity(
                                Intent(
                                    this@NumberInputActivity,
                                    VendorDashbordActivity::class.java
                                )
                            )
                            finish()
                        }
                    } else {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(
                            this@NumberInputActivity,
                            "${jsonObject.getString("message")}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: JSONException) {
                    binding.progressBar.visibility = View.GONE
                    e.printStackTrace()
                    Log.e("login_exe", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                binding.progressBar.visibility = View.GONE
                Log.e("login_err", t.toString())

            }

        })
    }

    fun forgetpassword() {
        binding.progressBar.visibility = View.VISIBLE
        val forget: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> = forget.forget(binding.mobile.text.toString(), usertype)
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e("forget_res", response.body().toString())
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progressBar.visibility = View.GONE
                        startActivity(
                            Intent(this@NumberInputActivity, OtpActivity::class.java)
                                .putExtra("forget", "password")
                                .putExtra("otp", jsonObject.getString("data"))
                                .putExtra("mobile", binding.mobile.text.toString())
                        )
                    } else {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(
                            this@NumberInputActivity,
                            "Please Inter Valid Mobile Number",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("forget_exe", e.toString())
                    binding.progressBar.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("forget_err", t.toString())
                binding.progressBar.visibility = View.GONE
            }

        })
    }

}