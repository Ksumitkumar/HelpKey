package com.helpkey.service.Adapter

import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.ernestoyaquello.dragdropswiperecyclerview.DragDropSwipeAdapter
import com.ernestoyaquello.dragdropswiperecyclerview.listener.OnListScrollListener
import com.squareup.picasso.Picasso
import com.helpkey.service.Models.CartModel
import com.helpkey.service.R

class CartAdapter(dateSet: ArrayList<CartModel>,val cartDelete: com.helpkey.service.Adapter.CartAdapter.CartDelete) :
    DragDropSwipeAdapter<CartModel, com.helpkey.service.Adapter.CartAdapter.ViewHolder>(dateSet) {
    var number = ""
    class ViewHolder(itemView: View) : DragDropSwipeAdapter.ViewHolder(itemView) {
        val itemText: TextView = itemView.findViewById(R.id.item_name)
        val price: TextView = itemView.findViewById(R.id.product_price)
        val img: ImageView = itemView.findViewById(R.id.productimage)
        val rupee: TextView = itemView.findViewById(R.id.rupees)
        val deleteCart:ImageView=itemView.findViewById(R.id.deleteCart)



    }


    interface CartDelete{
        fun cardItemDelete(position: Int)
    }
    private val onListScrollListener = object : OnListScrollListener {
        override fun onListScrollStateChanged(scrollState: OnListScrollListener.ScrollState) {
            Log.e("delet","onListScrollStateChanged")
        }

        override fun onListScrolled(scrollDirection: OnListScrollListener.ScrollDirection, distance: Int) {
            Log.e("delet","onListScrolled")
        }
    }

    override fun getViewHolder(itemLayout: View) =
        ViewHolder(itemLayout)


    override fun onBindViewHolder(item: CartModel, viewHolder: ViewHolder, position: Int) {


        viewHolder.deleteCart.setOnClickListener {
            cartDelete.cardItemDelete(position)

        }

        if (position.equals(null)) {

        } else {
            number = dataSet[position].price.toString()
            if (dataSet[position].price.equals(null)) {
                viewHolder.price.text = "Book Appointment"
                viewHolder.rupee.visibility = View.GONE
            }
            else {
                viewHolder.price.text = "₹ " + dataSet[position].price
            }
            viewHolder.itemText.text = dataSet[position].servicename.toString()
//        viewHolder.price.text = dataSet[position].price
            Picasso.get()
                .load("https://panels.helpkey.in/public/images/serviceimage/" + dataSet[position].serviceimage)
                .placeholder(R.drawable.logo)
                .into(viewHolder.img)
        }


    }

    override fun getViewToTouchToStartDraggingItem(
        item: CartModel,
        viewHolder: ViewHolder,
        position: Int
    ): View? {

        return null
    }




}