package com.helpkey.service.Helper

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface GetDataService {

    @POST("otp-registration")
    @FormUrlEncoded
    fun send_otp(
        @Field("mobile") mobile: String?,
        @Field("email") email: String?,
        @Field("password") password: String?,
        @Field("type") type: String?,
        @Field("referred_by") referred_by: String?
    ): Call<JsonArray>

    @POST("otp-registration")
    @FormUrlEncoded
    fun vendorsend_otp(
        @Field("mobile") mobile: String?,
        @Field("type") type: String?,
        @Field("password") password: String?
    ): Call<JsonArray>


    @Headers("multipart: true")
    @POST("update-profile/{id}")
    @Multipart
    fun update_profile(
        @Part image: MultipartBody.Part,
        @Path("id") id: String,
        @Part("username") username: RequestBody,
        @Part("mobile") mobile: RequestBody,
        @Part("gender") gender: RequestBody,
        @Part("pin_code") pin_code: RequestBody,
        @Part("country") country: RequestBody,
        @Part("state") state: RequestBody,
        @Part("city") city: RequestBody,
        @Part("address") address: RequestBody,
        @Part("email") email: RequestBody,
        @Part("work") work: RequestBody,
        @Part("discount") discount: RequestBody,
        @Part("description") description: RequestBody,
        @Part("latitude") latitude: RequestBody,
        @Part("longitude") longitude: RequestBody
    ): Call<JsonArray>



    @POST("update-profile/{id}")
    @FormUrlEncoded
    fun user_update(
        @Path("id") id: String?,
        @Field("username") username: String?,
        @Field("mobile") mobile: String?,
        @Field("gender") gender: String?,
        @Field("work") work: String?,
        @Field("pin_code") pin_code: String?,
        @Field("country") country: String?,
        @Field("state") state: String?,
        @Field("city") city: String?,
        @Field("address") address: String?,
        @Field("email") email: String?,
        @Field("description") description: String?,
        @Field("latitude") latitude: String?,
        @Field("longitude") longitude: String?

    ): Call<JsonArray>

    @Headers("multipart: true")
    @POST("upload-document-virtual-card/{id}")
    @Multipart
    fun uplode_document(
        @Part document_image: MultipartBody.Part,
        @Path("id") id: String,
    ): Call<JsonObject>

    @Headers("multipart: true")
    @POST("order-other-virtual-card")
    @Multipart
    fun order_famliy(
        @Part document_image: MultipartBody.Part,
        @Part photo: MultipartBody.Part,
        @Part("order_no") order_no:RequestBody,
        @Part("user_id") user_id:RequestBody,
        @Part("amount") amount:RequestBody,
        @Part("txn_id") txn_id:RequestBody,
        @Part("name") name:RequestBody,
        @Part("work") work:RequestBody,
        @Part("address") address:RequestBody,
        @Part("payment_status") payment_status:RequestBody
    ): Call<JsonObject>


    @POST("order-virtual-card")
    @FormUrlEncoded
    fun cardpaymentsuccess(
        @Field("user_id") user_id: String,
        @Field("order_no") order_no: String,
        @Field("amount") amount: String,
        @Field("txn_id") txn_id: String,
        @Field("payment_status") payment_status: String,
    ): Call<JsonObject>

    @POST("verification-otp")
    @FormUrlEncoded
    fun verify_otp(
        @Field("type") type: String?,
        @Field("otp") otp: String?,
        @Field("mobile") mobile: String?
    ): Call<JsonArray>


    @POST("fetch-vendor-by-subcategory/{cat_id}/{subcate_id}")
    fun fetch_vendor_by_subcategory(
        @Path("cat_id") cat_id: String?,
        @Path("subcate_id") subcate_id: String?
    ): Call<JsonObject>


    @GET("view-cart/{user_id}")
    fun view_cart(
        @Path("user_id") user_id: String?,
    ): Call<JsonArray>

    @GET("count-add-cart-items/{user_id}")
    fun cart_count(
        @Path("user_id") user_id: String?,
    ): Call<JsonArray>

    @GET("fetch-vendor-service/{vendor_id}")
    fun fetch_vendorservice(
        @Path("vendor_id") vendor_id: String?
    ): Call<JsonArray>

    @GET("fetch-vendor-service-type/{vid}/{cid}/{scid}")
    fun fetch_vendorservicecate(
        @Path("vid") vid: String?,
        @Path("cid") cid: String?,
        @Path("scid") scid: String?
    ): Call<JsonArray>


    @POST("add-to-cart/{user_id}/{service_id}")
    fun add_to_cart(
        @Path("user_id") user_id: String?,
        @Path("service_id") service_id: String?
    ): Call<JsonArray>


    @POST("add-delivery-address/{user_id}/{latitude}/{longitude}")
    @FormUrlEncoded
    fun address(
        @Path("user_id") user_id: String?,
        @Path("latitude") latitude: String?,
        @Path("longitude") longitude: String?,
        @Field("address") address: String?,
        @Field("address_type") address_type: String?
    ): Call<JsonArray>

    @GET("fetch-delivery-address/{user_id}")
    fun getAddress(
        @Path("user_id") user_id: String?,
    ): Call<JsonArray>

    @DELETE("delete-delivery-address/{user_id}")
    fun deleteAddress(
        @Path("user_id") user_id: String?,
    ): Call<JsonArray>

    @GET("view-profile/{user_id}")
    fun view_profile(
        @Path("user_id") user_id: String?,
    ): Call<JsonArray>

    @POST("generate-orderId/{user_id}")
    fun orderid(
        @Path("user_id") user_id: String?,
    ): Call<JsonArray>

    @GET("fetch-virtual-card/{user_id}")
    fun fetch_virtual_card(
        @Path("user_id") user_id: String?,
    ): Call<JsonObject>

    @GET("fetch-other-virtual-card/{user_id}")
    fun fetch_card_family(
        @Path("user_id") user_id: String?,
    ): Call<JsonObject>

  @GET("order-details/{user_id}")
    fun order_details(
        @Path("user_id") user_id: String?,
    ): Call<JsonObject>

    @GET("verify-profile/{user_id}")
    fun verify_profile(
        @Path("user_id") user_id: String?,
    ): Call<JsonArray>

    @POST("update-profile{id}")
    @FormUrlEncoded
    fun user_registraion(
        @Field("id") id: String?,
        @Field("name") name: String?,
        @Field("mobile") mobile: String?,
        @Field("email") email: String?,
        @Field("password") password: String?,
        @Field("refferal_code") refferal_code: String?,
        @Field("type") type: String?
    ): Call<JsonObject>


    @POST("add-book-now/{user_id}/{deliv_id}")
    @FormUrlEncoded
    fun add_book_now(
        @Path("user_id") user_id: String?,
        @Path("deliv_id") deliv_id: String?,
        @Field("payment_method") payment_method: String?,
        @Field("amount") amount: String?
    ): Call<JsonArray>


 @POST("order-update-pay/{user_id}/{order_id}/{payment_type}/{transaction_id}")

    fun order_update_pay(
        @Path("user_id") user_id: String?,
        @Path("order_id") deliv_id: String?,
        @Path("payment_type") payment_type: String?,
        @Path("transaction_id") transaction_id: String?
    ): Call<JsonArray>

   @POST("fetch-category-sb")
    @FormUrlEncoded
    fun fetch_category(
        @Field("category") category: String?
    ): Call<JsonArray>


    @GET("fetch-banner")
    fun banner(
    ): Call<JsonArray>


    @GET("fetch-category/{id}")
    fun catgeroy(
        @Path("id") id: String?
    ): Call<JsonArray>


    @GET("fetch-popular-service-list")
    fun mostpopular(
    ): Call<JsonObject>

    @GET("fetch-popular-point-list")
    fun topvendor(
    ): Call<JsonObject>


    @DELETE("delete-cart/{cart_id}")
    fun delete_cart(
        @Path("cart_id") cart_id: String?
    ): Call<JsonArray>

    @GET("fetch-single-delivery-address/{id}")
    fun fetch_address(
        @Path("id") id: String?
    ): Call<JsonArray>

    @GET("fetch-all-vendor-order-services/{id}")
    fun VendorOrderRequest(
        @Path("id") id: String?
    ): Call<JsonObject>

    @GET("fetch-all-vendor-complete-order-services/{id}")
    fun Vendorcompleteorderservices(
        @Path("id") id: String?
    ): Call<JsonObject>

    @GET("fetch-all-vendor-uncomplete-order-services/{id}")
    fun VendorUncompleteOrderServices(
        @Path("id") id: String?
    ): Call<JsonObject>

    @GET("fetch-all-vendor-uncomplete-order-services/{id}")
    fun vendorUncompleteService(
        @Path("id") id: String?
    ): Call<JsonObject>

    @GET("fetch-all-vendor-cancel-order-services/{id}")
    fun vendorcancelService(
        @Path("id") id: String?
    ): Call<JsonObject>

    @POST("delete-vendorservice-request")
    @FormUrlEncoded
    fun vendorservicesdelete(
        @Field("user_id") user_id: String?,
        @Field("vendorservice_id") vendorservice_id: String?
    ): Call<JsonObject>

    @GET("view-single-order-details/{id}")
    fun Singleorderdetail(
        @Path("id") id: String?
    ): Call<JsonObject>

    @POST("near-vendor-list/{lat1}/{lon1}")
    fun nearbyvendor(
        @Path("lat1") lat1: String?,
        @Path("lon1") lon1: String?
    ): Call<JsonObject>

    @POST("user-verification")
    @FormUrlEncoded
    fun userverification(
        @Field("mobile") mobile: String?,
        @Field("type") type: String?

    ): Call<JsonArray>

    @Headers("multipart: true")
    @POST("update-profile/{id}")
    @Multipart
    fun vendor_register(
        @Path("id") id: String,
        @Part image: MultipartBody.Part,
        @Part("username") username: RequestBody,
        @Part("mobile") mobile: RequestBody,
        @Part("city") city: RequestBody,
        @Part("state") state: RequestBody,
        @Part("discount") discount: RequestBody,
        @Part("password") password: RequestBody,
        @Part("email") email: RequestBody,
        @Part("gender") gender: RequestBody,
        @Part("address") address: RequestBody,
        @Part("pin_code") pin_code: RequestBody,
        @Part("description") description: RequestBody,
        @Part("work") work: RequestBody,
        @Part("latitude") latitude: RequestBody,
        @Part("longitude") longitude: RequestBody

    ): Call<JsonArray>

    @Headers("multipart: true")
    @POST("add-vendor-service/{id}")
    @Multipart
    fun addvendorservices(
        @Path("id") id: String,
        @Part("type") type: RequestBody,
        @Part("mobile") mobile: RequestBody,
        @Part("email") email: RequestBody,
        @Part("servicename") servicename: RequestBody,
        @Part("vendorname") vendorname: RequestBody,
        @Part("price") price: RequestBody,
        @Part("discount") discount: RequestBody,
        @Part("address") address: RequestBody,
        @Part("latitude")latitude: RequestBody,
        @Part("longitude")longitude: RequestBody,
        @Part("category") category: RequestBody,
        @Part("subcategory") subcategory: RequestBody,
        @Part coverimage: MultipartBody.Part,
        @Part serviceimage: MultipartBody.Part,
        @Part document: MultipartBody.Part,
        @Part("description") description: RequestBody,
        @Part("ac_no") accountNumber: RequestBody,
        @Part("ac_holder_name") accountHolderName: RequestBody,
        @Part("ifsc") ifsc: RequestBody,
        @Part("upi") upi: RequestBody
    ): Call<JsonArray>

    @Headers("multipart: true")
    @POST("add-vendor-service/{id}")
    @Multipart
    fun addvendorservice(
        @Path("id") id: String,
        @Part("type") type: RequestBody,
        @Part("mobile") mobile: RequestBody,
        @Part("email") email: RequestBody,
        @Part("servicename") servicename: RequestBody,
        @Part("vendorname") vendorname: RequestBody,
        @Part("price") price: RequestBody,
        @Part("discount") discount: RequestBody,
        @Part("address") address: RequestBody,
        @Part("latitude")latitude: RequestBody,
        @Part("longitude")longitude: RequestBody,
        @Part("category") category: RequestBody,
        @Part("subcategory") subcategory: RequestBody,
        @Part coverimage: MultipartBody.Part,
        @Part serviceimage: MultipartBody.Part,
        @Part("description") description: RequestBody,
        @Part("ac_no") accountNumber: RequestBody,
        @Part("ac_holder_name") accountHolderName: RequestBody,
        @Part("ifsc") ifsc: RequestBody,
        @Part("upi") upi: RequestBody
    ): Call<JsonArray>

    @POST("update-vendor-service/{id}")
    @FormUrlEncoded
    fun vendor_UpdateService(
        @Path("id") id: String?,
        @Field("servicename") servicename: String?,
        @Field("vendorname") vendorname: String?,
        @Field("price") price: String?,
        @Field("address") address: String?,
        @Field("category") category: String?,
        @Field("subcategory") subcategory: String?,
        @Field("description") description: String?

    ): Call<JsonArray>


    @GET("fetch-vendor-service/{id}")
    fun VendorSrvices(
        @Path("id") id: String?
    ): Call<JsonArray>

    @POST("fetch-transaction-history")
    @FormUrlEncoded
    fun transationhistory(
        @Field("id") id: String?
    ): Call<JsonObject>

    @POST("check-user")
    @FormUrlEncoded
    fun check_user(
        @Field("id") id: String?
    ): Call<JsonArray>

    @GET("fetch-vendor-all-type-service/{vid}/{cid}")
    fun fetch_vendor_allServices(
        @Path("vid") vid: String?,
        @Path("cid") cid: String?
    ): Call<JsonArray>

    @GET("get-delete-vendorservice-request/{vid}/{type}")
    fun fetch_vendor_alldeleteServices(
        @Path("vid") vid: String?,
        @Path("type") type: String?
    ): Call<JsonObject>

    @POST("update-vendor-service-agreement")
    @FormUrlEncoded
    fun update_vendor_service_agreement(
        @Field("id") id: String?,
        @Field("percentage_status") percentage_status: String?
    ): Call<JsonArray>

    @POST("fetch-point-by-subcategory/{cid}/{scid}")
    fun fetch_point_by_subcategory(
        @Path("cid") cid: String?,
        @Path("scid") scid: String?
    ): Call<JsonObject>

    @POST("login")
    @FormUrlEncoded
    fun login(
        @Field("email") email: String?,
        @Field("password") password: String?,
        @Field("type") type: String?
    ): Call<JsonArray>

    @POST("forget-password/{mobile}/{type}")
    fun forget(
        @Path("mobile") mobile: String?,
        @Path("type") type: String?
    ): Call<JsonObject>

    @POST("change-password")
    @FormUrlEncoded
    fun chandepassword(
        @Field("mobile") mobile: String?,
        @Field("type") type: String?,
        @Field("password") password: String?
    ): Call<JsonObject>

    @POST("withdrawal-request")
    @FormUrlEncoded
    fun withdrawal(
        @Field("user_id") user_id: String?,
        @Field("amount") amount: String?,
        @Field("upi_address") upi_address: String?,
        @Field("ifsc_code") ifsc_code: String?,
        @Field("account_holder_name") account_holder_name: String?,
        @Field("account_no") account_no: String?,
        @Field("bank_name") bank_name: String?,
        @Field("branch_name") branch_name: String?
    ): Call<JsonObject>

    @GET("withdrawal-request-member/{id}")
    fun withdrawal_request_member(
        @Path("id") id: String?
    ): Call<JsonObject>

    @POST("update-booked-order-status/{orderno}/{status}")
    fun booked_order_status(
        @Path("orderno") orderno: String?,
        @Path("status") status: String?
    ): Call<JsonObject>


    @POST("company-pay")
    @FormUrlEncoded
    fun company_pay(
        @Field("servicepoint")servicePoint:String?,
        @Field("vendor_id") vendor_id: String?,
        @Field("description") description: String?,
        @Field("txn_id") txn_id: String?,
        @Field("amount") amount: String?,
        @Field("vendorservice_id") vendorservice_id: String?,
        @Field("status") status: String?
    ): Call<JsonObject>

    @GET("search/{service_name}")
    fun Search(
        @Path("service_name") service_name: String?
    ): Call<JsonObject>

    @GET("company-pay-details/{id}")
    fun vendortransationhistory(
        @Path("id") id: String?
    ): Call<JsonObject>

    @GET("point-pay-user/{user_id}")
    fun usercardtransationhistory(
        @Path("user_id") user_id: String?
    ): Call<JsonObject>

    @GET("point-pay-vendor/{vendor_id}")
    fun vendorcardtransationhistory(
        @Path("vendor_id") vendor_id: String?
    ): Call<JsonObject>

    @GET("fetch-vendor-approve-point-service-list/{vid}/{type}")
    fun servicestype(
        @Path("vid") id: String?,
        @Path("type") type: String?
    ): Call<JsonObject>



    @GET("point-pay-user-qrcode/{id}")
    fun vendorqrCodetransationhistory(
        @Path("id") id: String?
    ): Call<JsonObject>
}

