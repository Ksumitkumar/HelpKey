package com.helpkey.service.UserActivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Toast
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.R
import com.helpkey.service.VendorActivity.VendorDashbordActivity
import com.helpkey.service.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONException
import retrofit2.Call
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    var type = ""
    lateinit var binding: ActivityMainBinding
    var prefrenceManager: PrefrenceManger1? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefrenceManager = PrefrenceManger1(applicationContext)
        type = prefrenceManager?.gettype(applicationContext).toString()
        Log.e("fkdj", prefrenceManager?.getUserid(applicationContext).toString())

        val slideAnimation = AnimationUtils.loadAnimation(this, R.anim.slideanimation)
        binding.main.startAnimation(slideAnimation)

//                1.any id approval
//                2.delete service or point request
//                3.search on address

        Handler(Looper.getMainLooper()).postDelayed({

            if (prefrenceManager?.getUserid(applicationContext).equals("0")) {
                var intent = Intent(this@MainActivity, SelectuserTypeActivity::class.java)
                startActivity(intent)
            } else {
                user_status()
            }

        }, 500)

    }

    fun user_status() {
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.check_user(prefrenceManager?.getUserid(applicationContext))
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e("checkUser_response", response.body().toString())
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val type = jsonObject.getString("type")
                        val status = jsonObject.getString("user_status")

                        if (status.equals("Active")) {
                            checkuser()
                        } else {
                            var intent =
                                Intent(this@MainActivity, SelectuserTypeActivity::class.java)
                            intent.putExtra("address", "main")
                            startActivity(intent)
                        }

                    } else {
                        var intent = Intent(this@MainActivity, SelectuserTypeActivity::class.java)
                        startActivity(intent)
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("checkUser_exe", e.toString())
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("checkUser_error", t.toString())
                if (t.equals("java.net.SocketTimeoutException: Read timed out")) {
                    Toast.makeText(this@MainActivity, "Server Down Please Wait", Toast.LENGTH_SHORT)
                        .show()
                } else {

                }
            }

        })
    }

    private fun checkuser() {
        binding.progress.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.userverification(prefrenceManager?.getmobilno(applicationContext), type)
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    Log.e(
                        "checkuser_data",
                        response.body().toString() + "" + prefrenceManager?.getmobilno(
                            applicationContext
                        ) + "" + type
                    )
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        if (type == "user") {
                            intent = Intent(applicationContext, DashbordActivity::class.java)
//                            intent = Intent(applicationContext, UserRegitrationActivity::class.java)
                            startActivity(intent)
                            finish()
                        } else if (type == "vendor") {
                            //VendorDasbordActivity
                            intent = Intent(applicationContext, VendorDashbordActivity::class.java)
                            startActivity(intent)
                            finish()
                        }
                    } else {
                        if (type == "user") {
                            intent = Intent(applicationContext, SelectuserTypeActivity::class.java)
                            intent.putExtra("typenumber", "userrrr")
                            startActivity(intent)
                        } else if (type == "vendor") {
                            intent = Intent(applicationContext, SelectuserTypeActivity::class.java)
                            intent.putExtra("typenumber", "vendorrrr")
                            startActivity(intent)
                        } else {
                            intent = Intent(applicationContext, SelectuserTypeActivity::class.java)
                            intent.putExtra("typenumber", "null")
                            startActivity(intent)
                        }

                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("checkuser_ex", e.toString())
                    binding.progress.visibility = View.GONE
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("checkuser_ex", t.toString())
                binding.progress.visibility = View.GONE

            }

        })
    }
}