package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CartModel {
    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("price")
    @Expose
    var price: String? = null

    @SerializedName("servicename")
    @Expose
    var servicename: String? = null

    @SerializedName("user_id")
    @Expose
    var user_id: Int? = null

    @SerializedName("cart_id")
    @Expose
    var cart_id: Int? = null

    @SerializedName("serviceimage")
    @Expose
    var serviceimage: String? = null

    constructor(
        description: String?,
        price: String?,
        servicename: String?,
        user_id: Int?,
        cart_id: Int?,
        serviceimage: String?
    ) {
        this.description = description
        this.price = price
        this.servicename = servicename
        this.user_id = user_id
        this.cart_id = cart_id
        this.serviceimage = serviceimage
    }
}