package com.helpkey.service.VendorActivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.razorpay.Checkout
import com.razorpay.PaymentData
import com.razorpay.PaymentResultWithDataListener
import com.helpkey.service.Adapter.VendorTransitionHistoryAdapter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.PaymentServiceModel
import com.helpkey.service.Models.VendorTransitionHistoryModel
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityPayHelpkeyBinding
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PayHelpkeyActivity : AppCompatActivity(), PaymentResultWithDataListener {
    var serviceType="Service"
    lateinit var binding: ActivityPayHelpkeyBinding
    var prefrenceManager: PrefrenceManger1? = null
    var vendorTransitionHistoryModel: ArrayList<VendorTransitionHistoryModel> = ArrayList()
    var services = ArrayList<String>()
    var services_id = ArrayList<String>()
    var vendorservice_id = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPayHelpkeyBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefrenceManager = PrefrenceManger1(applicationContext)
        Checkout.preload(applicationContext)
        binding.empaty.setAnimation(R.raw.datanotfound)

        binding.back.setOnClickListener {
            if (binding.vendorhistoryLayout.isVisible) {
                binding.history.isEnabled = true
                binding.vendorhistoryLayout.visibility = View.GONE
                binding.pay.visibility = View.VISIBLE
                binding.mainLayout.visibility = View.VISIBLE
            } else {
                finish()
            }
        }
        servicetype("2")
        binding.radiogroup.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->

            val radio: RadioButton = group.findViewById(checkedId)

            if (radio.text.toString() == "Services") {
                serviceType = "Service"
                servicetype("2")
            } else {
                serviceType = "Point"
                servicetype("1")
            }


        })

        binding.pay.setOnClickListener {
            if (validation()) {
                VendorPayment()
            } else {
                Toast.makeText(this@PayHelpkeyActivity, "Please Fill All Field", Toast.LENGTH_SHORT)
                    .show()
            }
        }
        binding.history.setOnClickListener{
            binding.vendorhistoryLayout.visibility = View.VISIBLE
            binding.pay.visibility = View.GONE
            binding.mainLayout.visibility = View.GONE
            transitionHistory()
        }
        binding.thankBtn.setOnClickListener {
            binding.thanks.visibility = View.GONE
            binding.thankBtn.visibility = View.GONE
            binding.pay.visibility = View.VISIBLE
        }
    }

    fun servicetype(s: String) {
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonObject> = getDataService.servicestype(prefrenceManager?.getUserid(applicationContext),s)
        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("ser_res", response.body().toString())
                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonObject2 = jsonObject.getJSONArray("data")
                        services.clear()
                        services_id.clear()
                        for (i in 0 until jsonObject2.length()) {
                            val model: PaymentServiceModel = Gson().fromJson(
                                jsonObject2.getString(i).toString(),
                                PaymentServiceModel::class.java
                            )
                            services.add(model.servicename.toString())
                            services_id.add(model.id.toString())
                        }
                        val aa = ArrayAdapter(
                            this@PayHelpkeyActivity,
                            android.R.layout.simple_spinner_item,
                            services
                        )
                        // Set layout to use when the list of choices appear
                        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        // Set Adapter to Spinner
                        binding.spinner.adapter = aa

                        binding.spinner.onItemSelectedListener = object :
                            AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(
                                parent: AdapterView<*>,
                                view: View, position: Int, id: Long
                            ) {
                                vendorservice_id = services_id[position]
                            }
                            override fun onNothingSelected(parent: AdapterView<*>) {
                            }
                        }
                    } else {

                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("ser_exe", response.body().toString())
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("ser_error", t.toString())
            }

        })

    }

    private fun VendorPayment() {

        val co = Checkout()

        try {
            val options = JSONObject()
            options.put("name", "HelpKey App")
            options.put("description", prefrenceManager?.getName(applicationContext))
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png")
            options.put("theme.color", "#3399cc")
            options.put("currency", "INR")
            options.put(
                "amount",
                binding.amount.text.toString() + "00"
            )
            val prefill = JSONObject()
            prefill.put("email", prefrenceManager?.getemail(applicationContext))
            prefill.put("contact", prefrenceManager?.getmobilno(applicationContext))
            options.put("prefill", prefill)
            co.open(this@PayHelpkeyActivity, options)
            Log.e("opstion", options.toString())
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("exception_err", e.toString())
        }
    }


    override fun onPaymentSuccess(razorpayPaymentID: String?, paymentData: PaymentData?) {

        var status = "Success"
        if (paymentData != null) {
            try {
                company_pay(razorpayPaymentID.toString(), status)
            } catch (e: Exception) {
                Log.e("payment", e.toString())

            }

        }

    }

    override fun onPaymentError(p0: Int, razorpayPaymentID: String?, paymentData: PaymentData?) {
        var status = "Failed"
        if (paymentData != null) {
            try {
                company_pay("Payment processing cancelled by user", status)
            } catch (e: Exception) {
                Log.e("payment", e.toString())

            }

        }
    }

    fun company_pay(razorpayPaymentID: String, status: String) {



        val pay: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> = pay.company_pay(serviceType,
            prefrenceManager?.getUserid(applicationContext),
            binding.description.text.toString(),
            razorpayPaymentID,
            binding.amount.text.toString(),
            vendorservice_id,
            status
        )
        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e("Pay_res", response.body().toString())
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        if (status == "Success") {
                            binding.thanks.visibility = View.VISIBLE
                            binding.thankBtn.visibility = View.VISIBLE
                            binding.pay.visibility = View.GONE
                            binding.description.setText("")
                            binding.amount.setText("")
                            Toast.makeText(
                                this@PayHelpkeyActivity,
                                "Data Save Successfully",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            binding.animation.setAnimation(R.raw.failed)
                            binding.thanks.visibility = View.VISIBLE
                            binding.thankBtn.visibility = View.VISIBLE
                            binding.pay.visibility = View.GONE
                            binding.description.setText("")
                            binding.txtbook.text = "Failed"
                            binding.thangsDescription.text = ""
                            binding.amount.setText("")
                        }

                    } else {
                        Toast.makeText(
                            this@PayHelpkeyActivity,
                            "Payment Failed",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                } catch (e: JSONException) {
                    Log.e("Pay_exe", e.toString())
                }

            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("Pay_err", t.toString())
            }

        })
    }

    fun transitionHistory() {
        vendorTransitionHistoryModel.clear()
        binding.progressBar.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.vendortransationhistory(prefrenceManager?.getUserid(applicationContext))
        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("transition_response", response.body().toString())
                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    var res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.history.isEnabled = false
                        binding.progressBar.visibility = View.GONE
                        val jsonArray = jsonObject.getJSONArray("data")
                        if (jsonArray.length() > 0) {
                            for (i in 0 until jsonArray.length()) {
                                var transition: VendorTransitionHistoryModel = Gson().fromJson(
                                    jsonArray.getString(i).toString(),
                                    VendorTransitionHistoryModel::class.java
                                )
                                vendorTransitionHistoryModel.add(transition)
                            }
                        } else {
                            binding.progressBar.visibility = View.GONE
                            binding.empaty.visibility = View.VISIBLE
                        }

                    } else {
                        binding.progressBar.visibility = View.GONE
                    }

                    var adpter3 = VendorTransitionHistoryAdapter(
                        vendorTransitionHistoryModel,
                        applicationContext
                    )
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.transitionHistory.layoutManager = layoutManager
                    binding.transitionHistory.setHasFixedSize(true)
                    binding.transitionHistory.adapter = adpter3

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("transition_exe", e.toString())
                    binding.progressBar.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("transition_error", t.toString())
                binding.progressBar.visibility = View.GONE
            }

        })
    }

    fun validation(): Boolean {
        if (binding.amount.text.toString().trim().isEmpty()) {
            binding.amount.error = "Enter Your Amount"
            binding.amount.requestFocus()
        } else if (binding.description.text.toString().trim().isEmpty()) {
            binding.description.error = "Enter Your Description"
            binding.description.requestFocus()
        } else {
            return true
        }
        return false
    }

    override fun onBackPressed() {
        if (binding.vendorhistoryLayout.isVisible) {
            binding.history.isEnabled = true
            binding.vendorhistoryLayout.visibility = View.GONE
            binding.pay.visibility = View.VISIBLE
            binding.mainLayout.visibility = View.VISIBLE
        } else {
            super.onBackPressed()
        }
    }
}