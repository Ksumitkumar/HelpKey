package com.helpkey.service.VendorActivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.helpkey.service.Adapter.VendorTodayorderAdapter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.VendorAllOrderRequestModel
import com.helpkey.service.databinding.ActivityViewAllBinding
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response

class ViewAllActivity : AppCompatActivity() {

    lateinit var binding:ActivityViewAllBinding
    var vendorAllOrderRequestModel: ArrayList<VendorAllOrderRequestModel> =
        ArrayList()
    var prefrenceManager: PrefrenceManger1? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding=ActivityViewAllBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefrenceManager = PrefrenceManger1(applicationContext)

        binding.back.setOnClickListener(View.OnClickListener { finish() })

        venderPendinngServices()

    }
    fun venderPendinngServices() {
        binding.progressBar.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.vendorUncompleteService(
                prefrenceManager?.getUserid(applicationContext)
            )

        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e("Vallrequest_response", response.body().toString())

                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progressBar.visibility = View.GONE
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Log.e("Vallrequest", jsonObject.toString())
                        if (jsonArray1.length() > 0) {
                            for (i in 0 until jsonArray1.length()) {
                                val vendarSModel: VendorAllOrderRequestModel = Gson().fromJson(
                                    jsonArray1.getString(i).toString(),
                                    VendorAllOrderRequestModel::class.java
                                )
                                vendorAllOrderRequestModel.add(vendarSModel)
                            }
                        } else {
                            Toast.makeText(this@ViewAllActivity,"Data not Fount",Toast.LENGTH_SHORT).show()
                        }


                    } else {
                        binding.progressBar.visibility = View.GONE
                        binding.empaty.visibility = View.VISIBLE
                    }

                    var adpter3 = VendorTodayorderAdapter(vendorAllOrderRequestModel, applicationContext)
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.pendingRecylview.layoutManager = layoutManager
                    binding.pendingRecylview.setHasFixedSize(true)
                    binding.pendingRecylview.adapter = adpter3

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("Vallrequest_ex", e.toString())
                    binding.progressBar.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("Vallrequest_error", t.toString())
                binding.progressBar.visibility = View.GONE
            }
        })
    }
}