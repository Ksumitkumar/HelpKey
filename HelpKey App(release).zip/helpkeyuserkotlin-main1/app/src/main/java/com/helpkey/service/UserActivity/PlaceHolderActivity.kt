package com.helpkey.service.UserActivity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityPlaceHolderBinding
import org.json.JSONArray
import org.json.JSONException
import retrofit2.Call
import retrofit2.Response


class PlaceHolderActivity : AppCompatActivity() {
    lateinit var binding: ActivityPlaceHolderBinding
    var PaymentMethod = ""
    var prefrenceManager: PrefrenceManger1? = null
    var totalamount = ""
    var selectedtriptype = 0

    companion object {
        lateinit var activity: Activity
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlaceHolderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        activity = this

        prefrenceManager = PrefrenceManger1(applicationContext)

        prefrenceManager!!.getaddressid(applicationContext)?.let { 
            getAddress(it) }

        binding.back.setOnClickListener { finish() }

        binding.itemcont.text = Constracter.itemcount
        binding.amouts.text = Constracter.amont

        try {
            totalamount = ((0) + (Constracter.amont.toInt())).toString()
            binding.totalamounts.text = totalamount
            if (totalamount.toDouble() <= 0) {
                binding.online.visibility = View.GONE
                binding.view1.visibility = View.GONE
            } else {
                binding.online.visibility = View.VISIBLE
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        binding.changeAddres.setOnClickListener {
            var intent = Intent(this, SelectAddressActivity::class.java)
            startActivity(intent)
        }

        binding.codimage.setImageResource(R.drawable.ic_baseline_check_circle_24)
        binding.wallet.setBackgroundResource(0)
        binding.walletimage.setImageResource(R.drawable.ic_baseline_panorama_fish_eye_24)
        binding.online.setBackgroundResource(0)
        binding.onlineimage.setImageResource(R.drawable.ic_baseline_panorama_fish_eye_24)
        binding.walletdiscount.visibility = View.GONE
        PaymentMethod = "cod"

        binding.online.setOnClickListener(View.OnClickListener {
            binding.onlineimage.setImageResource(R.drawable.ic_baseline_check_circle_24)
            binding.wallet.setBackgroundResource(0)
            binding.walletimage.setImageResource(R.drawable.ic_baseline_panorama_fish_eye_24)
            binding.cod.setBackgroundResource(0)
            binding.codimage.setImageResource(R.drawable.ic_baseline_panorama_fish_eye_24)
            selectedtriptype = 2
            PaymentMethod = "online"
            binding.walletdiscount.visibility = View.GONE
            //                startPayment();
            binding.buyNowTxt.text = "Pay Now"
        })

        binding.cod.setOnClickListener(View.OnClickListener {
            binding.codimage.setImageResource(R.drawable.ic_baseline_check_circle_24)
            binding.wallet.setBackgroundResource(0)
            binding.walletimage.setImageResource(R.drawable.ic_baseline_panorama_fish_eye_24)
            binding.online.setBackgroundResource(0)
            binding.onlineimage.setImageResource(R.drawable.ic_baseline_panorama_fish_eye_24)
            selectedtriptype = 3
            PaymentMethod = "cod"
            // binding.charge(digi.coders.LDWClub.Activity.PlaceOrder.showaddressModels.get(0).getAddressId())
            binding.walletdiscount.visibility = View.GONE
            binding.buyNowTxt.text = "Place Order"
        })

        binding.buynow.setOnClickListener {
            book_address()
        }

    }


    fun getAddress(address_id: String) {

        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonArray> = getDataService.fetch_address(
            address_id
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e("seletadd_res", response.body().toString())
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonArray = jsonObject.getJSONArray("data")
                        val jsonObject = jsonArray.getJSONObject(0)

                        binding.personanme.text = jsonObject.getString("address")

                    } else {
//                        var intent = Intent(applicationContext, SelectAddressActivity::class.java)
//                        startActivity(intent)

                    }


                } catch (e: Exception) {
                    Log.e("seletadd_error", e.toString())

                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("seletadd_error", t.toString())
            }

        })

    }

    fun book_address() {
        if(binding.personanme.text.toString().isEmpty()){
            Toast.makeText(this@PlaceHolderActivity, "Please enter address", Toast.LENGTH_SHORT).show()
        }else{
            val getDataService: GetDataService =
                RetrofitClintanse.getInstance().create(GetDataService::class.java)
            val call: Call<JsonArray> = getDataService.add_book_now(
                prefrenceManager?.getUserid(applicationContext),
                prefrenceManager?.getaddressid(applicationContext),
                PaymentMethod,
                totalamount
            )
            call.enqueue(object : retrofit2.Callback<JsonArray> {
                override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                    try {
                        Log.e(
                            "book_res",
                            response.body().toString() + " " + PaymentMethod + " " + totalamount
                                    + " " + prefrenceManager?.getUserid(applicationContext) + " " + prefrenceManager?.getaddressid(
                                applicationContext
                            )
                        )
                        val jsonArray = JSONArray(Gson().toJson(response.body()))
                        val jsonObject = jsonArray.getJSONObject(0)
                        val res = jsonObject.getString("status")
                        if (res.equals("success")) {

                            when (PaymentMethod) {
                                "online" -> {
                                    val mainIntent = Intent(
                                        this@PlaceHolderActivity,
                                        PayemetgetwayActivity::class.java
                                    )
                                    mainIntent.putExtra("orderid", jsonObject.getString("data"))
                                    mainIntent.putExtra("price", totalamount)
                                    startActivity(mainIntent)
                                    finish()
                                }
                                "cod" -> {
                                    val intent = Intent(
                                        this@PlaceHolderActivity,
                                        OrderSuccessActivity::class.java
                                    )
                                    intent.putExtra("orderid", jsonObject.getString("data"))
                                    startActivity(intent)
                                    finish()
                                }
                            }

                        } else {

                        }

                    } catch (e: JSONException) {
                        e.printStackTrace()
                        Log.e("book_ex", e.toString())
                    }
                }

                override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                    Log.e("book_res", t.toString())

                }
            })
        }


    }

    override fun onRestart() {
        super.onRestart()
        prefrenceManager!!.getaddressid(applicationContext)?.let { getAddress(it) }
        binding.itemcont.text = Constracter.itemcount
        binding.amouts.text = Constracter.amont
        totalamount = ((20) + (Constracter.amont.toInt())).toString()
    }
}