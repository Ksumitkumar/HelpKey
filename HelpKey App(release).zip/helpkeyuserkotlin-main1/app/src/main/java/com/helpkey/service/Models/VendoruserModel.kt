package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class VendoruserModel {

    @SerializedName("id")
    @Expose
    var id: Int? = null

  @SerializedName("cateName")
    @Expose
    var cateName: String? = null
    @SerializedName("vendor_name")
    @Expose
    var vendor_name: String? = null

    @SerializedName("image")
    @Expose
    var image: String? = null
    @SerializedName("vendorId")
    @Expose
    var vendorId: Int? = null

    @SerializedName("serviceimage")
    @Expose
    var serviceimage: String? = null

    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("address")
    @Expose
    var address: String? = null


    constructor(
        id: Int?,
        image: String?,
        cateName: String?,
        serviceimage: String?,
        vendorId: Int?,
        description: String?,
        address: String?,
    ) : super() {
        this.id = id
        this.image = image
        this.cateName = cateName
        this.serviceimage = serviceimage
        this.vendorId = vendorId
        this.description = description
        this.address = address


    }
}