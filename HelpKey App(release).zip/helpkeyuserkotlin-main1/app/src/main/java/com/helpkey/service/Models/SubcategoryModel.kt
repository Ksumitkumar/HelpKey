package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SubcategoryModel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("category")
    @Expose
    var category: String? = null

    @SerializedName("image")
    @Expose
    var image: String? = null

    @SerializedName("sub_category")
    @Expose
    var sub_category: String? = null


    constructor(
        id: Int?,
        category: String?,
        image: String?,
        sub_category: String?

        ) : super() {
        this.id = id

        this.category = category

        this.image = image

        this.sub_category = sub_category
    }
}