package com.helpkey.service.VendorActivity

import Categorymodel
import android.R
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.android.gms.common.api.Status
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.widget.AutocompleteSupportFragment
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.squareup.picasso.Picasso
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.Refresh
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.SubcategoryModel
import com.helpkey.service.UserActivity.EditeActivity
import com.helpkey.service.databinding.ActivityAddServiceBinding
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.json.JSONArray
import org.json.JSONException
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.util.*
import kotlin.collections.ArrayList


class AddServiceActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener, Refresh {
    var currentLat: Double = 0.0
    var upiPinDetails=""
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    var currentLong: Double = 0.0
    var location = "address"
    var geocoder: Geocoder? = null
    var addresses: List<Address>? = null
    lateinit var binding:ActivityAddServiceBinding
    var categoryid = ""
    var subcategoryid = ""
    var servicesadd = ""
    var serviceid = ""
    var cetagory_id = ""
    var uri1 = Uri.parse("")
    var uri = Uri.parse("")
    var pdfuri = Uri.parse("")
    var category = ""
    var list = ArrayList<String>()
    var list_id = ArrayList<String>()
    var sub_list = ArrayList<String>()
    var sub_list_id = ArrayList<String>()
    var prefrenceManager: PrefrenceManger1? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityAddServiceBinding.inflate(layoutInflater)
        setContentView(binding.root)
        fusedLocationProviderClient =
            LocationServices.getFusedLocationProviderClient(this@AddServiceActivity)
        Places.initialize(applicationContext, "AIzaSyCkPVrOq6BI6MotAkt-0iXV_vht5jwlU04")
        geocoder = Geocoder(this, Locale.getDefault())
        prefrenceManager = PrefrenceManger1(applicationContext)
        binding.back.setOnClickListener { finish() }
        accountDetails()
        servicesadd = intent.getStringExtra("serviceUpdate").toString()
        binding.vendorName.setText(prefrenceManager?.getName(applicationContext))
        cetagory_id = intent.getStringExtra("cat_id").toString()
        val autocompleteFragment =
            supportFragmentManager.findFragmentById(com.helpkey.service.R.id.autocomplete_fragment) as AutocompleteSupportFragment?

        (autocompleteFragment ?: return).setPlaceFields(
            listOf(
                Place.Field.ID,
                Place.Field.NAME,
                Place.Field.LAT_LNG,
                Place.Field.ADDRESS,
                Place.Field.PLUS_CODE
            )
        ).setCountry("IN")
        autocompleteFragment.setHint("Address")

        autocompleteFragment.setOnPlaceSelectedListener(object : PlaceSelectionListener {
            override fun onPlaceSelected(place: Place) {

                Log.e(
                    "search_location_saved",
                    place.name + " " +
                            place.address + " " +
                            place.latLng.latitude.toString() + "  " +
                            place.latLng.longitude.toString() + "  " +
                            place.address.toString()
                )
                val geocoder: Geocoder
                val addresses: List<Address>?
                geocoder = Geocoder(this@AddServiceActivity, Locale.getDefault())

                addresses = geocoder.getFromLocation(
                    place.latLng.latitude,
                    place.latLng.longitude,
                    1
                ) // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                prefrenceManager!!.setlatitude(
                    place.latLng.latitude.toString(),
                    this@AddServiceActivity
                )
                prefrenceManager!!.setlongitude(
                    place.latLng.longitude.toString(),
                    this@AddServiceActivity
                )
                try {
                    val address: kotlin.String =
                        addresses!![0].getAddressLine(0) // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()

                    val city: kotlin.String = addresses[0].locality
                    val state: kotlin.String = addresses[0].adminArea
                    val country: kotlin.String = addresses[0].countryName
                    val postalCode: kotlin.String = addresses[0].postalCode
                    val knownName: kotlin.String = addresses[0].featureName
                    binding.vendorAddress.setText(city)



                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("location", e.toString())
                }

            }

            override fun onError(status: Status) {
                status.status


            }
        })
        Category_user()
        profile_view()

        when (servicesadd) {
            "servicesAdd" -> {
                binding.addService.setOnClickListener {
                    addvendorservices(it)
                }
            }
            "2" -> {

                binding.vendorEmail.visibility = View.GONE
                binding.document.visibility = View.GONE
                binding.discount.visibility = View.GONE
                binding.vendorMobile.setText(prefrenceManager?.getmobilno(applicationContext).toString())
                binding.addService.setOnClickListener {
                    if (uri1.path == "") {
                        Toast.makeText(this@AddServiceActivity,"Please Upload cover Image",Toast.LENGTH_SHORT).show()
                    } else if (uri.path == "") {
                        Toast.makeText(this@AddServiceActivity,"Please Upload Service Image",Toast.LENGTH_SHORT).show()
                    } else  {
                        addvendorservice(it)
                    }
                }
            }
            "1" -> {
                binding.serviceName.hint = "Organization Name"
                binding.vendorAddress.hint = "Organization Address"
                binding.serviceDescription.hint = "Organization Description"
                binding.vendorMobile.hint = "Organization Mobile"
                binding.vendorEmail.hint = "Organization Email"
                binding.servicePrice.visibility = View.GONE
                binding.discount.visibility = View.GONE
                binding.vendorName.visibility = View.GONE
                binding.addService.setOnClickListener {
                    if (uri.path == "") {
                        Toast.makeText(this@AddServiceActivity,"Please Upload cover Image",Toast.LENGTH_SHORT).show()
                    } else if (uri1.path == "") {
                        Toast.makeText(this@AddServiceActivity,"Please Upload Profile Image",Toast.LENGTH_SHORT).show()
                    } else  {
                        addvendorservices(it)
                    }
                }
            }
            "servicesAdapter" -> {
                serviceid = intent.getStringExtra("id").toString()

                Log.e(
                    "description",
                    intent.getStringExtra("pimg") + " " + intent.getStringExtra("cimg")
                )
                binding.serviceName.setText(intent.getStringExtra("sname"))
                binding.vendorName.setText(intent.getStringExtra("vname"))
                binding.servicePrice.setText(intent.getStringExtra("pname"))
                binding.vendorAddress.setText(intent.getStringExtra("aname"))
                binding.serviceDescription.setText(intent.getStringExtra("dname"))
                Picasso.get().load(
                    "https://panels.helpkey.in/public/images/coverimage/" +
                            intent.getStringExtra("pimg")
                ).placeholder(R.drawable.stat_notify_error).into(binding.profileImage)
                Picasso.get().load(
                    "https://panels.helpkey.in/public/images/serviceimage/" +
                            intent.getStringExtra("cimg")
                ).placeholder(R.drawable.stat_notify_error).into(binding.coverImage)

                binding.addService.setOnClickListener {
                    updateservice(it)
                }
            }
        }



        binding.documenttxt.setOnClickListener {
            ImagePicker.with(this)
                .crop()                    //Crop image(Optional), Check Customization for more option
                .compress(1024)            //Final image size will be less than 1 MB(Optional)
                .maxResultSize(
                    1080,
                    1080
                )
                .start(12)
        }

        binding.coverpic.setOnClickListener {
            ImagePicker.with(this)
                .crop()                    //Crop image(Optional), Check Customization for more option
                .compress(1024)            //Final image size will be less than 1 MB(Optional)
                .maxResultSize(
                    1080,
                    1080
                )
                .start(1)
            //Final image resolution will be less than 1080 x 1080(Optional)

        }

        binding.profilepic.setOnClickListener {
            ImagePicker.with(this)
                .crop()                    //Crop image(Optional), Check Customization for more option
                .compress(1024)            //Final image size will be less than 1 MB(Optional)
                .maxResultSize(
                    1080,
                    1080
                )
                //Final image resolution will be less than 1080 x 1080(Optional)
                .start(2)
        }
    }

    private fun accountDetails() {
        val list1=ArrayList<String>()
        list1.add(("Account Number"))
        list1.add("UPI Number")

        val aaa = ArrayAdapter(
            this@AddServiceActivity,
            R.layout.simple_spinner_item,
            list1
        )
        // Set layout to use when the list of choices appear
        aaa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        // Set Adapter to Spinner
        binding.accountDetailsSpinner.adapter = aaa
        upiPinDetails=list1.get(0).toString()

        binding.accountDetailsSpinner.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View, position: Int, id: Long
            ) {

                upiPinDetails=list1.get(position).toString()
                if(list1.get(position).equals("Account Number")){
                    binding.accountHolderName.visibility=View.VISIBLE
                    binding.ifscCode.visibility=View.VISIBLE
                    binding.accountNumber.visibility=View.VISIBLE
                    binding.upiPin.visibility=View.GONE
                }else{
                    binding.accountHolderName.visibility=View.GONE
                    binding.ifscCode.visibility=View.GONE
                    binding.accountNumber.visibility=View.GONE
                    binding.upiPin.visibility=View.VISIBLE
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>) {

            }
        }




    }

    @SuppressLint("Range")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && data != null) {
            Log.e("jdh", requestCode.toString())
            when (requestCode) {

                1 -> {
                    uri1 = data.data
                    binding.coverImage.setImageURI(uri1)
                    Log.e("pdf",uri1.path.toString())
                }
                2 -> {
                    uri = data.data
                    Log.e("jd", uri.toString())
                    binding.profileImage.setImageURI(uri)
                }
                12 -> {
                    pdfuri = data.data!!
                    binding.documenttxt.setText(pdfuri.path.toString())
                    Log.e("pdf", pdfuri.path.toString())
                }
            }

        } else if (resultCode == ImagePicker.RESULT_ERROR) {
            Toast.makeText(this, ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Task Cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    fun profile_view() {
        val getDataServices: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataServices.view_profile(
            prefrenceManager?.getUserid(applicationContext)
        )
        Log.e("userid",prefrenceManager?.getUserid(applicationContext).toString())
        call.enqueue(object : Callback<JsonArray> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e("profile_response", jsonArray.toString())
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonArray1 = jsonObject.getJSONObject("data")
                        var name = jsonArray1.getString("username")


                    } else {

                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("profile_error", e.toString())
                    if (e.toString() == "org.json.JSONException: No value for username") {
                        val mdliog = LayoutInflater.from(this@AddServiceActivity)
                            .inflate(com.helpkey.service.R.layout.update_profile, null)
                        val muBulder = AlertDialog.Builder(this@AddServiceActivity)
                            .setView(mdliog)
                        muBulder.setCancelable(false)
                        val maliert = muBulder.show()
                        val yes = mdliog.findViewById<TextView>(com.helpkey.service.R.id.yes)
                        val no = mdliog.findViewById<TextView>(com.helpkey.service.R.id.no)
                        val txt = mdliog.findViewById<TextView>(com.helpkey.service.R.id.txt)


                        yes.text = "Update"
                        txt.text = "Please Upload Your Profile"
                        yes.setOnClickListener {
                            startActivity(Intent(this@AddServiceActivity,EditeActivity::class.java)
                                .putExtra("address","vendor"))
                            finish()
                            maliert.dismiss()
                        }
                        no.setOnClickListener {
                            startActivity(Intent(this@AddServiceActivity,VendorDashbordActivity::class.java))
                            finish()
                            maliert.dismiss() }
                    } else {

                    }

                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("profile_error", t.toString())

            }

        })

    }

    fun addvendorservices(it: View) {
        Log.e("ccatidssssss", "$categoryid $subcategoryid")
        if (binding.serviceName.text.toString() == ""){
            Toast.makeText(this@AddServiceActivity,"Please fill all fields",Toast.LENGTH_SHORT).show()
        }else if(binding.vendorName.text.toString() == ""){
            Toast.makeText(this@AddServiceActivity,"Please fill all fields",Toast.LENGTH_SHORT).show()
        }else if(binding.vendorMobile.text.toString() == ""){
            Toast.makeText(this@AddServiceActivity,"Please fill all fields",Toast.LENGTH_SHORT).show()
        }else if(binding.vendorEmail.text.toString() == "") {
            Toast.makeText(this@AddServiceActivity, "Please fill all fields", Toast.LENGTH_SHORT).show()
        }  else if(!checkPaymentType()) {
            Toast.makeText(this@AddServiceActivity,"Please fill account/upi details fields",Toast.LENGTH_SHORT).show()
        }else  if(binding.serviceDescription.text.toString() == ""){
            Toast.makeText(this@AddServiceActivity,"Please fill all fields",Toast.LENGTH_SHORT).show()
        } else {
            val progress = ProgressDialog(this)
//        progress.setTitle("Loading")
            progress.setMessage("Loading...")
            progress.setCancelable(false)
            progress.show()
            val file = File(uri.path)
            val file1 = File(uri1.path)
            val pdf = File(pdfuri.path)
            val requestFile = RequestBody.create(MediaType.parse("*/*"), file)
            val requestFile1 = RequestBody.create(MediaType.parse("*/*"), file1)
            val pdfrequestFile = RequestBody.create(MediaType.parse("*/*"), pdf)
            val profile_img = MultipartBody.Part.createFormData("serviceimage", uri.path, requestFile)
            val coverimage = MultipartBody.Part.createFormData("coverimage", uri1.path, requestFile1)
            val pdffile = MultipartBody.Part.createFormData("document", pdfuri.path, pdfrequestFile)

            Log.e("imagesspath", uri1.path ?: return)
            Log.e("imagesspath1", uri.path ?: return)
            Log.e("imagesspath1", pdfuri.path ?: return)

            val getDataService: GetDataService =
                RetrofitClintanse.getInstance().create(GetDataService::class.java)
            val call: Call<JsonArray> =
                getDataService.addvendorservices(
                    prefrenceManager?.getUserid(applicationContext).toString(),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        cetagory_id
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.vendorMobile.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.vendorEmail.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.serviceName.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.vendorName.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.servicePrice.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.discount.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.vendorAddress.text.toString()
                    ),  RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        prefrenceManager?.getlatitude(this@AddServiceActivity).toString(),
                    ), RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        prefrenceManager?.getlongitude(this@AddServiceActivity).toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        categoryid
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        subcategoryid
                    ),
                    coverimage,
                    profile_img,
                    pdffile,

                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.serviceDescription.text.toString()
                    ), RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.accountNumber.text.toString()
                    ),  RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.accountHolderName.text.toString()
                    ),  RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.ifscCode.text.toString()
                    ),  RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.upiPin.text.toString()
                    ))
            Log.e("userid", prefrenceManager?.getUserid(applicationContext).toString())
            call.enqueue(object : Callback<JsonArray> {
                override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                    try {
                        Log.e("update_res", response.body().toString())
                        Log.e(
                            "all_data",
                            prefrenceManager?.getUserid(applicationContext)
                                .toString() + " " + binding.serviceName.text.toString() + " " +
                                    binding.vendorName.text.toString() + " " + binding.servicePrice.text.toString() + " " + binding.vendorAddress.text.toString() + " " +
                                    coverimage + " " +
                                    categoryid + " " +
                                    subcategoryid + " " +
                                    profile_img + "  " + binding.serviceDescription.text.toString()
                        )

                        val jsonArray = JSONArray(Gson().toJson(response.body()))
                        val jsonObject = jsonArray.getJSONObject(0)
                        val res = jsonObject.getString("status")
                        if (res.equals("success")) {

                            Toast.makeText(this@AddServiceActivity,"Please Wait For Admin Approval",Toast.LENGTH_SHORT).show()


                            progress.dismiss()
                            finish()

                        } else {

                            val snack =
                                Snackbar.make(it, jsonObject.getString("errors"), Snackbar.LENGTH_LONG)
                            snack.setBackgroundTint(
                                ContextCompat.getColor(
                                    applicationContext,
                                    R.color.holo_red_dark
                                )
                            )
                            snack.show()

                            progress.dismiss()
                        }

                    } catch (e: Exception) {
                        Log.e("update_ex", e.toString())
                        progress.dismiss()
                    }

                }

                override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                    Log.e("update_error", t.toString())
                    progress.dismiss()
                }
            })
        }

    }

    fun addvendorservice(it: View) {
        Log.e("ccatidssssss", "$categoryid $subcategoryid")
        val file = File(uri.path)
        val file1 = File(uri1.path)
        val requestFile = RequestBody.create(MediaType.parse("*/*"), file)
        val requestFile1 = RequestBody.create(MediaType.parse("*/*"), file1)
        val profile_img = MultipartBody.Part.createFormData("serviceimage", uri.path, requestFile)
        val coverimage = MultipartBody.Part.createFormData("coverimage", uri1.path, requestFile1)

        Log.e("imagesspath", uri1.path ?: return)
        Log.e("imagesspath1", uri.path ?: return)

        if (binding.serviceName.text.toString().equals("")){
            Toast.makeText(this@AddServiceActivity,"Please fill all fields",Toast.LENGTH_SHORT).show()
        }else if(binding.vendorMobile.text.toString().equals("")){
            Toast.makeText(this@AddServiceActivity,"Please fill all fields",Toast.LENGTH_SHORT).show()
        }else if(binding.vendorMobile.text.toString().equals("")){
            Toast.makeText(this@AddServiceActivity,"Please fill all fields",Toast.LENGTH_SHORT).show()

        } else if(!checkPaymentType()) {
            Toast.makeText(
                this@AddServiceActivity,
                "Please fill account/upi details fields",
                Toast.LENGTH_SHORT
            ).show()
        } else if(binding.serviceDescription.text.toString().equals("")){
            Toast.makeText(this@AddServiceActivity,"Please fill all fields",Toast.LENGTH_SHORT).show()
        }else{
            val progress = ProgressDialog(this)
//        progress.setTitle("Loading")
            progress.setMessage("Loading...")
            progress.setCancelable(false)
            progress.show()
            val getDataService: GetDataService =
                RetrofitClintanse.getInstance().create(GetDataService::class.java)
            val call: Call<JsonArray> =
                getDataService.addvendorservice(
                    prefrenceManager?.getUserid(applicationContext).toString(),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        cetagory_id
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.vendorMobile.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.vendorEmail.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.serviceName.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.vendorName.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.servicePrice.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.discount.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.vendorAddress.text.toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        prefrenceManager?.getlatitude(this@AddServiceActivity).toString(),
                    ), RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        prefrenceManager?.getlongitude(this@AddServiceActivity).toString()
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        categoryid
                    ),
                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        subcategoryid
                    ),
                    coverimage,
                    profile_img,

                    RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.serviceDescription.text.toString()
                    ),  RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.accountNumber.text.toString()
                    ),  RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.accountHolderName.text.toString()
                    ),  RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.ifscCode.text.toString()
                    ),  RequestBody.create(
                        MediaType.parse("multipart/form-data"),
                        binding.upiPin.text.toString()
                    )
                )
            Log.e("userid", prefrenceManager?.getUserid(applicationContext).toString())
            call.enqueue(object : Callback<JsonArray> {
                override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                    try {
                        Log.e("update_res", response.body().toString())
                        val jsonArray = JSONArray(Gson().toJson(response.body()))
                        val jsonObject = jsonArray.getJSONObject(0)
                        val res = jsonObject.getString("status")
                        if (res.equals("success")) {
                            Toast.makeText(this@AddServiceActivity,"Please Wait For Admin Approval",Toast.LENGTH_SHORT).show()
                            progress.dismiss()
                            finish()
                        } else {
                            val snack =
                                Snackbar.make(it, jsonObject.getString("errors"), Snackbar.LENGTH_LONG)
                            snack.setBackgroundTint(
                                ContextCompat.getColor(
                                    applicationContext,
                                    R.color.holo_red_dark
                                )
                            )
                            snack.show()

                            progress.dismiss()
                        }

                    } catch (e: Exception) {
                        Log.e("update_ex", e.toString())
                        progress.dismiss()
                    }

                }

                override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                    Log.e("update_error", t.toString())
                    progress.dismiss()
                }
            })
        }

    }

    fun updateservice(it: View) {
        val progress = ProgressDialog(this)
//        progress.setTitle("Loading")
        progress.setMessage("Loading...")
        progress.setCancelable(false)

        progress.show()
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.vendor_UpdateService(
                serviceid,
                binding.serviceName.text.toString(),
                binding.vendorName.text.toString(),
                binding.servicePrice.text.toString(),
                binding.vendorAddress.text.toString(),
                categoryid,
                subcategoryid,
                binding.serviceDescription.text.toString()
            )
        call.enqueue(object : Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    Log.e("serviceUpdate_res", response.body().toString())
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {

                        val snack =
                            Snackbar.make(it, jsonObject.getString("message"), Snackbar.LENGTH_LONG)
                        snack.setBackgroundTint(
                            ContextCompat.getColor(
                                applicationContext,
                                R.color.holo_red_dark
                            )
                        )
                        snack.show()
                        progress.dismiss()
                        finish()

                    } else {

                        val snack =
                            Snackbar.make(it, jsonObject.getString("errors"), Snackbar.LENGTH_LONG)
                        snack.setBackgroundTint(
                            ContextCompat.getColor(
                                applicationContext,
                                R.color.holo_red_dark
                            )
                        )
                        snack.show()
                        progress.dismiss()
                    }

                } catch (e: Exception) {
                    Log.e("serviceUpdate_ex", e.toString())
                    progress.dismiss()
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("serviceUpdate_error", t.toString())
                progress.dismiss()
                // binding.progress.visibility = View.GONE
            }
        })
    }

    fun Category_user() {
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonArray> = getDataService.catgeroy(cetagory_id)
        call.enqueue(object : Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e("category_response", response.body().toString())
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonObject2 = jsonObject.getJSONArray("data")
                        for (i in 0 until jsonObject2.length()) {
                            val categorymodel: Categorymodel = Gson().fromJson(
                                jsonObject2.getString(i).toString(),
                                Categorymodel::class.java
                            )
                            list.add(categorymodel.cateName.toString())
                            Log.e("data",categorymodel.cateName.toString())
                            list_id.add(categorymodel.id.toString())
                        }
                        val aa = ArrayAdapter(
                            this@AddServiceActivity,
                            R.layout.simple_spinner_item,
                            list
                        )
                        // Set layout to use when the list of choices appear
                        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        // Set Adapter to Spinner
                        binding.catSpinner.adapter = aa

                        binding.catSpinner.onItemSelectedListener = object :
                            AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(
                                parent: AdapterView<*>,
                                view: View, position: Int, id: Long
                            ) {
//                                Toast.makeText(
//                                    this@AddVendorServicesActivity,
//                                    getString(R.string.selected_item) + " " +
//                                            "" + list_id[position], Toast.LENGTH_SHORT
//                                ).show()
                                categoryid = list_id[position]
                                sub_category(list_id[position])
                            }
                            override fun onNothingSelected(parent: AdapterView<*>) {
                                // write code to perform some action
                            }
                        }
                    } else {

                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("category_exe", response.body().toString())
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("category_error", t.toString())
            }

        })

    }
    fun sub_category(catid: String) {
        sub_list.clear()
        sub_list_id.clear()
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataService.fetch_category(catid)
        call.enqueue(object : Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    Log.e("subcat_res", response.body().toString())
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Log.e("fddd", jsonArray1.toString())
                        for (i in 0 until jsonArray1.length()) {
                            val subcategoryModel: SubcategoryModel = Gson().fromJson(
                                jsonArray1.getString(i).toString(),
                                SubcategoryModel::class.java
                            )
                            sub_list.add(subcategoryModel.sub_category.toString())
                            sub_list_id.add(subcategoryModel.id.toString())
                        }

                        val aa = ArrayAdapter(
                            this@AddServiceActivity,
                            android.R.layout.simple_spinner_item,
                            sub_list
                        )

                        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

                        binding.subSpinner.adapter = aa

                        binding.subSpinner.onItemSelectedListener = object :
                            AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(
                                parent: AdapterView<*>,
                                view: View, position: Int, id: Long
                            ) {
//                                Toast.makeText(
//                                    this@AddVendorServicesActivity,
//                                    getString(R.string.selected_item) + " " +
//                                            "" + sub_list_id[position], Toast.LENGTH_SHORT
//                                ).show()
                                subcategoryid = sub_list_id[position]
                            }

                            override fun onNothingSelected(parent: AdapterView<*>) {
                                // write code to perform some action
                            }
                        }

                    } else {

                    }


                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("subcat_ex", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("subcat_res", t.toString())
            }
        })
    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
        Log.e("df", list[p2])

    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
    }

    override fun refresh() {
        Category_user()
    }

    fun checkPaymentType(): Boolean {
        if (upiPinDetails == "Account Number") {
            if (binding.accountNumber.text.toString() == "") {
                Toast.makeText(
                    this@AddServiceActivity,
                    "Please fill all fields",
                    Toast.LENGTH_SHORT
                ).show()
                return false
            } else if (binding.accountHolderName.text.toString() == "") {
                Toast.makeText(
                    this@AddServiceActivity,
                    "Please fill all fields",
                    Toast.LENGTH_SHORT
                ).show()
                return false
            }
        } else {
            if (binding.upiPin.text.toString() == "") {
                Toast.makeText(
                    this@AddServiceActivity,
                    "Please fill Upi fields",
                    Toast.LENGTH_SHORT
                ).show()
                return false
            }
        }
        return true
    }
}