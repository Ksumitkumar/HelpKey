package com.helpkey.service.VendorActivity

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.budiyev.android.codescanner.*
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.helpkey.service.Adapter.VendorCardPaymentHistoryAdapter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.VendorCardPaymentHistoryModel
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityQrscannerBinding
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.util.ArrayList


class QrscannerActivity : AppCompatActivity() {

    var prefrenceManager: PrefrenceManger1? = null
    private lateinit var codeScanner: CodeScanner
    val MY_CAMERA_PERMISSION_REQUEST = 1111
    lateinit var binding: ActivityQrscannerBinding
    var vendorCardPaymentHistoryModel: ArrayList<VendorCardPaymentHistoryModel> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQrscannerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefrenceManager = PrefrenceManger1(applicationContext)
        binding.empaty.setAnimation(R.raw.datanotfound)
        val scannerView = findViewById<CodeScannerView>(R.id.scanner_view)
        codeScanner = CodeScanner(this, scannerView)

        binding.back.setOnClickListener {
            if (binding.scannerView.isVisible) {
            finish()
        } else {
            binding.historyLayout.visibility = View.GONE
            binding.scannerView.visibility = View.VISIBLE
        } }

        binding.history.setOnClickListener {
            if (binding.scannerView.isVisible) {
                binding.historyLayout.visibility = View.VISIBLE
                binding.scannerView.visibility = View.GONE
                history()
            } else {
                binding.historyLayout.visibility = View.GONE
                binding.scannerView.visibility = View.VISIBLE
            }
        }

        // Parameters (default values)
        codeScanner.camera = CodeScanner.CAMERA_BACK // or CAMERA_FRONT or specific camera id
        codeScanner.formats = CodeScanner.ALL_FORMATS // list of type BarcodeFormat,
        // ex. listOf(BarcodeFormat.QR_CODE)
        codeScanner.autoFocusMode = AutoFocusMode.SAFE // or CONTINUOUS
        codeScanner.scanMode = ScanMode.SINGLE // or CONTINUOUS or PREVIEW
        codeScanner.isAutoFocusEnabled = true // Whether to enable auto focus or not
        codeScanner.isFlashEnabled = true // Whether to enable flash or not

        // Callbacks
        codeScanner.decodeCallback = DecodeCallback {
            runOnUiThread {
                Toast.makeText(this, "Scan result: ${it.text}", Toast.LENGTH_LONG).show()
                try {
                    val intent = Intent("com.google.zxing.client.android.SCAN")
                    intent.putExtra("SCAN_MODE", it.text) // "PRODUCT_MODE for bar codes
                    startActivityForResult(intent, 0)
                } catch (e: Exception) {
                    val marketUri = Uri.parse(it.text)
                    val marketIntent = Intent(Intent.ACTION_VIEW, marketUri)
                    startActivity(marketIntent)
                }
            }
        }
        codeScanner.errorCallback = ErrorCallback { // or ErrorCallback.SUPPRESS
            runOnUiThread {
                Toast.makeText(this@QrscannerActivity, "Error", Toast.LENGTH_SHORT).show()
            }
        }

        checkPermission()
    }

    fun checkPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.CAMERA),
                MY_CAMERA_PERMISSION_REQUEST
            )
        } else {
            codeScanner.startPreview()
        }
    }

    @SuppressLint("MissingSuperCall")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == MY_CAMERA_PERMISSION_REQUEST && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            codeScanner.startPreview()
        } else {
            Toast.makeText(this, "kdj", Toast.LENGTH_LONG).show()
        }
    }

    fun history() {
      //  Toast.makeText(this@QrscannerActivity, prefrenceManager?.getUserid(this).toString(), Toast.LENGTH_SHORT).show()

        vendorCardPaymentHistoryModel.clear()
        binding.empaty.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.vendorcardtransationhistory(prefrenceManager?.getUserid(applicationContext).toString())
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("History_res", response.body().toString())
                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progressBar.visibility = View.GONE
                        val jsonArray = jsonObject.getJSONArray("data")
                        Log.e("data", jsonArray.toString())
                        vendorCardPaymentHistoryModel= ArrayList()
                        if (jsonArray.length() > 0) {
                            for (i in 0 until jsonArray.length()) {
                                val history: VendorCardPaymentHistoryModel = Gson().fromJson(
                                    jsonArray.getString(i).toString(),
                                    VendorCardPaymentHistoryModel::class.java
                                )
                                vendorCardPaymentHistoryModel.add(history)
                            }
                        } else {
                            binding.progressBar.visibility = View.GONE
                            binding.empaty.visibility = View.VISIBLE
                        }
                    } else {
                        binding.progressBar.visibility = View.GONE
                        binding.empaty.visibility = View.VISIBLE
                    }

                    val adpter3 = VendorCardPaymentHistoryAdapter(
                        vendorCardPaymentHistoryModel,
                        applicationContext
                    )
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.historyRecy.layoutManager = layoutManager
                    binding.historyRecy.setHasFixedSize(true)
                    binding.historyRecy.adapter = adpter3

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("History_exe", e.toString())
                    binding.progressBar.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("History_error", t.toString())
                binding.progressBar.visibility = View.GONE
            }

        })
    }

    override fun onResume() {
        super.onResume()
        codeScanner.startPreview()
    }

    override fun onPause() {
        codeScanner.releaseResources()
        super.onPause()
    }

    override fun onBackPressed() {
        if (binding.scannerView.isVisible) {
            super.onBackPressed()
        } else {
            binding.historyLayout.visibility = View.GONE
            binding.scannerView.visibility = View.VISIBLE
        }

    }
}