package com.helpkey.service.UserActivity

import android.Manifest
import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.LatLng
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.squareup.picasso.Picasso
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityEditeBinding
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.json.JSONArray
import org.json.JSONException
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.IOException
import java.util.*

@Suppress("DEPRECATION")
class EditeActivity : AppCompatActivity() {
    lateinit var binding: ActivityEditeBinding
    var uri1 = Uri.parse("")
    var gender = "Male"
    var prefrenceManager: PrefrenceManger1? = null
    private lateinit var mFusedLocationClient: FusedLocationProviderClient
    private var lastLocation: Location? = null
    var localaddress = ""
    var latitude = ""
    var longitude = ""
    lateinit var imagess: MultipartBody.Part
    internal val TAG = "LocationProvider"
    internal val REQUEST_PERMISSIONS_REQUEST_CODE = 34


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        prefrenceManager = PrefrenceManger1(applicationContext)
        profile_view()


        if (intent.getStringExtra("address").toString() == "vendor") {
            binding.vendorDescription.visibility = View.VISIBLE
        } else {

        }

        binding.radiogroup.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->

            val radio: RadioButton = group.findViewById(checkedId)

            gender = radio.text.toString()


        })

        binding.back.setOnClickListener { finish() }
        binding.pick.setOnClickListener {
            ImagePicker.with(this@EditeActivity)
                .crop() //Crop image(Optional), Check Customization for more option
                .compress(1024) //Final image size will be less than 1 MB(Optional)
                .maxResultSize(
                    1080,
                    1080
                ) //Final image resolution will be less than 1080 x 1080(Optional)
                .start(101)
        }


        binding.editprofile.setOnClickListener {
            Log.e("uri", uri1.path.toString() + " " + binding.address.text.toString().length)
            if (uri1.path.toString() == "") {
                getLocationFromAddress(binding.address.text.toString() + binding.city.text.toString() + binding.state.text.toString())
                updateProfile1()
            } else {
                if (validation()) {
                    getLocationFromAddress(binding.address.text.toString() + binding.city.text.toString() + binding.state.text.toString())
                    updateProfile()

                } else {

                }
            }


        }

    }


    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && data != null) {
            when (requestCode) {
                101 -> {
                    uri1 = data.data
                    Log.e("image", uri1.toString())
                    binding.profileImage.setImageURI(uri1)
                }
            }
        }


    }


    fun validation(): Boolean {
        if (binding.name.text.toString().trim().isEmpty()) {
            binding.name.error = "Enter Your Name"
            binding.name.requestFocus()
        } else if (binding.email.text.toString().trim().isEmpty()) {
            binding.email.error = "Enter Your Email"
            binding.email.requestFocus()
        } else if (binding.work.text.toString().trim().isEmpty()) {
            binding.work.error = "Enter Your work"
            binding.work.requestFocus()
        } else if (binding.address.text.toString().trim().isEmpty()) {
            binding.address.error = "Enter Your Address"
            binding.address.requestFocus()
        } else if (binding.pincode.text.toString().trim().isEmpty()) {
            binding.pincode.error = "Enter Your Pincode"
            binding.pincode.requestFocus()
        } else if (binding.pincode.text.toString().trim().length < 6) {
            binding.pincode.error = "Enter the 6 digit"
            binding.pincode.requestFocus()
        } else if (binding.city.text.toString().trim().isEmpty()) {
            binding.city.error = "Enter Your City"
            binding.city.requestFocus()
        } else if (binding.state.text.toString().trim().isEmpty()) {
            binding.state.error = "Enter Your State"
            binding.state.requestFocus()
        } else {
            return true
        }
        return false
    }

    fun profile_view() {
        val progress = ProgressDialog(this)
        progress.setMessage("Loading...")
        progress.setCancelable(false)
        progress.show()
        val getDataServices: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataServices.view_profile(
            prefrenceManager?.getUserid(applicationContext)
        )
        Log.e("userid", prefrenceManager?.getUserid(applicationContext).toString())
        call.enqueue(object : Callback<JsonArray> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {

                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e(
                        "profile_response",
                        jsonArray.toString() + " " + call.request().url().toString()
                    )
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        progress.dismiss()
                        val jsonArray1 = jsonObject.getJSONObject("data")
                        binding.mobile.setText("+91 " + jsonArray1.getString("mobile").toString())
                        binding.email.setText(jsonArray1.getString("email").toString())
                        binding.name.setText(jsonArray1.getString("username").toString())
                        if (jsonArray1.getString("gender").toString() == "Male") {
                            binding.male.isChecked = true
                        } else if (jsonArray1.getString("gender").toString() == "Female") {
                            binding.female.isChecked = true
                        } else if (jsonArray1.getString("gender").toString() == "Other") {
                            binding.other.isChecked = true
                        }
                        if (jsonArray1.getString("address").toString() == "") {
                            if (!checkPermissions()) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    requestPermissions()
                                }
                            } else {
                                getLastLocation()
                            }
                        } else {
                            binding.address.setText(jsonArray1.getString("address").toString())
                        }
                        Picasso.get()
                            .load(
                                "https://panels.helpkey.in/public/images/profileImage/" + jsonArray1.optString(
                                    "image"
                                )
                            )
                            .placeholder(R.drawable.ic_baseline_person_24)
                            .into(binding.profileImage)

                        binding.pincode.setText(jsonArray1.getString("pin_code").toString())
                        binding.city.setText(jsonArray1.getString("city").toString())
                        binding.state.setText(jsonArray1.getString("state").toString())
                        binding.work.setText(jsonArray1.getString("work").toString())

                        Log.e("des", jsonArray1.optString("description").toString())
                        binding.vendorDescription.setText(
                            jsonArray1.optString("description").toString()
                        )
                    } else {

                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("profile_exe", e.toString())
                    progress.dismiss()

                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("profile_error", t.toString())
                progress.dismiss()

            }

        })

    }


    fun updateProfile() {
        val progress = ProgressDialog(this)
        progress.setMessage("Loading...")
        progress.setCancelable(false)
        progress.show()

        val file = File(uri1.path)
        val requestFile = RequestBody.create(MediaType.parse("*/*"), file)
        imagess = MultipartBody.Part.createFormData("image", uri1.path, requestFile)
        Log.e("imagess", uri1.path!!)
        Log.e("userid", prefrenceManager?.getUserid(applicationContext).toString() + " " + imagess)
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.update_profile(
                imagess,
                prefrenceManager?.getUserid(applicationContext).toString(),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.name.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    prefrenceManager?.getmobilno(applicationContext).toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    gender
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.pincode.text.toString()
                ),
                RequestBody.create(MediaType.parse("multipart/form-data"), "India"),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.state.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.city.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.address.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.email.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.work.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.discount.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.vendorDescription.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    latitude
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    longitude
                )

            )
        call.enqueue(object : Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                //  binding.progress.visibility = View.GONE
                Log.e("update_res", response.body().toString())
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    val message = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        val jsonObject1 = jsonArray1.getJSONObject(0)


                        Toast.makeText(
                            applicationContext,
                            "" + message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                        progress.dismiss()
                        prefrenceManager!!.setName(binding.name.text.toString(), applicationContext)
                        prefrenceManager!!.setemail(
                            binding.email.text.toString(),
                            applicationContext
                        )
                        prefrenceManager?.setlatitude(latitude, applicationContext)
                        prefrenceManager?.setlongitude(longitude, applicationContext)
//                        Toast.makeText(this@EditeActivity, latitude.toString(),Toast.LENGTH_LONG).show()
//                        Toast.makeText(this@EditeActivity,longitude?.toString(),Toast.LENGTH_LONG).show()
                       // this@EditeActivity.finish()
                        val intent = intent
                        finish()
                        startActivity(intent)

                    } else {
                        Toast.makeText(
                            applicationContext,
                            "" + message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                        progress.dismiss()
                        //   binding.progress.visibility = View.GONE
                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("update_error", e.toString())
                    progress.dismiss()

                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("update_error", t.toString())
                progress.dismiss()
            }
        })
    }

    fun updateProfile1() {
        val progress = ProgressDialog(this)
        progress.setMessage("Loading...")
        progress.setCancelable(false)
        progress.show()
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.user_update(
                prefrenceManager?.getUserid(applicationContext).toString(),
                binding.name.text.toString(),
                prefrenceManager?.getmobilno(applicationContext).toString(),
                gender,
                binding.work.text.toString(),
                binding.pincode.text.toString(),
                "India",
                binding.state.text.toString(),
                binding.city.text.toString(),
                binding.address.text.toString(),
                binding.email.text.toString(),
                binding.vendorDescription.text.toString(),
                latitude,
                longitude

            )
        call.enqueue(object : Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                //  binding.progress.visibility = View.GONE
                Log.e("update_res", response.body().toString())
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    val message1 = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        val jsonObject1 = jsonArray1.getJSONObject(0)
                        Toast.makeText(
                            this@EditeActivity,
                            "" + message1.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                        progress.dismiss()
                        prefrenceManager!!.setName(binding.name.text.toString(), applicationContext)
                        prefrenceManager!!.setemail(
                            binding.email.text.toString(),
                            applicationContext)
                        prefrenceManager?.setlatitude(latitude, applicationContext)
                        prefrenceManager?.setlongitude(longitude, applicationContext)
                        val intent = intent
                        finish()
                        startActivity(intent)
//                        this@EditeActivity.finish()

                    } else {
                        Toast.makeText(
                            applicationContext,
                            "" + message1.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                        progress.dismiss()
                        //   binding.progress.visibility = View.GONE
                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("update_error", e.toString())
                    progress.dismiss()

                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("update_error", t.toString())
                progress.dismiss()
            }
        })
    }


    private fun getLastLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        mFusedLocationClient.lastLocation.addOnCompleteListener(this) { task ->
            if (task.isSuccessful && task.result != null) {
                lastLocation = task.result
                Log.e("latitude", (lastLocation)!!.latitude.toString())
                Log.e("longitude", (lastLocation)!!.longitude.toString())

                latitude = (lastLocation)!!.latitude.toString()
                longitude = (lastLocation)!!.longitude.toString()

                val geocoder = Geocoder(this, Locale.getDefault())
                val list: List<Address> =
                    geocoder.getFromLocation(
                        (lastLocation)!!.latitude,
                        (lastLocation)!!.longitude,
                        1
                    )!!
                binding.apply {
                    Log.e("locationArea", list[0].getAddressLine(0))
                    localaddress = address.setText(list[0].getAddressLine(0)).toString()
//                    binding.userAddress.setText(list[0].getAddressLine(0))
                    binding.pincode.setText(list[0].postalCode)
                    binding.state.setText(list[0].adminArea)
                    binding.city.setText(list[0].locality)
                }
            } else {
                Log.w(TAG, "getLastLocation:exception", task.exception)
            }
        }
    }
    private fun showSnackbar(
        mainTextStringId: String, actionStringId: String,
        listener: View.OnClickListener
    ) {
       // Toast.makeText(this, mainTextStringId, Toast.LENGTH_LONG).show()
    }

    private fun checkPermissions(): Boolean {
        val permissionState = ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        return permissionState == PackageManager.PERMISSION_GRANTED
    }

    private fun startLocationPermissionRequest() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION),
            REQUEST_PERMISSIONS_REQUEST_CODE
        )
    }

    private fun requestPermissions() {
        val shouldProvideRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (shouldProvideRationale) {
            Log.i(TAG, "Displaying permission rationale to provide additional context.")
            showSnackbar("Location permission is needed for core functionality", "Okay",
                View.OnClickListener {
                    startLocationPermissionRequest()
                })
        } else {
            Log.i(TAG, "Requesting permission")
            startLocationPermissionRequest()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Log.i(TAG, "onRequestPermissionResult")
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            when {
                grantResults.isEmpty() -> {
                    Log.i(TAG, "User interaction was cancelled.")
                }
                grantResults[0] == PackageManager.PERMISSION_GRANTED -> {
                    getLastLocation()
                }
                else -> {
                    showSnackbar("Permission was denied", "Settings",
                        View.OnClickListener {
                            val intent = Intent()
                            intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                            val uri = Uri.fromParts(
                                "package",
                                Build.DISPLAY, null
                            )
                            intent.data = uri
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                        }
                    )
                }
            }
        }
    }

    private fun getLocationFromAddress(strAddress: String?): LatLng? {
        val coder = Geocoder(applicationContext)
        val address: List<Address>?
        var latLng: LatLng? = null
        try {
            address = coder.getFromLocationName(strAddress!!, 5)
            if (address == null) {
                return null
            }
            try {
                val location = address[0]
                latLng = LatLng(location.latitude, location.longitude)
                latitude = location.latitude.toString()
                longitude = location.longitude.toString()
                Log.e("location", latLng.toString())
            } catch (e: Exception) {
                Log.e("Exception", e.toString())
            }

        } catch (e: IOException) {
            e.printStackTrace()
        }

        return latLng
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}