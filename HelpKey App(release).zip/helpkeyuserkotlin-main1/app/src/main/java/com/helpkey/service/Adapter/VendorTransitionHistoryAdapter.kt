package com.helpkey.service.Adapter

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.helpkey.service.Models.VendorTransitionHistoryModel
import com.helpkey.service.databinding.TranstationHistoryLayoutBinding

class VendorTransitionHistoryAdapter(var list: ArrayList<VendorTransitionHistoryModel>, var context: Context): RecyclerView.Adapter<VendorTransitionHistoryAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VendorTransitionHistoryAdapter.ViewHolder {
        val binding = TranstationHistoryLayoutBinding.inflate(LayoutInflater.from(context),parent,false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: VendorTransitionHistoryAdapter.ViewHolder, position: Int) {

       if (list.get(position).servicepoint.equals("Service")) {
           holder.binding.pointType.visibility=View.GONE
           holder.binding.serviceType.visibility=View.VISIBLE
           holder.binding.serviceName.text=list.get(position).servicename.toString()
        }else if (list.get(position).servicepoint.equals("Point")){
           holder.binding.pointType.visibility=View.VISIBLE
           holder.binding.serviceType.visibility=View.GONE
           holder.binding.points.text=list.get(position).servicename.toString()
        }else{

       }
        holder.binding.money.text = "₹ " + list[position].amount
        holder.binding.serviceName.text=list.get(position).servicename.toString()
        holder.binding.date.text = "Time: " + list[position].createdAt
        holder.binding.status.text = list[position].status
        holder.binding.descrip.text = "Description: " + list[position].description
        if (list[position].status.equals("Success")) {
            holder.binding.status.setTextColor(Color.parseColor("#008640"))
        } else {
            holder.binding.status.setTextColor(Color.parseColor("#e10028"))
        }


    }

    override fun getItemCount(): Int {
     return list.size
    }

    inner class ViewHolder(var binding: TranstationHistoryLayoutBinding): RecyclerView.ViewHolder(binding.root)
}