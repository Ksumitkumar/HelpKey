import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class BannersModel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("image")
    @Expose
    var image: String? = null

//    @SerializedName("status")
//    @Expose
//    var status: Int? = null

    constructor(
        id: Int?,
        image: String?,
        status: Int?,
    ) : super() {
        this.id = id
        this.image = image
       // this.status = status

    }
}