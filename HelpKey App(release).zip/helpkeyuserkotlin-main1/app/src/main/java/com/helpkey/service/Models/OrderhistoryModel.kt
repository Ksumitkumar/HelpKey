package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class OrderhistoryModel {

    @SerializedName("id")
    @Expose
    var id: String? = null

    @SerializedName("order_no")
    @Expose
    var order_no: String? = null

    @SerializedName("order_date")
    @Expose
    var order_date: String? = null

    @SerializedName("mobile")
    @Expose
    var mobile: String? = null

    constructor(id: String?, order_no: String?, order_date: String?, mobile: String?):super()
    {
        this.id = id
        this.order_no = order_no
        this.order_date = order_date
        this.mobile = mobile
    }
}