package com.helpkey.service.Adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.ShowAddressModel
import com.helpkey.service.UserActivity.PlaceHolderActivity
import com.helpkey.service.UserActivity.SelectAddressActivity
import com.helpkey.service.databinding.ShowaddressBinding
import org.json.JSONArray
import retrofit2.Call
import retrofit2.Response

class SelectAddressAdapter(var list: ArrayList<ShowAddressModel>, var context: Context) :
    RecyclerView.Adapter<SelectAddressAdapter.ViewHolder>() {
    var prefrenceManager: PrefrenceManger1? = null

    inner class ViewHolder(var binding: ShowaddressBinding) : RecyclerView.ViewHolder(binding.root)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ShowaddressBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.personaddress.text = list[position].address
        prefrenceManager = PrefrenceManger1(context)

        holder.binding.deletecard.setOnClickListener {
            try {
                if (!list[position].id.equals("")) {
                    deleteAddress(list[position].id.toString(), position)
                } else {
                    Toast.makeText(
                        context,
                        "There is no more address for delete in list",
                        Toast.LENGTH_LONG
                    ).show()
                }

            } catch (e: Exception) {
                e.localizedMessage
            }

        }


        holder.binding.select.setOnClickListener {
            val intent = Intent(context, PlaceHolderActivity::class.java)
            prefrenceManager!!.setaddressid(list[position].id.toString(), context)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
            SelectAddressActivity.activity.finish()
            PlaceHolderActivity.activity.finish()
        }

    }

    override fun getItemCount(): Int {
        return list.size
    }

    fun deleteAddress(id: String?, position: Int) {
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonArray> = getDataService.deleteAddress(
            id
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e("deleteAddress_res", response.body().toString() + " " + id)
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        list.removeAt(position)
                        notifyItemRemoved(position)
                        notifyItemRangeChanged(position, list.size)
//                        holder.itemView.visibility = View.GONE
                        val message = jsonObject.getString("message")
                        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()


                    } else {

                    }

                } catch (e: Exception) {
                    Log.e("deleteAddress_error", e.toString())
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("deleteAddress_error", t.toString())
            }

        })

    }


}