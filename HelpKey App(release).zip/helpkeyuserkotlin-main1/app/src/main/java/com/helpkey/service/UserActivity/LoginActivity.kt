package com.helpkey.service.UserActivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.helpkey.service.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    lateinit var binding: ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.regiertHere.setOnClickListener {
            val mainIntent = Intent(this, SelectuserTypeActivity::class.java)
            startActivity(mainIntent)
        }
        binding.signIn.setOnClickListener {
            val mainIntent = Intent(this, DashbordActivity::class.java)
            startActivity(mainIntent)
        }
    }
}