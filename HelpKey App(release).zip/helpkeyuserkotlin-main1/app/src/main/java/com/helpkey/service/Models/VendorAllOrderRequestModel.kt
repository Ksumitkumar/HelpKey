package com.helpkey.service.Models

import com.google.gson.annotations.SerializedName
import com.google.gson.annotations.Expose

class VendorAllOrderRequestModel {
    @SerializedName("order_no")
    @Expose
    var orderNo: String? = null

    @SerializedName("distance")
    @Expose
    var distance: String? = null

    @SerializedName("payment_method")
    @Expose
    var paymentMethod: String? = null

    @SerializedName("total_amount")
    @Expose
    var totalAmount: String? = null

    @SerializedName("order_status")
    @Expose
    var orderStatus: String? = null

    @SerializedName("payment_status")
    @Expose
    var paymentStatus: String? = null

    @SerializedName("delivery_address")
    @Expose
    var deliveryAddress: String? = null

    @SerializedName("address_type")
    @Expose
    var addressType: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("servicename")
    @Expose
    var servicename: String? = null

    @SerializedName("service_cost")
    @Expose
    var serviceCost: String? = null

    @SerializedName("category")
    @Expose
    var category: String? = null

    @SerializedName("subcategory")
    @Expose
    var subcategory: String? = null

    @SerializedName("coverimage")
    @Expose
    var coverimage: String? = null

    @SerializedName("serviceimage")
    @Expose
    var serviceimage: String? = null

    @SerializedName("username")
    @Expose
    var username: String? = null

    @SerializedName("mobile")
    @Expose
    var mobile: String? = null

    /**
     * No args constructor for use in serialization
     *
     */
    constructor() {}

    /**
     *
     * @param orderNo
     * @param distance
     * @param serviceCost
     * @param addressType
     * @param orderStatus
     * @param totalAmount
     * @param createdAt
     * @param coverimage
     * @param deliveryAddress
     * @param paymentMethod
     * @param serviceimage
     * @param category
     * @param subcategory
     * @param paymentStatus
     * @param username
     * @param mobile
     */
    constructor(
        orderNo: String?,
        distance: String?,
        paymentMethod: String?,
        totalAmount: String?,
        orderStatus: String?,
        paymentStatus: String?,
        deliveryAddress: String?,
        addressType: String?,
        createdAt: String?,
        serviceCost: String?,
        category: String?,
        subcategory: String?,
        coverimage: String?,
        serviceimage: String?,
        username: String?,
        mobile: String?
    ) : super() {
        this.orderNo = orderNo
        this.distance = distance
        this.paymentMethod = paymentMethod
        this.totalAmount = totalAmount
        this.orderStatus = orderStatus
        this.paymentStatus = paymentStatus
        this.deliveryAddress = deliveryAddress
        this.addressType = addressType
        this.createdAt = createdAt
        this.serviceCost = serviceCost
        this.category = category
        this.subcategory = subcategory
        this.coverimage = coverimage
        this.serviceimage = serviceimage
        this.username = serviceimage
        this.mobile = serviceimage
    }
}