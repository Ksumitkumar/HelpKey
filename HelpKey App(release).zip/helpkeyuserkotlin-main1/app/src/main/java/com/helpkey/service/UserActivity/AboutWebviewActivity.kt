package com.helpkey.service.UserActivity

import android.content.Intent
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.helpkey.service.databinding.ActivityAboutWebviewBinding


class AboutWebviewActivity : AppCompatActivity() {
    private var url = "https://helpkey.in/about-us/"
    lateinit var binding: ActivityAboutWebviewBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutWebviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.back.setOnClickListener { finish() }
//       binding. webView.getSettings().setJavaScriptEnabled(true);
//        val webSettings: WebSettings =   binding. webView.getSettings()
//
//        webSettings.javaScriptEnabled = true
//        webSettings.useWideViewPort = true
//        webSettings.loadWithOverviewMode = true
//        webSettings.domStorageEnabled = true
        binding. webView.loadUrl("helpkey.in/about-us/")
        //binding.webView.setWebViewClient(MyWebViewClient())




        binding.webView.loadUrl(url)
        binding.webView.getSettings().setJavaScriptEnabled(true)
        binding.webView.setWebViewClient(WebViewClient())
    }
    override fun onBackPressed() {
        if (binding.webView.canGoBack()) {
            startActivity(Intent(this@AboutWebviewActivity,DashbordActivity::class.java))

        } else {
            super.onBackPressed()
        }
    }
    private class MyWebViewClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            return false
        }
    }

}


