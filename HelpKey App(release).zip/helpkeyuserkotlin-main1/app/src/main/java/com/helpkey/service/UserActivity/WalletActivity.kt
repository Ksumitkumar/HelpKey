package com.helpkey.service.UserActivity

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.airbnb.lottie.LottieAnimationView
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.helpkey.service.Adapter.WalletAdapter
import com.helpkey.service.Adapter.WithdrawalHistoryAdapter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.TransitionHistoryModel
import com.helpkey.service.Models.WithdrawalHistoryModel
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityWalletBinding
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
class WalletActivity : AppCompatActivity() {
    lateinit var binding: ActivityWalletBinding
    var prefrenceManger: PrefrenceManger1? = null
    var amountwallet = "0"
    companion object {
        var walletBalance: MutableLiveData<String> = MutableLiveData()
    }
    var transitionHistoryModel: ArrayList<TransitionHistoryModel> = ArrayList()
    var withdrawalHistoryModel: ArrayList<WithdrawalHistoryModel> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWalletBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefrenceManger = PrefrenceManger1(applicationContext)
        binding.back.setOnClickListener { finish() }
        binding.empaty.setAnimation(R.raw.datanotfound)
        binding.walletRecylview.visibility = View.VISIBLE
        binding.widRecylview.visibility = View.GONE
        transitionHistory()


        binding.withdrawal.setOnClickListener {
            if (amountwallet == "0") {
                Toast.makeText(this@WalletActivity,"Your Wallet Amount Empty",Toast.LENGTH_SHORT).show()
            } else {
                Withdrawal()
            }
        }

        binding.tablayout.addOnTabSelectedListener(object : OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                val position = tab.position
                binding.empaty.visibility = View.GONE
                if (position == 0) {
                    binding.walletRecylview.visibility = View.VISIBLE
                    binding.widRecylview.visibility = View.GONE
                    binding.empaty.visibility = View.GONE
                    transitionHistory()
                } else if (position == 1) {
                    binding.empaty.visibility = View.GONE
                    binding.walletRecylview.visibility = View.GONE
                    binding.widRecylview.visibility = View.VISIBLE
                    Withdrawal_history()
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

    }
    private fun Withdrawal() {
        val builder = AlertDialog.Builder(this@WalletActivity)
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView: View =
            LayoutInflater.from(applicationContext)
                .inflate(R.layout.withdrawal_layout, viewGroup, false)
        builder.setView(dialogView)
        builder.setCancelable(false)
        val alertDialog = builder.create()
        val bankname = dialogView.findViewById<EditText>(R.id.bank_name)
        val brannchname = dialogView.findViewById<EditText>(R.id.branch_name)
        val account = dialogView.findViewById<EditText>(R.id.account_number)
        val ifsc = dialogView.findViewById<EditText>(R.id.ifsc_code)
        val amount = dialogView.findViewById<EditText>(R.id.amount)
        val upiid = dialogView.findViewById<EditText>(R.id.upi)
        val name = dialogView.findViewById<EditText>(R.id.name)
        val require = dialogView.findViewById<TextView>(R.id.require)
        val submit = dialogView.findViewById<Button>(R.id.submit)
        val back = dialogView.findViewById<TextView>(R.id.back)
        back.setOnClickListener { alertDialog.dismiss() }
        submit.setOnClickListener {
            if (amount.text.toString().trim().isEmpty()) {
                require.visibility = View.VISIBLE
                Toast.makeText(this@WalletActivity,"Please Inter Amount",Toast.LENGTH_SHORT).show()
            } else {
                require.visibility = View.GONE
                if (bankname.text.toString().trim().isEmpty() || brannchname.text.toString().trim().isEmpty() || account.text.toString().trim().isEmpty() || ifsc.text.toString().trim().isEmpty()) {
                    if (amountwallet.toInt() > amount.text.toString().toInt()) {
                        Log.e("amount",amountwallet+" "+amount.text.toString())
                        if (upiid.text.toString().trim().isEmpty()) {
                            require.visibility = View.GONE
                            upiid.requestFocus()
                            upiid.error = "Please Inter UPI"
                        } else {
                            require.visibility = View.GONE
                            Withdrawalapi(amount.text.toString(),upiid.text.toString(),ifsc.text.toString(),
                                name.text.toString(),account.text.toString(),bankname.text.toString(),brannchname.text.toString(),alertDialog)
                        }

                    } else {
                        require.visibility = View.VISIBLE
                    }
                } else {
                    if (amount.text.toString().trim().isEmpty()) {
                        amount.error = "Enter Your Amount"
                        amount.requestFocus()
                    } else if (bankname.text.toString().trim().isEmpty()) {
                        bankname.error = "Enter Your Bank Name"
                        bankname.requestFocus()
                    } else if (brannchname.text.toString().trim().isEmpty()) {
                        brannchname.error = "Enter Your Branch Name"
                        brannchname.requestFocus()
                    } else if (account.text.toString().trim().isEmpty()) {
                        account.error = "Enter Your Account Number"
                        account.requestFocus()
                    } else if (name.text.toString().trim().isEmpty()) {
                        name.error = "Enter Your Name"
                        name.requestFocus()
                    } else if (ifsc.text.toString().trim().isEmpty()) {
                        ifsc.error = "Enter the IFSC CODE"
                        ifsc.requestFocus()
                    } else  {
                        if (amountwallet.toInt() >= amount.text.toString().toInt()) {
                            require.visibility = View.GONE
                            Withdrawalapi(
                                amount.text.toString(),
                                upiid.text.toString(),
                                ifsc.text.toString(),
                                name.text.toString(),
                                account.text.toString(),
                                bankname.text.toString(),
                                brannchname.text.toString(),
                                alertDialog)
                        } else {
                           Toast.makeText(this@WalletActivity,"Wallet has not sufficient amount as you are requesting",Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }

        alertDialog.show()
    }
    fun Withdrawalapi(
        amount: String,
        upiid: String,
        ifsc: String,
        name: String,
        account: String,
        bankname: String,
        brannchname: String,
        alertDialog: AlertDialog){
        binding.progressBar.visibility = View.VISIBLE
        val Withdrawal: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            Withdrawal.
            withdrawal(
                prefrenceManger?.getUserid(applicationContext).toString(),
                amount,
                upiid,
                ifsc,
                name,
                account,
                bankname,
                brannchname
            )
        call.enqueue(object  : retrofit2.Callback<JsonObject>{
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e("withdrawal_res",response.body().toString())
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    val mes = jsonObject.getString("message")
                    if (res.equals("success")) {
                        binding.progressBar.visibility = View.GONE
                        Withdrawal_history()
                        Toast.makeText(this@WalletActivity,"$mes",Toast.LENGTH_SHORT).show()
                        alertDialog.dismiss()
                        confirm()

                            transitionHistory()



                    } else {

                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(this@WalletActivity,"$mes",Toast.LENGTH_SHORT).show()
                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("withdrawal_exe",e.toString())
                    binding.progressBar.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("withdrawal_err",t.toString())
                binding.progressBar.visibility = View.GONE
            }

        })

    }
    fun transitionHistory() {
        transitionHistoryModel.clear()
        binding.progressBar.visibility = View.VISIBLE
        binding.empaty.visibility = View.GONE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.transationhistory(prefrenceManger?.getUserid(applicationContext))
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("transition_response", response.body().toString())
                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    var res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        if (jsonObject.getString("amount").equals(null)){
                            binding.balance.text = "Balance : ₹ " + "0"
                        } else {
                            amountwallet = jsonObject.getString("amount").toString()
                           // walletBalance.value=amountwallet
                            binding.balance.text = "Balance : ₹ " + amountwallet

                        }
                        binding.progressBar.visibility = View.GONE
                        val jsonArray = jsonObject.getJSONArray("data")
                        if (jsonArray.length().toString() !="") {
                            for (i in 0 until jsonArray.length()) {
                                var transition: TransitionHistoryModel = Gson().fromJson(
                                    jsonArray.getString(i).toString(),
                                    TransitionHistoryModel::class.java)
                                transitionHistoryModel.add(transition)
                            }
                        } else {
                            binding.progressBar.visibility = View.GONE
                            binding.empaty.visibility = View.VISIBLE
                        }

                    } else {
                        binding.progressBar.visibility = View.GONE
                    }

                    var adpter3 = WalletAdapter(transitionHistoryModel, applicationContext)
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.walletRecylview.layoutManager = layoutManager
                    binding.walletRecylview.setHasFixedSize(true)
                    binding.walletRecylview.adapter = adpter3

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("transition_exe", e.toString())
                    binding.progressBar.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("transition_error", t.toString())
                binding.progressBar.visibility = View.GONE
            }

        })
    }
    fun Withdrawal_history() {
        withdrawalHistoryModel.clear()
        binding.empaty.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.withdrawal_request_member(prefrenceManger?.getUserid(applicationContext))
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("WithHistory_res", response.body().toString())
                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    var res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progressBar.visibility = View.GONE
                        val jsonArray = jsonObject.getJSONArray("data")
                        Log.e("data", jsonArray.toString())
                        if (jsonArray.length().toString() !="") {
                            for (i in 0 until jsonArray.length()) {
                                var Withdrawal: WithdrawalHistoryModel = Gson().fromJson(
                                    jsonArray.getString(i).toString(),
                                    WithdrawalHistoryModel::class.java
                                )
                                withdrawalHistoryModel.add(Withdrawal)
                            }
                        } else {
                            binding.progressBar.visibility = View.GONE
                            binding.empaty.visibility = View.GONE
                        }
                    } else {
                        binding.progressBar.visibility = View.GONE
                        binding.empaty.visibility = View.VISIBLE
                    }
                    var adpter3 = WithdrawalHistoryAdapter(withdrawalHistoryModel, applicationContext)
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.widRecylview.layoutManager = layoutManager
                    binding.widRecylview.setHasFixedSize(true)
                    binding.widRecylview.adapter = adpter3

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("WithHistory_exe", e.toString())
                    binding.progressBar.visibility = View.GONE
                }
            }
            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("WithHistory_error", t.toString())
                binding.progressBar.visibility = View.GONE
            }

        })
    }
    fun confirm() {
        val mdliog = LayoutInflater.from(this@WalletActivity)
            .inflate(R.layout.delete_service_cofiarmation, null)
        val muBulder = AlertDialog.Builder(this@WalletActivity)
            .setView(mdliog)
        val maliert = muBulder.show()
        val yes = mdliog.findViewById<TextView>(R.id.yes)
        val no = mdliog.findViewById<TextView>(R.id.no)
        val anitation = mdliog.findViewById<LottieAnimationView>(R.id.animation_view)
        val txt = mdliog.findViewById<TextView>(R.id.txt)
        no.visibility = View.GONE
        yes.text = "OK"
        anitation.setAnimation(R.raw.done)
        txt.text = "-Your Request Submitted-"
        yes.setOnClickListener {
            maliert.dismiss()
        }
        no.setOnClickListener { maliert.dismiss() }
    }
}