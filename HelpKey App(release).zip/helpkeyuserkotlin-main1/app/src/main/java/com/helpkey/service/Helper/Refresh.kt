package com.helpkey.service.Helper

interface Refresh {

    fun refresh()

}