package com.helpkey.service.Helper

import com.google.protobuf.DescriptorProtos.SourceCodeInfo.Location

class ConstantValue {
    companion object{
        var lastLocation: Location? =null
        var latitude=""
        var longitude=""
    }

}