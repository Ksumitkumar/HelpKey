package com.helpkey.service.Helper

class Constracter {
    companion object {
        var lat = ""
        var log = ""
        var itemcount = ""
        var amont = ""
        var addressl = ""
        var point = ""
        var category_id = ""
        var subcategory_id = ""
        var vendor_id = ""
        var manegestatus = ""
        var mobile = ""
        var latitude = ""
        var longitude = ""

    }

}