package com.helpkey.service.Adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Models.VendoruserModel
import com.helpkey.service.UserActivity.ProductActivity
import com.helpkey.service.databinding.RecviewVendorBinding

class VendorsAdapter(var list: ArrayList<VendoruserModel>,var context: Context) : RecyclerView.Adapter<VendorsAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: RecviewVendorBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            RecviewVendorBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        Picasso.get().load("https://panels.helpkey.in/public/images/serviceimage/"+list.get(position).serviceimage).into(holder.binding.img)
        Log.e("image","https://panels.helpkey.in/public/images/serviceimage/"+ list[position].serviceimage)
        holder.binding.title.text = list[position].vendor_name
        holder.binding.discirption.text = list[position].description
        holder.binding.location.text = list[position].address

        holder.binding.card.setOnClickListener {
            var intent = Intent(context, ProductActivity::class.java)
            Constracter.vendor_id = list[position].vendorId.toString()
            intent.putExtra("vendor_id",list[position].id.toString())
            intent.putExtra("name",list[position].vendor_name.toString())
            intent.putExtra("address","vendorcat")
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
        }

    }

    override fun getItemCount(): Int {
        return list.size
    }
}