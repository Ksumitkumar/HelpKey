package com.helpkey.service.UserActivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.helpkey.service.databinding.ActivityVendorviewallFulldetailsBinding

class Vendorviewall_fulldetailsActivity : AppCompatActivity() {
    lateinit var binding:ActivityVendorviewallFulldetailsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding=ActivityVendorviewallFulldetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)


//        var viewedadapter = MostPoupularAdapter(applicationContext)
//        val gridLayoutManager3 = GridLayoutManager(applicationContext, 3)
//        binding.recylviewVendornear.layoutManager = gridLayoutManager3
//        binding.recylviewVendornear.setHasFixedSize(true)
//        binding.recylviewVendornear.itemAnimator = DefaultItemAnimator()
//        binding.recylviewVendornear.adapter = viewedadapter





    }
}