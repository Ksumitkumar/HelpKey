package com.helpkey.service.UserActivity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.razorpay.Checkout
import com.razorpay.PaymentData
import com.razorpay.PaymentResultWithDataListener
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.databinding.ActivityFaimalyVerchalpaymentBinding
import okhttp3.MediaType
import okhttp3.RequestBody
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FaimalyVerchalpaymentActivity : AppCompatActivity(), PaymentResultWithDataListener {
    lateinit var binding: ActivityFaimalyVerchalpaymentBinding
    var prefrenceManager: PrefrenceManger1? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFaimalyVerchalpaymentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefrenceManager = PrefrenceManger1(applicationContext)
        startPayment()
    }


    private fun startPayment() {

        val co = Checkout()

        try {
            val options = JSONObject()
            options.put("name", "HelpKey App")
            options.put("description", prefrenceManager?.getName(applicationContext).toString())
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png")
            options.put("theme.color", "#3399cc");
            options.put("currency", "INR");
            options.put("amount", "100" + "00")
            val prefill = JSONObject()
            prefill.put("email", prefrenceManager?.getemail(applicationContext).toString())
            prefill.put("contact", prefrenceManager?.getmobilno(applicationContext).toString())
            options.put("prefill", prefill)
            co.open(this@FaimalyVerchalpaymentActivity, options)
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("exception_err", e.toString())
        }
    }

    override fun onPaymentSuccess(razorpayPaymentID: String?, paymentData: PaymentData?) {

        if (paymentData != null) {
            try {
                paymentSuccess(razorpayPaymentID.toString())
                Log.e("paymentSuccess",paymentData.data.toString())
            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("paymentExe", e.toString())

            }

        }


    }

    override fun onPaymentError(p0: Int, p1: String?, p2: PaymentData?) {

    }


    fun paymentSuccess(tx_id: String) {
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.order_famliy(
                MyvirtualcardActivity.list1, MyvirtualcardActivity.list2,
                RequestBody.create(
                    MediaType.parse("multipart/form-data"), intent.getStringExtra("orderid")
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    prefrenceManager?.getUserid(applicationContext).toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"), "100.00"
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"), tx_id
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"), intent.getStringExtra("name")
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"), intent.getStringExtra("work")
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    intent.getStringExtra("address") +","+ intent.getStringExtra("city") +","+ intent.getStringExtra("state") +","+ intent.getStringExtra("pin")
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"), "Success"

                )
            )
        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e("payemtn_res", response.body().toString())
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                        val intent =
                            Intent(this@FaimalyVerchalpaymentActivity, ThankyouActivity::class.java)
                        intent.putExtra("order_id", intent.getStringExtra("orderid"))
                        intent.putExtra("book", "cardbook")
                        startActivity(intent)

                    } else {
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: Exception) {

                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("payemnt_error", t.toString())

            }
        })
    }

}