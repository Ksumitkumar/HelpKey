package com.helpkey.service.VendorActivity

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.helpkey.service.Adapter.VendorMyDeleteServicesAdapter
import com.helpkey.service.Adapter.VendorMyServicesAdapter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.Refresh
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.DeleteServiceModel
import com.helpkey.service.Models.VenderServicesModel
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityVendorServicesBinding
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response

class VendorServicesActivity : AppCompatActivity(), Refresh {
    lateinit var binding: ActivityVendorServicesBinding

    var prefrenceManager: PrefrenceManger1? = null
    var venderServicesModel: ArrayList<VenderServicesModel> = ArrayList()
    var idtype = ""

    companion object {
        lateinit var activity: Activity
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVendorServicesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        activity = this
        prefrenceManager = PrefrenceManger1(applicationContext)
        binding.empaty1.setAnimation(R.raw.datanotfound)
        binding.empaty.setAnimation(R.raw.datanotfound)
        binding.mtoolbar.setNavigationOnClickListener(View.OnClickListener {
            if (binding.deleteLayout.isVisible) {
                binding.deleteHistory.isEnabled = true
                binding.serviceLayout.visibility = View.VISIBLE
                binding.deleteLayout.visibility = View.GONE
                vendorallservices()
            } else {
                finish()
            }
        })

        binding.deleteHistory.setOnClickListener {
            binding.serviceLayout.visibility = View.GONE
            binding.deleteLayout.visibility = View.VISIBLE
            delete_services_history()

        }
        idtype = intent.getStringExtra("type").toString()

        if (idtype == "1") {
            binding.mtoolbar.title = "My Helpkey Point"
        } else {
            binding.mtoolbar.title = "My Helpkey Services"
        }
        binding.progressBar.visibility = View.VISIBLE
        vendorallservices()
    }

    fun vendorallservices() {
        venderServicesModel.clear()
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.fetch_vendor_allServices(
                prefrenceManager?.getUserid(applicationContext),
                idtype
            )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                binding.progressBar.visibility = View.GONE
                try {
                    Log.e(
                        "venderallser_response",
                        response.body().toString() + " " + call.request().url().toString()
                    )

                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Log.e("venderallser", jsonObject.toString())
                        for (i in 0 until jsonArray1.length()) {
                            val vendarSModel: VenderServicesModel = Gson().fromJson(
                                jsonArray1.getString(i).toString(),
                                VenderServicesModel::class.java
                            )
                            venderServicesModel.add(vendarSModel)

                        }

                        var adpter3 = VendorMyServicesAdapter(
                            venderServicesModel, applicationContext, this@VendorServicesActivity
                        )
                        val layoutManager = LinearLayoutManager(applicationContext)
                        layoutManager.orientation = LinearLayoutManager.VERTICAL
                        binding.servicesRecy.layoutManager = layoutManager
                        binding.servicesRecy.setHasFixedSize(true)
                        binding.servicesRecy.adapter = adpter3


                    } else {
                        binding.servicesRecy.visibility = View.GONE
                        binding.empaty.visibility = View.VISIBLE
                        binding.progressBar.visibility = View.GONE

                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("venderallser_ex", e.toString())
                    binding.progressBar.visibility = View.GONE
                    binding.empaty.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.i("venderallser_error", t.toString())
                binding.progressBar.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE
            }
        })

    }

    fun delete_services_history() {
        venderServicesModel.clear()
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.fetch_vendor_alldeleteServices(
                prefrenceManager?.getUserid(applicationContext), idtype
            )
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                binding.progressBar.visibility = View.GONE
                try {
                    Log.e(
                        "venderallser_response",
                        response.body().toString() + " " + call.request().url().toString()
                    )
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.deleteHistory.isEnabled = false
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        if (jsonArray1.length() > 0) {
                            var venderServicesModel: ArrayList<DeleteServiceModel> = ArrayList()
                            for (i in 0 until jsonArray1.length()) {
                                val vendarSModel: DeleteServiceModel = Gson().fromJson(
                                    jsonArray1.getString(i).toString(),
                                    DeleteServiceModel::class.java
                                )
                                venderServicesModel.add(vendarSModel)
                            }

                            var adpter3 = VendorMyDeleteServicesAdapter(
                                venderServicesModel, applicationContext
                            )
                            val layoutManager = LinearLayoutManager(applicationContext)
                            layoutManager.orientation = LinearLayoutManager.VERTICAL
                            binding.deleteServicesRecy.layoutManager = layoutManager
                            binding.deleteServicesRecy.setHasFixedSize(true)
                            binding.deleteServicesRecy.adapter = adpter3
                        } else {
                            binding.empaty1.visibility = View.VISIBLE
                        }
                    } else {
                        binding.empaty.visibility = View.VISIBLE
                        binding.progressBar.visibility = View.GONE

                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("venderallser_ex", e.toString())
                    binding.progressBar.visibility = View.GONE
                    binding.empaty.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("venderallser_error", t.toString())
                binding.progressBar.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE
            }
        })

    }

    override fun onBackPressed() {
        if (binding.deleteLayout.isVisible) {
            binding.deleteHistory.isEnabled = true
            binding.serviceLayout.visibility = View.VISIBLE
            binding.deleteLayout.visibility = View.GONE
            vendorallservices()
        } else {
            super.onBackPressed()
        }
    }

    override fun refresh() {
    }


}