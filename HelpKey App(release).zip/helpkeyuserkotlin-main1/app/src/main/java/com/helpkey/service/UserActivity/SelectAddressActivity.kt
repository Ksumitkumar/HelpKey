package com.helpkey.service.UserActivity

import android.app.Activity
import android.graphics.Color
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.android.gms.common.api.Status
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.widget.AutocompleteSupportFragment
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.helpkey.service.Adapter.SelectAddressAdapter
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.ShowAddressModel
import com.helpkey.service.databinding.ActivitySelectAddressBinding
import org.json.JSONArray
import retrofit2.Call
import retrofit2.Response
import java.util.*
import kotlin.collections.ArrayList

class SelectAddressActivity : AppCompatActivity() {
    var location = "address"
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    var geocoder: Geocoder? = null
    lateinit var binding: ActivitySelectAddressBinding
    var prefrenceManager: PrefrenceManger1? = null
    var showAddressModels: ArrayList<ShowAddressModel> = ArrayList()

    companion object {
        lateinit var activity: Activity
    }

    var type = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectAddressBinding.inflate(layoutInflater)
        setContentView(binding.root)
        fusedLocationProviderClient =
            LocationServices.getFusedLocationProviderClient(this@SelectAddressActivity)
        Places.initialize(applicationContext, "AIzaSyCkPVrOq6BI6MotAkt-0iXV_vht5jwlU04")
        geocoder = Geocoder(this, Locale.getDefault())

        val autocompleteFragment =
            supportFragmentManager.findFragmentById(com.helpkey.service.R.id.autocomplete_fragment) as AutocompleteSupportFragment?

        (autocompleteFragment ?: return).setPlaceFields(
            listOf(
                Place.Field.ID,
                Place.Field.NAME,
                Place.Field.LAT_LNG,
                Place.Field.ADDRESS,
                Place.Field.PLUS_CODE
            )
        ).setCountry("IN")
        autocompleteFragment.setHint("Address")

        autocompleteFragment.setOnPlaceSelectedListener(object : PlaceSelectionListener {
            override fun onPlaceSelected(place: Place) {
                Log.e(
                    "search_location_saved",
                    place.name + " " +
                            place.address + " " +
                            place.latLng.latitude.toString() + "  " +
                            place.latLng.longitude.toString() + "  " +
                            place.address.toString()
                )
                val geocoder: Geocoder
                val addresses: List<Address>?
                geocoder = Geocoder(this@SelectAddressActivity, Locale.getDefault())

                addresses = geocoder.getFromLocation(
                    place.latLng.latitude,
                    place.latLng.longitude,
                    1
                ) // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                prefrenceManager!!.setlatitude(
                    place.latLng.latitude.toString(),
                    this@SelectAddressActivity
                )
                prefrenceManager!!.setlongitude(
                    place.latLng.longitude.toString(),
                    this@SelectAddressActivity
                )
                try {
                    val address: kotlin.String =
                        addresses!![0].getAddressLine(0) // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()

                    val city: kotlin.String = addresses[0].locality
                    val state: kotlin.String = addresses[0].adminArea
                    val country: kotlin.String = addresses[0].countryName
                    val postalCode: kotlin.String = addresses[0].postalCode
                    val knownName: kotlin.String = addresses[0].featureName
                    binding.houseNo.setText(addresses!![0].getAddressLine(0))
                    binding.city.setText(city)
                    binding.state.setText(state)
                    binding.pincode.setText(postalCode)
                    binding.roadname.setText(knownName)


                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("location", e.toString())
                }

            }

            override fun onError(status: Status) {
                status.status


            }
        })

        activity = this
        prefrenceManager = PrefrenceManger1(applicationContext)
        binding.addAddress.setOnClickListener {
            if (validation()) {
                addAddress()
            }
        }

        getAddress()

        binding.back.setOnClickListener {
            finish()
        }

        binding.AddNew.setOnClickListener(View.OnClickListener {
            binding.addressRecylview.visibility = View.GONE
            binding.scroll.visibility = View.VISIBLE
        })

        binding.home.setCardBackgroundColor(Color.parseColor("#C7FFF5"))
        binding.hometxt.setTextColor(Color.parseColor("#008069"))
        binding.office.setCardBackgroundColor(Color.parseColor("#F1F0F0"))
        binding.officetxt.setTextColor(Color.parseColor("#FF000000"))
        type = binding.hometxt.text.toString()

        binding.home.setOnClickListener {
            type = binding.hometxt.text.toString()
            binding.home.setCardBackgroundColor(Color.parseColor("#C7FFF5"))
            binding.hometxt.setTextColor(Color.parseColor("#008069"))
            binding.office.setCardBackgroundColor(Color.parseColor("#F1F0F0"))
            binding.officetxt.setTextColor(Color.parseColor("#FF000000"))
        }

        binding.office.setOnClickListener {
            type = binding.officetxt.text.toString()
            binding.home.setCardBackgroundColor(Color.parseColor("#F1F0F0"))
            binding.hometxt.setTextColor(Color.parseColor("#FF000000"))
            binding.office.setCardBackgroundColor(Color.parseColor("#C7FFF5"))
            binding.officetxt.setTextColor(Color.parseColor("#008069"))
        }

    }

    private fun addAddress() {
        Toast.makeText(this@SelectAddressActivity, prefrenceManager?.getlatitude(applicationContext).toString(),Toast.LENGTH_LONG).show()
        Toast.makeText(this@SelectAddressActivity,prefrenceManager?.getlongitude(applicationContext).toString(),Toast.LENGTH_LONG).show()
        Toast.makeText(this@SelectAddressActivity,prefrenceManager?.getUserid(applicationContext).toString(),Toast.LENGTH_LONG).show()
        binding.progress.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.address(
                prefrenceManager?.getUserid(applicationContext),
                prefrenceManager?.getlatitude(applicationContext),
                prefrenceManager?.getlongitude(applicationContext),
                binding.recipientName.text.toString() + ", " + binding.recipientNumber.text.toString() + ", " + binding.alternateNumber.text.toString() + ", " + binding.houseNo.text.toString() + ", " ,
                type
            )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                binding.progress.visibility = View.GONE
                Log.e(
                    "address_res",
                    response.body()
                        .toString() + "" + prefrenceManager?.getUserid(applicationContext) + " " +
                            binding.recipientName.text.toString() + " " + Constracter.lat +
                            Constracter.log,
                )

                if (response.isSuccessful) {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        getAddress()
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                        binding.addressRecylview.visibility = View.VISIBLE
                        binding.scroll.visibility = View.GONE
                        binding.addressRecylview.visibility = View.VISIBLE
                        binding.scroll.visibility = View.GONE
                        binding.recipientName.setText("")
                        binding.recipientNumber.setText("")
                        binding.alternateNumber.setText("")
                        binding.houseNo.setText("")
                        binding.roadname.setText("")
                        binding.city.setText("")
                        binding.state.setText("")
                        binding.pincode.setText("")
                    } else {
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()

                    }
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("address_error", t.toString())
                binding.progress.visibility = View.GONE

            }

        })
    }

    fun getAddress() {
        showAddressModels.clear()
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataService.getAddress(
            prefrenceManager?.getUserid(applicationContext)
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e("getAddress_res", response.body().toString())
                binding.progress.visibility = View.GONE
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonObject2 = jsonObject.getJSONArray("data")
                        for (i in 0 until jsonObject2.length()) {
                            val showAddressModel: ShowAddressModel = Gson().fromJson(
                                jsonObject2.getString(i).toString(),
                                ShowAddressModel::class.java
                            )
                            showAddressModels.add(showAddressModel)
                        }

                    } else {
                        binding.progress.visibility = View.GONE
                    }
                    val getAddress = SelectAddressAdapter(showAddressModels, applicationContext)
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.addressRecylview.layoutManager = layoutManager
                    binding.addressRecylview.setHasFixedSize(true)
                    binding.addressRecylview.adapter = getAddress


                } catch (e: Exception) {
                    Log.e("getAddress_error", e.toString())
                    binding.progress.visibility = View.GONE
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("getAddress_error", t.toString())
                binding.progress.visibility = View.GONE
            }

        })

    }

    private fun validation(): Boolean {
        if (binding.recipientName.text.toString().trim().isEmpty()) {
            binding.recipientName.error = "Enter Your Name"
            binding.recipientName.requestFocus()
        } else if (binding.recipientNumber.text.toString().trim().isEmpty()) {
            binding.recipientNumber.error = "Enter Your Mobile"
            binding.recipientNumber.requestFocus()
        } else if (binding.recipientNumber.text.toString().trim().length < 10) {
            binding.recipientNumber.error = "Enter Your Mobile"
            binding.recipientNumber.requestFocus()
        } else if (binding.houseNo.text.toString().trim().isEmpty()) {
            binding.houseNo.error = "Enter Your House No"
            binding.houseNo.requestFocus()
        } else if (binding.roadname.text.toString().trim().isEmpty()) {
            binding.roadname.error = "Enter Your Road Name, Area, Colony"
            binding.roadname.requestFocus()
        } else if (binding.pincode.text.toString().trim().isEmpty()) {
            binding.pincode.error = "Enter Your Pin Code"
            binding.pincode.requestFocus()
        } else if (binding.pincode.text.toString().trim().length < 6) {
            binding.pincode.error = "Enter the 6 digit"
            binding.pincode.requestFocus()
        } else if (binding.city.text.toString().trim().isEmpty()) {
            binding.city.error = "Enter Your City"
            binding.city.requestFocus()
        } else if (binding.state.text.toString().trim().isEmpty()) {
            binding.state.error = "Enter Your State"
            binding.state.requestFocus()
        } else {
            return true
        }
        return false
    }

    override fun onRestart() {
        super.onRestart()
        getAddress()
    }

    override fun onBackPressed() {
        super.onBackPressed()
       // Refresh.refresh()

    }
}