package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class VendorCategoryModel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("image")
    @Expose
    var image: String? = null

    @SerializedName("status")
    @Expose
    var status: Int? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null


    constructor(
        id: Int?,
        image: String?,
        status: Int?,
        createdAt: String?,
        updatedAt: String?
    ) : super() {
        this.id = id
        this.image = image
        this.status = status
        this.createdAt = createdAt
        this.updatedAt = updatedAt
    }
}