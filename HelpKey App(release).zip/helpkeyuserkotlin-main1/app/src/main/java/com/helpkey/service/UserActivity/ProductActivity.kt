package com.helpkey.service.UserActivity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Paint
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.squareup.picasso.Picasso
import com.helpkey.service.Adapter.ProductuserAdapter
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.ProductModel
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityProductBinding
import org.json.JSONArray
import retrofit2.Call
import retrofit2.Response

class ProductActivity : AppCompatActivity() {

    lateinit var binding: ActivityProductBinding
    var productModels: ArrayList<ProductModel> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.empaty.setAnimation(R.raw.datanotfound)

        binding.back.setOnClickListener {
            finish()
        }

        if (Constracter.point == "1") {
            binding.tital.text = "Helpkey Point"
            binding.li2.visibility = View.VISIBLE
            binding.li1.visibility = View.GONE
            binding.li.visibility = View.GONE
            binding.address.text = intent.getStringExtra("address")
            binding.poindId.text = "HK0"+intent.getStringExtra("vendor_id")
            binding.productName.text = intent.getStringExtra("name")
            binding.description.text = intent.getStringExtra("description")
            binding.contact.text = "+91 " + intent.getStringExtra("mobile")
            binding.contact.paintFlags = binding.contact.paintFlags or Paint.UNDERLINE_TEXT_FLAG
            binding.discount.text = intent.getStringExtra("discount") + "%"
            binding.address.text = intent.getStringExtra("address")
            Picasso.get().load(
                "https://panels.helpkey.in/public/images/coverimage/" +
                        intent.getStringExtra("cimg")
            ).into(binding.coverImage)
            Picasso.get().load(
                "https://panels.helpkey.in/public/images/serviceimage/" +
                        intent.getStringExtra("simg")
            ).into(binding.serviceImg)

        } else {
            binding.tital.text = intent.getStringExtra("name").toString()
            binding.li1.visibility = View.VISIBLE
            binding.li2.visibility = View.GONE
            if (intent.getStringExtra("address").toString() == "vendorcat") {
                Log.e("point", "1")
                product_bysubcategory()
            } else {
                Log.e("point", "2")
                product_user()
            }
        }

        binding.contact.setOnClickListener {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CALL_PHONE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CALL_PHONE),
                    100
                )
            } else {
                val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", binding.contact.text.toString(), null))
                startActivity(intent)
            }
        }
    }

    fun product_user() {
        binding.progress.visibility = View.VISIBLE
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonArray> = getDataService.fetch_vendorservice(
            intent.getStringExtra("vendor_id")
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e("product_res", response.body().toString())
                binding.progress.visibility = View.GONE
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonObject2 = jsonObject.getJSONArray("data")
                        if (jsonObject2.length() > 0) {
                            for (i in 0 until jsonObject2.length()) {
                                val productModel: ProductModel = Gson().fromJson(
                                    jsonObject2.getString(i).toString(),
                                    ProductModel::class.java
                                )
                                productModels.add(productModel)
                            }

                        } else {
                            binding.empaty.visibility = View.VISIBLE
                        }

                    } else {
                        binding.empaty.visibility = View.VISIBLE
                    }
                    var adpter3 = ProductuserAdapter(productModels, applicationContext)
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.productRecylview.layoutManager = layoutManager
                    binding.productRecylview.setHasFixedSize(true)
                    binding.productRecylview.adapter = adpter3

                } catch (e: Exception) {
                    Log.e("product_error", e.toString())
                    binding.progress.visibility = View.GONE
                    binding.empaty.visibility = View.VISIBLE
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("product_error", t.toString())
                binding.progress.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE
            }

        })

    }

    fun product_bysubcategory() {
        binding.progress.visibility = View.VISIBLE
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonArray> = getDataService.fetch_vendorservicecate(
            Constracter.vendor_id,
            Constracter.category_id,
            Constracter.subcategory_id
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e(
                    "productsub_res",
                    response.body().toString() + " " + call.request().url().toString()
                )
                binding.progress.visibility = View.GONE
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonObject2 = jsonObject.getJSONArray("data")
                        if (jsonObject2.length() > 0) {

                            for (i in 0 until jsonObject2.length()) {
                                val productModel: ProductModel = Gson().fromJson(
                                    jsonObject2.getString(i).toString(),
                                    ProductModel::class.java
                                )
                                productModels.add(productModel)
                            }

                        } else {
                            binding.empaty.visibility = View.VISIBLE
                        }

                    } else {

                        binding.empaty.visibility = View.VISIBLE
                    }
                    var adpter3 = ProductuserAdapter(productModels, applicationContext)
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.productRecylview.layoutManager = layoutManager
                    binding.productRecylview.setHasFixedSize(true)
                    binding.productRecylview.adapter = adpter3

                } catch (e: Exception) {
                    Log.e("productsub_error", e.toString())
                    binding.progress.visibility = View.GONE
                    binding.empaty.visibility = View.VISIBLE
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("productsub_error", t.toString())
                binding.progress.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE
            }

        })

    }

}