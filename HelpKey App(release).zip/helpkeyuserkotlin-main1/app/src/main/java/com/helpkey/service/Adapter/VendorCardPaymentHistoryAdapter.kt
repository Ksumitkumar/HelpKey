package com.helpkey.service.Adapter

import android.content.Context
import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.helpkey.service.Models.VendorCardPaymentHistoryModel
import com.helpkey.service.databinding.VendorcardHistoryLayoutBinding
import java.text.DecimalFormat

class VendorCardPaymentHistoryAdapter(var list: ArrayList<VendorCardPaymentHistoryModel>, var context: Context): RecyclerView.Adapter<VendorCardPaymentHistoryAdapter.ViewHolder>() {

    var amount = ""

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VendorCardPaymentHistoryAdapter.ViewHolder {
        val binding = VendorcardHistoryLayoutBinding.inflate(LayoutInflater.from(context),parent,false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: VendorCardPaymentHistoryAdapter.ViewHolder, position: Int) {
        holder.binding.servicename.text = list[position].servicename.toString()
        holder.binding.name.text = list[position].username.toString()
        holder.binding.cardNo.text = list[position].cardNo.toString()
        holder.binding.address.text = list[position].address.toString()
        holder.binding.discount.text = "₹ "+list[position].discount.toString()
        holder.binding.totalAmount.text = "₹ "+list[position].totalAmount.toString()
        holder.binding.totalAmount.paintFlags = Paint.STRIKE_THRU_TEXT_FLAG
        holder.binding.discountedAmount.text = "₹ "+list[position].discountedAmount.toString()
        val i2: Double = list[position].discountedAmount!!.toDouble()
        holder.binding.discountedAmount.setText(DecimalFormat("##.##").format(i2))
        holder.binding.date.text = list[position].createdAt.toString()

    }

    override fun getItemCount(): Int {
     return list.size
    }

    inner class ViewHolder(var binding: VendorcardHistoryLayoutBinding): RecyclerView.ViewHolder(binding.root)
}