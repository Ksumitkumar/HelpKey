package com.helpkey.service.VendorActivity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.helpkey.service.Adapter.VendorTodayorderAdapter
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.Refresh
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.VendorAllOrderRequestModel
import com.helpkey.service.databinding.ActivityProductItemBinding
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response

class Product_itemActivity : AppCompatActivity(), Refresh {

    var addresss = ""
    lateinit var binding:ActivityProductItemBinding
    var prefrenceManager: PrefrenceManger1? = null

    companion object {
        lateinit var activity: Product_itemActivity
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityProductItemBinding.inflate(layoutInflater)
        setContentView(binding.root)
        activity = this@Product_itemActivity
        prefrenceManager = PrefrenceManger1(applicationContext)
        binding.mtoolbar.setNavigationOnClickListener(View.OnClickListener { finish() })

        addresss = intent.getStringExtra("VendordashAddress").toString()

        when (addresss) {
            "completeServices" -> {
                binding.mtoolbar.title = "Complete Service Request"
                Vendorcompleteorderservices()
            }
            "uncomplete" -> {
                binding.mtoolbar.title = "Uncompleted Services"
                Vendoruncompleteorderservices()
            }
            "allServices" -> {
                binding.mtoolbar.title = "Cancel Services"
                  cencelvendor()
            }"vendorallservices" -> {
                binding.mtoolbar.title = "Vendor All Services"
            }
        }

    }
   fun Vendorcompleteorderservices() {
       binding.progressBar.visibility = View.VISIBLE
       val getDataService: GetDataService =
           RetrofitClintanse.getInstance().create(GetDataService::class.java)
       val call: Call<JsonObject> =
           getDataService.Vendorcompleteorderservices(
               prefrenceManager?.getUserid(applicationContext)
           )
       call.enqueue(object : retrofit2.Callback<JsonObject> {
           override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
               try {
                   Log.e("Vallrequest_response", response.body().toString())

                   val jsonObject = JSONObject(Gson().toJson(response.body()))
                   var vendorAllOrderRequestModel: ArrayList<VendorAllOrderRequestModel> =
                       ArrayList()
                   val res = jsonObject.getString("status")
                   if (res.equals("success")) {
                       binding.progressBar.visibility = View.GONE
                       val jsonArray1 = jsonObject.getJSONArray("data")
                       Log.e("Vallrequest", jsonObject.toString())
                       if (jsonArray1.length() > 0) {
                           for (i in 0 until jsonArray1.length()) {
                               val vendarSModel: VendorAllOrderRequestModel = Gson().fromJson(
                                   jsonArray1.getString(i).toString(),
                                   VendorAllOrderRequestModel::class.java
                               )
                               vendorAllOrderRequestModel.add(vendarSModel)


                           }
                       } else {
                           Toast.makeText(this@Product_itemActivity,"Data not Fount",Toast.LENGTH_SHORT).show()
                           binding.empaty.visibility = View.VISIBLE
                       }

                   } else {

                       binding.progressBar.visibility = View.GONE
                       binding.empaty.visibility = View.VISIBLE

                   }

                   var adpter3 = VendorTodayorderAdapter(vendorAllOrderRequestModel, applicationContext)
                   val layoutManager = LinearLayoutManager(applicationContext)
                   layoutManager.orientation = LinearLayoutManager.VERTICAL
                   binding.productRecylview.layoutManager = layoutManager
                   binding.productRecylview.setHasFixedSize(true)
                   binding.productRecylview.adapter = adpter3

               } catch (e: JSONException) {
                   e.printStackTrace()
                   Log.e("Vallrequest_ex", e.toString())
                   binding.progressBar.visibility = View.GONE
                   binding.empaty.visibility = View.VISIBLE
               }
           }

           override fun onFailure(call: Call<JsonObject>, t: Throwable) {
               Log.i("Vallrequest_error", t.toString())
               binding.progressBar.visibility = View.GONE
               binding.empaty.visibility = View.VISIBLE
           }
       })

    }

    fun  cencelvendor() {
        binding.progressBar.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.vendorcancelService(
                prefrenceManager?.getUserid(applicationContext).toString()
            )

        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {

                try {
                    Log.e("Vallrequest_response", response.body().toString())

                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progressBar.visibility = View.GONE
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Log.e("Vallrequest", jsonObject.toString())
                        var vendorAllOrderRequestModel: ArrayList<VendorAllOrderRequestModel> =
                            ArrayList()
                        for (i in 0 until jsonArray1.length()) {
                            val vendarSModel: VendorAllOrderRequestModel = Gson().fromJson(
                                jsonArray1.getString(i).toString(),
                                VendorAllOrderRequestModel::class.java
                            )
                            vendorAllOrderRequestModel.add(vendarSModel)


                        }

                        var adpter3 = VendorTodayorderAdapter(vendorAllOrderRequestModel, applicationContext)
                        val layoutManager = LinearLayoutManager(applicationContext)
                        layoutManager.orientation = LinearLayoutManager.VERTICAL
                        binding.productRecylview.layoutManager = layoutManager
                        binding.productRecylview.setHasFixedSize(true)
                        binding.productRecylview.adapter = adpter3

                        Log.e("servicecount1", vendorAllOrderRequestModel.size.toString())

                    } else {


                        binding.progressBar.visibility = View.GONE
                        binding.empaty.visibility = View.VISIBLE
                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("Vallrequest_ex", e.toString())
                    binding.progressBar.visibility = View.GONE
                    binding.empaty.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("Vallrequest_error", t.toString())
                binding.progressBar.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE
            }
        })
    }

    fun  Vendoruncompleteorderservices() {
        binding.progressBar.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.vendorUncompleteService(
                prefrenceManager?.getUserid(applicationContext).toString()
            )

        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e("Vuncomplete_response", response.body().toString())

                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progressBar.visibility = View.GONE
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Log.e("Vuncomplete", jsonObject.toString())
                        var vendorAllOrderRequestModel: ArrayList<VendorAllOrderRequestModel> =
                            ArrayList()
                        for (i in 0 until jsonArray1.length()) {
                            val vendarSModel: VendorAllOrderRequestModel = Gson().fromJson(
                                jsonArray1.getString(i).toString(),
                                VendorAllOrderRequestModel::class.java
                            )
                            vendorAllOrderRequestModel.add(vendarSModel)


                        }

                        var adpter3 = VendorTodayorderAdapter(vendorAllOrderRequestModel, this@Product_itemActivity)
                        val layoutManager = LinearLayoutManager(applicationContext)
                        layoutManager.orientation = LinearLayoutManager.VERTICAL
                        binding.productRecylview.layoutManager = layoutManager
                        binding.productRecylview.setHasFixedSize(true)
                        binding.productRecylview.adapter = adpter3


                    } else {


                        binding.progressBar.visibility = View.GONE
                        binding.empaty.visibility = View.VISIBLE
                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("Vuncomplete_ex", e.toString())
                    binding.progressBar.visibility = View.GONE
                    binding.empaty.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("Vuncomplete_error", t.toString())
                binding.progressBar.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE
            }
        })

    }

    fun call() {
        if (ContextCompat.checkSelfPermission(
                this@Product_itemActivity,
                Manifest.permission.CALL_PHONE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this@Product_itemActivity,
                arrayOf(Manifest.permission.CALL_PHONE),
                100
            )
        } else {
            val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", Constracter.mobile, null))
            this@Product_itemActivity.startActivity(intent)
        }
    }



    override fun refresh() {
    }
    override fun onRestart() {
        super.onRestart()
    }
}