package com.helpkey.service.UserActivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.helpkey.service.Adapter.PointsAdapter
import com.helpkey.service.Adapter.VendorsAdapter
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.PointServicesModel
import com.helpkey.service.Models.VendoruserModel
import com.helpkey.service.databinding.ActivityVendorAcitivityBinding
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response

class VendorAcitivityUser : AppCompatActivity() {
    lateinit var binding: ActivityVendorAcitivityBinding
    var vendoruserModels: ArrayList<VendoruserModel> = ArrayList()
    var pointServicesModel: ArrayList<PointServicesModel> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVendorAcitivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.tital.text = intent.getStringExtra("name").toString()
        binding.back.setOnClickListener {
            finish()
        }

        if (Constracter.point == "1") {
            point_user()
        } else {
            vendor_user()
        }

    }

    fun vendor_user() {
        binding.progress.visibility = View.VISIBLE
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonObject> = getDataService.fetch_vendor_by_subcategory(
            intent.getStringExtra("cat_id"),
            intent.getStringExtra("subcat_id")
        )
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("vendor_res", response.body().toString()+" "+call.request().url().toString()
                        +" "+intent.getStringExtra("cat_id"))
                binding.progress.visibility = View.GONE
               try {
                   val jsonObject = JSONObject(Gson().toJson(response.body()))
                   val res = jsonObject.getString("status")
                   if (res.equals("success")) {
                       val jsonObject2 = jsonObject.getJSONArray("data")
                       Log.e("fd", jsonObject2.toString())
                       if (jsonObject2.length() > 0) {

                           for (i in 0 until jsonObject2.length()) {
                               val vendoruserModel: VendoruserModel = Gson().fromJson(
                                   jsonObject2.getString(i).toString(),
                                   VendoruserModel::class.java
                               )
                               vendoruserModels.add(vendoruserModel)
                           }

                       } else {
                           binding.empaty.visibility = View.VISIBLE
                       }


                   } else {
                       binding.empaty.visibility = View.VISIBLE
                   }
                   var adpter3 = VendorsAdapter(vendoruserModels, applicationContext)
                   val layoutManager = LinearLayoutManager(applicationContext)
                   layoutManager.orientation = LinearLayoutManager.VERTICAL
                   binding.recylviewVendor.layoutManager = layoutManager
                   binding.recylviewVendor.setHasFixedSize(true)
                   binding.recylviewVendor.adapter = adpter3

               }catch (e: Exception){
                   Log.e("vendor_error",e.toString())
                   binding.progress.visibility = View.GONE
                   binding.empaty.visibility = View.VISIBLE
               }

            }
            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("vendor_error", t.toString())
                binding.progress.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE
            }

        })

    }


    fun point_user() {
        binding.progress.visibility = View.VISIBLE
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonObject> = getDataService.fetch_point_by_subcategory(
            intent.getStringExtra("cat_id"),
            intent.getStringExtra("subcat_id")
        )
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("point_res", response.body().toString()+" "+intent.getStringExtra("subcat_id")
                        +" "+intent.getStringExtra("cat_id"))
                binding.progress.visibility = View.GONE
               try {
                   val jsonArray = JSONObject(Gson().toJson(response.body()))
                   val res = jsonArray.getString("status")
                   if (res.equals("success")) {
                       val jsonObject = jsonArray.getJSONArray("data")

                       Log.e("point", jsonObject.toString())
                       if (jsonObject.length() > 0) {

                           for (i in 0 until jsonObject.length()) {
                               val point: PointServicesModel = Gson().fromJson(
                                   jsonObject.getString(i).toString(),
                                   PointServicesModel::class.java
                               )
                               pointServicesModel.add(point)
                           }

                       } else {
                           binding.empaty.visibility = View.VISIBLE
                       }

                   } else {
                       binding.empaty.visibility = View.VISIBLE
                   }
                   var adpter3 = PointsAdapter(pointServicesModel, applicationContext)
                   val layoutManager = LinearLayoutManager(applicationContext)
                   layoutManager.orientation = LinearLayoutManager.VERTICAL
                   binding.recylviewVendor.layoutManager = layoutManager
                   binding.recylviewVendor.setHasFixedSize(true)
                   binding.recylviewVendor.adapter = adpter3

               }catch (e: Exception){
                   Log.e("point_exe",e.toString())
                   binding.progress.visibility = View.GONE
                   binding.empaty.visibility = View.VISIBLE
               }

            }
            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("point_error", t.toString())
                binding.progress.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE
            }

        })

    }
}