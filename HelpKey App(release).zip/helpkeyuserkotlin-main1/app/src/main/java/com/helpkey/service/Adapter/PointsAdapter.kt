package com.helpkey.service.Adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.helpkey.service.Models.PointServicesModel
import com.helpkey.service.UserActivity.ProductActivity
import com.helpkey.service.databinding.RecviewVendorBinding

class PointsAdapter(var list: ArrayList<PointServicesModel>, var context: Context) : RecyclerView.Adapter<PointsAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: RecviewVendorBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            RecviewVendorBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        Picasso.get().load("https://panels.helpkey.in/public/images/serviceimage/"+list.get(position).serviceimage).into(holder.binding.img)
        Log.e("image","https://panels.helpkey.in/public/images/serviceimage/"+ list[position].serviceimage)
        holder.binding.title.text = list[position].servicename
        holder.binding.discirption.text = list[position].description
        holder.binding.location.text = list[position].address

        holder.binding.card.setOnClickListener {
            var intent = Intent(context, ProductActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            intent.putExtra("vendor_id",list[position].vendorId.toString())
            intent.putExtra("name",list[position].servicename.toString())
            intent.putExtra("mobile",list[position].mobile.toString())
            intent.putExtra("address",list[position].address.toString())
            intent.putExtra("dicount",list[position].discount.toString())
            intent.putExtra("description",list[position].description.toString())
            intent.putExtra("cimg",list[position].coverimage.toString())
            intent.putExtra("simg",list[position].serviceimage.toString())
            intent.putExtra("discount",list[position].percentage.toString())
            context.startActivity(intent)
        }

    }

    override fun getItemCount(): Int {
        return list.size
    }
}