package com.helpkey.service.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.helpkey.service.Models.UserOrderServiceModel
import com.helpkey.service.databinding.UserServicesOrderLayoutBinding

class UserOrderServicesAdapter(var list: ArrayList<UserOrderServiceModel>, var context: Context) :
    RecyclerView.Adapter<UserOrderServicesAdapter.MyViewHolder>() {
    var cost: Double? = null
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): UserOrderServicesAdapter.MyViewHolder {
        val binding =
            UserServicesOrderLayoutBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UserOrderServicesAdapter.MyViewHolder, position: Int) {

        try {
            cost = list[position].serviceCost?.toDouble()
            if (cost!! <= 0) {
                holder.binding.serviceCost1.visibility = View.GONE
            } else {
                holder.binding.serviceCost1.text = "₹ "+cost.toString()
            }
        } catch (e:Exception) {
            e.printStackTrace()

        }


        holder.binding.vendorName1.text = list[position].vendorName
//        holder.binding.serviceCost1.text = "₹ " + list[position].serviceCost
        holder.binding.serviceName1.text = list[position].serviceName


    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class MyViewHolder(var binding: UserServicesOrderLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {

    }
}