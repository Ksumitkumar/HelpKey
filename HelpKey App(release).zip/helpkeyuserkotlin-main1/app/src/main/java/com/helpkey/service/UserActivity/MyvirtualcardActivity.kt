package com.helpkey.service.UserActivity

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.squareup.picasso.Picasso
import com.helpkey.service.Adapter.FamliycardAdapter
import com.helpkey.service.Adapter.UserCardPaymentHistoryAdapter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.FamliyCardModel
import com.helpkey.service.Models.UserCardPaymentHistoryModel
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityMyvirtualcardBinding
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import java.io.File
import java.util.ArrayList

@Suppress("DEPRECATION")
class MyvirtualcardActivity : AppCompatActivity() {
    var prefrenceManager: PrefrenceManger1? = null

    var ur2: Uri? = null
    var ur1: Uri? = null
    var uri: Uri? = null

    companion object {
        lateinit var list: MultipartBody.Part
        lateinit var list1: MultipartBody.Part
        lateinit var list2: MultipartBody.Part
    }

    var famliyCardModels: ArrayList<FamliyCardModel> = ArrayList()
    var userCardPaymentHistoryModel: ArrayList<UserCardPaymentHistoryModel> = ArrayList()
    lateinit var binding: ActivityMyvirtualcardBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyvirtualcardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefrenceManager = PrefrenceManger1(applicationContext)

        binding.wait.setAnimation(R.raw.waiting)
        binding.empaty.setAnimation(R.raw.datanotfound)
        binding.back.setOnClickListener {
            if (binding.mainLayout.isVisible) {
                finish()
            } else {
                binding.historyLayout.visibility = View.GONE
                binding.mainLayout.visibility = View.VISIBLE
            }
        }
        cardGenreat()

        binding.faimlyCard.setOnClickListener {
            binding.famliymemberView.visibility = View.VISIBLE
            binding.cardView.visibility = View.GONE
            binding.famliycardRecylview.visibility = View.GONE
        }

        binding.paynow.setOnClickListener {

            if (uri?.path.equals(null)) {
                Toast.makeText(
                    this@MyvirtualcardActivity,
                    "Please Upload Your Document",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                profile_check()

            }

        }

        binding.history.setOnClickListener {
            if (binding.mainLayout.isVisible) {
                binding.historyLayout.visibility = View.VISIBLE
                binding.mainLayout.visibility = View.GONE
                history()
            }
        }

        binding.paynowFamliy.setOnClickListener {
            if (ur1?.path.equals(null)) {
                Toast.makeText(
                    this@MyvirtualcardActivity,
                    "Please Upload Profile Image",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                if (ur2?.path.equals(null)) {
                    Toast.makeText(
                        this@MyvirtualcardActivity,
                        "Please Upload Document Image",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    if (validation()) {
                        orderGenreatFamily()
                    } else {
                        Toast.makeText(
                            this@MyvirtualcardActivity,
                            "Please Fill All Field",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }

        binding.uplaodImg.setOnClickListener {
            ImagePicker.with(this)
                .crop()
                .compress(1024)
                .maxResultSize(
                    1080,
                    1080
                )
                .start(101)
        }

        binding.editImg.setOnClickListener {

            ImagePicker.with(this)
                .crop()
                .compress(1024)
                .maxResultSize(
                    1080,
                    1080
                )
                .start(102)

        }

        binding.famliyuplaodImg.setOnClickListener {

            ImagePicker.with(this)
                .crop()
                .compress(1024)
                .maxResultSize(
                    1080,
                    1080
                )
                .start(103)

        }

    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (resultCode) {
            Activity.RESULT_OK -> {
                Log.e("resultCode", requestCode.toString())
                when (requestCode) {
                    101 -> {
                        uri = data?.data!!

                        val file = File(uri?.path!!)
                        val requestFile = RequestBody.create(MediaType.parse("*/*"), file)
                        val imagess = MultipartBody.Part.createFormData(
                            "document_image",
                            uri?.path,
                            requestFile
                        )
                        list = imagess
                        binding.image.setImageURI(uri)

                        if (uri !== null) {
                            binding.paynow.visibility = View.VISIBLE

                        } else {
                            Toast.makeText(
                                applicationContext,
                                " Please Upload Document",
                                Toast.LENGTH_SHORT
                            ).show()

                        }
                    }
                    102 -> {

                        ur1 = data?.data!!
                        val file = File(ur1?.path!!)
                        val requestFile = RequestBody.create(MediaType.parse("*/*"), file)
                        val imagess = MultipartBody.Part.createFormData(
                            "photo",
                            ur1?.path,
                            requestFile
                        )

                        Log.e("imaged", ur1.toString())
                        list1 = imagess
                        binding.profileImg.setImageURI(ur1)


                        if (ur1 !== null) {
                            //   binding.paynow.visibility = View.VISIBLE

                        } else {
                            Toast.makeText(
                                applicationContext,
                                " Please Upload Document",
                                Toast.LENGTH_SHORT
                            ).show()

                        }

                    }
                    103 -> {

                        ur2 = data?.data!!

                        val file = File(ur2?.path)
                        val requestFile = RequestBody.create(MediaType.parse("*/*"), file)
                        val imagess = MultipartBody.Part.createFormData(
                            "document_image",
                            ur2?.path,
                            requestFile
                        )
                        list2 = imagess
                        binding.imageFamliy.setImageURI(ur2)
                        Log.e("image", ur2.toString())

                        if (ur2 !== null) {
                            // binding.paynow.visibility = View.VISIBLE

                        } else {
                            Toast.makeText(
                                applicationContext,
                                " Please Upload  Family Document",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                }

            }
            ImagePicker.RESULT_ERROR -> {
                Toast.makeText(this, ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
            }
            else -> {
                Toast.makeText(this, "Task Cancelled", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun profile_check() {
        val getDataServices: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataServices.verify_profile(
            prefrenceManager?.getUserid(applicationContext)
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {

                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e("check_res", jsonArray.toString())
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        if (jsonObject.getString("message") == "User profile update") {
                            orderGenreat()

                        } else {
                            Toast.makeText(
                                applicationContext,
                                " Please profile update ",
                                Toast.LENGTH_SHORT
                            ).show()
                            val intent =
                                Intent(this@MyvirtualcardActivity, EditeActivity::class.java)
                            startActivity(intent)
                        }

                    } else {
                        Log.e("check", "not Available")
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("check_exe", e.toString())

                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("check_err", t.toString())

            }

        })

    }

    fun orderGenreat() {
        binding.progress.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.orderid(
                prefrenceManager?.getUserid(applicationContext)
            )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e("verCard_res", response.body().toString())

                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progress.visibility = View.GONE
                        val jsonArray1 = jsonObject.getJSONObject("data")

                        val mainIntent = Intent(
                            this@MyvirtualcardActivity,
                            VerchualcardPaymentActivity::class.java
                        )
                        mainIntent.putExtra("orderid", jsonArray1.getString("order_id"))
                        startActivity(mainIntent)
                    } else {
                        binding.progress.visibility = View.GONE
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("verCard_exe", e.toString())
                    binding.progress.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("verCard_err", t.toString())
                binding.progress.visibility = View.GONE
            }
        })
    }


    fun orderGenreatFamily() {
        binding.progress.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.orderid(
                prefrenceManager?.getUserid(applicationContext)
            )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    binding.progress.visibility = View.GONE
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonArray1 = jsonObject.getJSONObject("data")

                        val intent = Intent(
                            this@MyvirtualcardActivity,
                            FaimalyVerchalpaymentActivity::class.java
                        )
                        intent.putExtra("orderid", jsonArray1.getString("order_id"))
                        intent.putExtra("name", binding.familyName.text.toString())
                        intent.putExtra("work", binding.familyWork.text.toString())
                        intent.putExtra("address", binding.familyAddresss.text.toString())
                        intent.putExtra("city", binding.familyCity.text.toString())
                        intent.putExtra("state", binding.familyState.text.toString())
                        intent.putExtra("pin", binding.familyPincode.text.toString())
                        startActivity(intent)
                    } else {
                        binding.progress.visibility = View.GONE
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("verCard_ex", e.toString())
                    binding.progress.visibility = View.GONE

                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("verCard_error", t.toString())
                binding.progress.visibility = View.GONE

            }

        })
    }

    fun cardGenreat() {
        binding.progress.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.fetch_virtual_card(
                prefrenceManager?.getUserid(applicationContext)
            )
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("genCard_res", response.body().toString())
                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progress.visibility = View.GONE
                        val message = jsonObject.getString("message")
                        if (message == "Under process, card not generated yet") {
                            binding.waitLayout.visibility = View.VISIBLE
                        } else {
                            val jsonObject1 = jsonObject.getJSONObject("data")
                            var s = ""
                            val s2 = jsonObject1.getString("virtual_card_no").toCharArray()
                            for (i in s2.indices) {
                                when (i) {
                                    3 -> {
                                        s += s2.get(i) + "   "
                                    }
                                    7 -> {
                                        s += s2.get(i) + "   "
                                    }
                                    11 -> {
                                        s += s2.get(i) + "   "
                                    }
                                    else -> {
                                        s += s2.get(i)
                                    }
                                }
                            }
                            Picasso.get().load(
                                "https://panels.helpkey.in/images/profileImage/" + jsonObject1.optString("image")
                            ).placeholder(R.drawable.logo).into(binding.userProfile)
                            binding.cardNo.text = s
                            binding.cardName.text = jsonObject1.getString("user_name")
                            binding.exDate.text = jsonObject1.getString("card_validity")
                            binding.address.text = buildString {
                                append("Address:-  ")
                                append(jsonObject1.getString("address"))
                            }
                            binding.userWork.text = jsonObject1.getString("work")
                            val qrCodeWriter = QRCodeWriter()
                            val bitMatrix =
                                qrCodeWriter.encode(
                                    "https://panels.helpkey.in/user_cart/${
                                        jsonObject1.getString("id")
                                    }/card",
                                    BarcodeFormat.QR_CODE,
                                    200,
                                    200
                                )
                            val bitmap = Bitmap.createBitmap(200, 200, Bitmap.Config.RGB_565)
                            for (x in 0..199) {
                                for (y in 0..199) {
                                    bitmap.setPixel(
                                        x,
                                        y,
                                        if (bitMatrix[x, y]) Color.BLACK else Color.WHITE
                                    )
                                }
                            }
                            binding.userQr.setImageBitmap(bitmap)

                            if (message.equals("Card generate")) {
                                // Card Show
                                binding.cardView.visibility = View.VISIBLE
                                binding.memmberView.visibility = View.GONE
                                binding.faimlyCard.visibility = View.VISIBLE
                                cardGenreatFamily()
                            } else {
                                // Card Not Show
                                binding.cardView.visibility = View.GONE
                                binding.memmberView.visibility = View.VISIBLE
                                binding.faimlyCard.visibility = View.GONE
                            }
                        }

                    } else {
                        binding.progress.visibility = View.GONE
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("genCard_ex", e.toString())
                    binding.progress.visibility = View.GONE


                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("genCard_error", t.toString())
                binding.progress.visibility = View.GONE

            }

        })
    }

    fun cardGenreatFamily() {
        binding.progress.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.fetch_card_family(
                prefrenceManager?.getUserid(applicationContext)
            )
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e(
                    "famcard_res",
                    response.body().toString() + " " + call.request().url().toString()
                )
                Log.e("famcard_res", prefrenceManager?.getUserid(applicationContext).toString())

                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progress.visibility = View.GONE
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        for (i in 0 until jsonArray1.length()) {
                            val famliyCardModel: FamliyCardModel = Gson().fromJson(
                                jsonArray1.getString(i).toString(),
                                FamliyCardModel::class.java
                            )
                            famliyCardModels.add(famliyCardModel)
                        }

                        val adpter3 = FamliycardAdapter(famliyCardModels, applicationContext)
                        val layoutManager = LinearLayoutManager(applicationContext)
                        layoutManager.orientation = LinearLayoutManager.VERTICAL
                        binding.famliycardRecylview.layoutManager = layoutManager
                        binding.famliycardRecylview.setHasFixedSize(true)
                        binding.famliycardRecylview.adapter = adpter3

                    } else {
                        binding.progress.visibility = View.GONE
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("famcard_ex", e.toString())
                    binding.progress.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("famcard_error", t.toString())
                binding.progress.visibility = View.GONE

            }

        })
    }

    fun history() {
        userCardPaymentHistoryModel.clear()
        binding.empaty.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.usercardtransationhistory(prefrenceManager?.getUserid(applicationContext))
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("History_res", response.body().toString())
                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progressBar.visibility = View.GONE
                        val jsonArray = jsonObject.getJSONArray("data")
                        Log.e("data", jsonArray.toString())
                        if (jsonArray.length() > 0) {
                            for (i in 0 until jsonArray.length()) {
                                val history: UserCardPaymentHistoryModel = Gson().fromJson(
                                    jsonArray.getString(i).toString(),
                                    UserCardPaymentHistoryModel::class.java
                                )
                                userCardPaymentHistoryModel.add(history)
                            }
                        } else {
                            binding.progressBar.visibility = View.GONE
                            binding.empaty.visibility = View.VISIBLE
                        }
                    } else {
                        binding.progressBar.visibility = View.GONE
                        binding.empaty.visibility = View.VISIBLE
                    }

                    val adpter3 = UserCardPaymentHistoryAdapter(
                        userCardPaymentHistoryModel,
                        applicationContext
                    )
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.historyRecy.layoutManager = layoutManager
                    binding.historyRecy.setHasFixedSize(true)
                    binding.historyRecy.adapter = adpter3

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("History_exe", e.toString())
                    binding.progressBar.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("History_error", t.toString())
                binding.progressBar.visibility = View.GONE
            }

        })
    }

    private fun validation(): Boolean {
        if (binding.familyName.text.toString().trim().isEmpty()) {
            binding.familyName.error = "Enter Your Name"
            binding.familyName.requestFocus()
        } else if (binding.familyWork.text.toString().trim().isEmpty()) {
            binding.familyWork.error = "Enter Your Family Work"
            binding.familyWork.requestFocus()
        } else if (binding.familyAddresss.text.toString().trim().isEmpty()) {
            binding.familyAddresss.error = "Enter Your Family Address"
            binding.familyAddresss.requestFocus()
        } else if (binding.address.text.toString().trim().isEmpty()) {
            binding.address.error = "Enter Your Family Address"
            binding.address.requestFocus()
        } else if (binding.familyPincode.text.toString().trim().isEmpty()) {
            binding.familyPincode.error = "Enter Your Family Pincode"
            binding.familyPincode.requestFocus()
        } else if (binding.familyCity.text.toString().trim().isEmpty()) {
            binding.familyCity.error = "Enter Your Family City"
            binding.familyCity.requestFocus()
        } else if (binding.familyState.text.toString().trim().isEmpty()) {
            binding.familyState.error = "Enter Your Family State"
            binding.familyState.requestFocus()
        } else {
            return true
        }
        return false
    }

    override fun onBackPressed() {
        if (binding.mainLayout.isVisible) {
            super.onBackPressed()

        } else {
            binding.historyLayout.visibility = View.GONE
            binding.mainLayout.visibility = View.VISIBLE
            cardGenreat()
        }

    }
}