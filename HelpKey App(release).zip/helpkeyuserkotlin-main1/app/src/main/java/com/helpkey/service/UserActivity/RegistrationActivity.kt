package com.helpkey.service.UserActivity

import android.Manifest
import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.databinding.ActivityRegistrationBinding
import org.json.JSONArray
import org.json.JSONException
import retrofit2.Call
import retrofit2.Response
import java.util.*


class RegistrationActivity : AppCompatActivity() {

    lateinit var binding: ActivityRegistrationBinding
    var prefrenceManager: PrefrenceManger1? = null
    var gender = "Male"
    var latitude = ""
    var longitude = ""
    internal val TAG = "LocationProvider"
    internal val REQUEST_PERMISSIONS_REQUEST_CODE = 34
    var localaddress = ""

    private lateinit var mFusedLocationClient: FusedLocationProviderClient
    private var lastLocation: Location? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistrationBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        prefrenceManager = PrefrenceManger1(applicationContext)

        binding.mobile.setText(prefrenceManager?.getmobilno(applicationContext).toString())
        binding.signUp.setOnClickListener {

            if (validation()) {
                user_upload()
            } else {
                Toast.makeText(this@RegistrationActivity,"Please Fill All Field",Toast.LENGTH_SHORT).show()
            }
        }

        binding.loginHere.setOnClickListener {
            var intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        binding.radiogroup.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->

            val radio: RadioButton = group.findViewById(checkedId)

            gender = radio.text.toString()


        })

        if (!checkPermissions()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions()
            }
        } else {
            getLastLocation()
        }

    }
    fun validation(): Boolean {
        if (binding.name.text.toString().trim().isEmpty()) {
            binding.name.error = "Enter Your Name"
            binding.name.requestFocus()
        } else if (binding.email.text.toString().trim().isEmpty()) {
            binding.email.error = "Enter Your Email"
            binding.email.requestFocus()
        } else if (binding.mobile.text.toString().trim().isEmpty()) {
            binding.mobile.error = "Enter Your Mobile"
            binding.mobile.requestFocus()
        } else if (binding.address.text.toString().trim().isEmpty()) {
            binding.address.error = "Enter Your Address"
            binding.address.requestFocus()
        } else if (binding.pincode.text.toString().trim().isEmpty()) {
            binding.pincode.error = "Enter Your Pincode"
            binding.pincode.requestFocus()
        } else if (binding.pincode.text.toString().trim().length < 6) {
            binding.pincode.error = "Enter the 6 digit"
            binding.pincode.requestFocus()
        } else if (binding.city.text.toString().trim().isEmpty()) {
            binding.city.error = "Enter Your City"
            binding.city.requestFocus()
        } else if (binding.state.text.toString().trim().isEmpty()) {
            binding.state.error = "Enter Your State"
            binding.state.requestFocus()
        } else {
            return true
        }
        return false
    }

    private fun user_upload() {
        val progress = ProgressDialog(this)
        progress.setMessage("Loading...")
        progress.setCancelable(false)
        progress.show()
        Log.e("iddd",prefrenceManager?.getUserid(applicationContext).toString())
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.user_update(
                prefrenceManager?.getUserid(applicationContext).toString(),
                binding.name.text.toString(),
                binding.mobile.text.toString(),
                gender,
                "Work",
                binding.pincode.text.toString(),
                "India",
                binding.state.text.toString(),
                binding.city.text.toString(),
                binding.address.text.toString(),
                binding.email.text.toString(),
                binding.email.text.toString(),
                latitude,
                longitude
            )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e("upload1_res", response.body().toString())
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e("upload1_response", jsonArray.toString())
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {

                        var intent = Intent(this@RegistrationActivity, DashbordActivity::class.java)
                        intent.putExtra("RegistrationLayout", "members")
                        startActivity(intent)
                        finishAffinity()
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                        progress.dismiss()

                    } else {
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                        progress.dismiss()

                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("upload1_error", e.toString())
                    progress.dismiss()
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("upload1_eror", t.toString())
                progress.dismiss()
            }

        })

    }

    private fun getLastLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        mFusedLocationClient.lastLocation.addOnCompleteListener(this) { task ->
            if (task.isSuccessful && task.result != null) {
                lastLocation = task.result
                Log.e("fdkj", (lastLocation)!!.latitude.toString())
                Log.e("fdkj", (lastLocation)!!.longitude.toString())

                latitude = (lastLocation)!!.latitude.toString()
                longitude = (lastLocation)!!.longitude.toString()

//                preferencesManegar?.setlatitude((lastLocation)!!.latitude.toString(), applicationContext)
//                preferencesManegar?.setlongitude((lastLocation)!!.longitude.toString(), applicationContext)

                val geocoder = Geocoder(this, Locale.getDefault())
                val list: List<Address> =
                    geocoder.getFromLocation(
                        (lastLocation)!!.latitude,
                        (lastLocation)!!.longitude,
                        1
                    )!!
                binding.apply {
                    Log.e("jfks", list[0].getAddressLine(0))

                    localaddress = address.setText(list[0].getAddressLine(0)).toString()
//                    binding.userAddress.setText(list[0].getAddressLine(0))
                    binding.pincode.setText(list[0].postalCode)
                    binding.state.setText(list[0].adminArea)
                    binding.city.setText(list[0].locality)
//                    binding.userLandmark.setText(list[0].featureName)
                }
            } else {
                Log.w(TAG, "getLastLocation:exception", task.exception)
                //showMessage("No location detected. Make sure location is enabled on the device.")
            }
        }
    }

    private fun showSnackbar(
        mainTextStringId: String, actionStringId: String,
        listener: View.OnClickListener
    ) {
        Toast.makeText(this, mainTextStringId, Toast.LENGTH_LONG).show()
    }

    private fun checkPermissions(): Boolean {
        val permissionState = ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        return permissionState == PackageManager.PERMISSION_GRANTED
    }

    private fun startLocationPermissionRequest() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION),
            REQUEST_PERMISSIONS_REQUEST_CODE
        )
    }

    private fun requestPermissions() {
        val shouldProvideRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (shouldProvideRationale) {
            Log.i(TAG, "Displaying permission rationale to provide additional context.")
            showSnackbar("Location permission is needed for core functionality", "Okay",
                View.OnClickListener {
                    startLocationPermissionRequest()
                })
        } else {
            Log.i(TAG, "Requesting permission")
            startLocationPermissionRequest()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Log.i(TAG, "onRequestPermissionResult")
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            when {
                grantResults.isEmpty() -> {
                    // If user interaction was interrupted, the permission request is cancelled and you
                    // receive empty arrays.
                    Log.i(TAG, "User interaction was cancelled.")
                }
                grantResults[0] == PackageManager.PERMISSION_GRANTED -> {
                    // Permission granted.
                    getLastLocation()
                }
                else -> {
                    showSnackbar("Permission was denied", "Settings",
                        View.OnClickListener {
                            // Build intent that displays the App settings screen.
                            val intent = Intent()
                            intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                            val uri = Uri.fromParts(
                                "package",
                                Build.DISPLAY, null
                            )
                            intent.data = uri
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                        }
                    )
                }
            }
        }
    }
}