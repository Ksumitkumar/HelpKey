package br.com.helpdev.sms.helper

import android.content.Context
import android.content.SharedPreferences

class PrefrenceManger1(applicationContext: Context) {

    private val preference_Name = "zxcvbnm"
    val sharedPreferences: SharedPreferences =
        applicationContext.getSharedPreferences(preference_Name, Context.MODE_PRIVATE)


    fun setMobileno(mobile: String?, context: Context) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("mobile", mobile)
        editor.apply()
    }

    fun getmobilno(context: Context): String? {
        return sharedPreferences.getString("mobile", "")
    }

    fun settype(type: String?, context: Context) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("type", type)
        editor.apply()
    }

    fun gettype(context: Context): String? {
        return sharedPreferences.getString("type", "")
    }

    fun setToken(token: String?, context: Context) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("token", token)
        editor.apply()
    }

    fun getToken(context: Context): String? {
        return sharedPreferences.getString("token", "")
    }


    fun setUserId(userid: String?, context: Context) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("userid", userid)
        editor.apply()
    }

    fun getUserid(context: Context): String? {
        return sharedPreferences.getString("userid", "")
    }

    fun getName(context: Context): String? {
        return sharedPreferences.getString("name", "")
    }

    fun setName(name: String?, context: Context) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("name", name)
        editor.apply()
    }

    fun getemail(context: Context): String? {
        return sharedPreferences.getString("email", "")
    }

    fun setemail(email: String?, context: Context) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("email", email)
        editor.apply()
    }

    fun setDob(dob: String?, context: Context) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("dob", dob)
        editor.apply()
    }

    fun getDob(context: Context): String? {
        return sharedPreferences.getString("dob", "")
    }

    fun setaddressid(addressid: String?, context: Context) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("addressid", addressid)
        editor.apply()
    }

    fun getaddressid(context: Context): String? {
        return sharedPreferences.getString("addressid", "")
    }

    fun getlatitude(context: Context): String? {
        return sharedPreferences.getString("latitude", "")
    }

    fun setlatitude(latitude: String?, context: Context) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("latitude", latitude)
        editor.apply()
    }

    fun getlongitude(context: Context): String? {
        return sharedPreferences.getString("longitude", "")
    }

    fun setlongitude(longitude: String?, context: Context) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("longitude", longitude)
        editor.apply()
    }

    fun clearSharedPreference() {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.clear()
        editor.commit()
    }
}