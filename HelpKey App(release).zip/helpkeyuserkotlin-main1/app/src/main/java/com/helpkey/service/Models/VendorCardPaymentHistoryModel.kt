package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class VendorCardPaymentHistoryModel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("vendor_service_id")
    @Expose
    var vendorServiceId: String? = null

    @SerializedName("user_id")
    @Expose
    var userId: String? = null

    @SerializedName("card_no")
    @Expose
    var cardNo: String? = null

    @SerializedName("total_amount")
    @Expose
    var totalAmount: String? = null

    @SerializedName("discount")
    @Expose
    var discount: String? = null

    @SerializedName("discounted_amount")
    @Expose
    var discountedAmount: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null

    @SerializedName("username")
    @Expose
    var username: String? = null

    @SerializedName("address")
    @Expose
    var address: String? = null

    @SerializedName("servicename")
    @Expose
    var servicename: String? = null
}