package com.helpkey.service.Adapter

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.helpkey.service.Models.WithdrawalHistoryModel
import com.helpkey.service.databinding.WithdrawalHistoryLayoutBinding

class WithdrawalHistoryAdapter(var list: ArrayList<WithdrawalHistoryModel>, var context: Context): RecyclerView.Adapter<WithdrawalHistoryAdapter.ViewHolder>() {

    var amount = ""

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WithdrawalHistoryAdapter.ViewHolder {
        val binding = WithdrawalHistoryLayoutBinding.inflate(LayoutInflater.from(context),parent,false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: WithdrawalHistoryAdapter.ViewHolder, position: Int) {

        if(list[position].status.equals("Accepted")) {
            holder.binding.status.setTextColor(Color.parseColor("#008640"))

        } else {
            holder.binding.status.setTextColor(Color.RED)
        }
        if (list[position].accountHolderName.equals(null)) {
            holder.binding.name.text = "-"
        } else {
            holder.binding.name.text = list[position].accountHolderName.toString()
        }
        if (list[position].branchName.equals(null)) {
            holder.binding.branchName.text = "-"
        } else {
            holder.binding.branchName.text = list[position].branchName.toString()
        }
        if (list[position].ifscCode.equals(null)) {
            holder.binding.ifscCode.text = "-"
        } else {
            holder.binding.ifscCode.text = list[position].ifscCode.toString()
        }
        if (list[position].accountNo.equals(null)) {
            holder.binding.accountNumber.text = "-"
        } else {
            holder.binding.accountNumber.text = list[position].accountNo.toString()
        }
        if (list[position].upiAddress.equals(null)) {
            holder.binding.upiId.text = "-"
        } else {
            holder.binding.upiId.text = list[position].upiAddress.toString()
        }
        if (list[position].bankName.equals(null)) {
            holder.binding.bankName.text = "-"
        } else {
            holder.binding.bankName.text = list[position].bankName.toString()
        }
        holder.binding.status.text = list[position].status.toString()
        holder.binding.amount.text = list[position].amount.toString()
        holder.binding.time.text = "Time :"+list[position].createdAt

    }

    override fun getItemCount(): Int {
     return list.size
    }

    inner class ViewHolder(var binding: WithdrawalHistoryLayoutBinding): RecyclerView.ViewHolder(binding.root)
}