package com.helpkey.service.UserActivity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.razorpay.Checkout
import com.razorpay.PaymentData

import com.razorpay.PaymentResultWithDataListener
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.R
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class VerchualcardPaymentActivity : AppCompatActivity(), PaymentResultWithDataListener {
    var prefrenceManager: PrefrenceManger1? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)
        prefrenceManager = PrefrenceManger1(applicationContext)


        startPayment()

        Log.e("orderid", MyvirtualcardActivity.list.toString())
    }


    private fun startPayment() {

        val co = Checkout()

        try {
            val options = JSONObject()
            options.put("name", "HelpKey App")
            options.put("description", prefrenceManager?.getName(applicationContext).toString())
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png")
            options.put("theme.color", "#3399cc");
            options.put("currency", "INR");
            options.put("amount", "100" + "00")
            val prefill = JSONObject()
            prefill.put("email", prefrenceManager?.getemail(applicationContext).toString())
            prefill.put("contact", prefrenceManager?.getmobilno(applicationContext).toString())
            options.put("prefill", prefill)
            co.open(this@VerchualcardPaymentActivity, options)
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("exception_err", e.toString())
        }
    }




    override fun onPaymentSuccess(razorpayPaymentID: String?, paymentData: PaymentData?) {

        if (paymentData != null) {
            Log.e("dkf", paymentData.signature + " " + paymentData.orderId + " " + paymentData.data)
            try {
                paymentSuccess(razorpayPaymentID.toString())

            } catch (e: Exception) {
                Log.e("fd", e.toString())

            }
        }
    }

    override fun onPaymentError(p0: Int, p1: String?, p2: PaymentData?) {
//        val intent =
//            Intent(this@VerchualcardPaymentActivity, ThankyouActivity::class.java)
//        intent.putExtra("order_id", intent.getStringExtra("hello"))
//        startActivity(intent)
        finish()
    }


    fun paymentSuccess(tx_id: String) {
        //  binding.progress.visibility = View.VISIBLE

        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.cardpaymentsuccess(
                prefrenceManager?.getUserid(applicationContext).toString(),
                intent.getStringExtra("orderid").toString(),
                "100.00",
                tx_id,
                "success"
            )
        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                //  binding.progress.visibility = View.GONE
                try {
                    Log.e("payemtn_res", response.body().toString())
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {

                        uploadDocument()

                    } else {
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: Exception) {

                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("payemnt_error", t.toString())

            }
        })
    }

    fun uploadDocument() {

        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.uplode_document(
                MyvirtualcardActivity.list,
                intent.getStringExtra("orderid").toString(),

                )
        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                //  binding.progress.visibility = View.GONE
                try {
                    Log.e("upload_res", response.body().toString())
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {

                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                        val intent =
                            Intent(this@VerchualcardPaymentActivity, ThankyouActivity::class.java)
                        intent.putExtra("order_id", intent.getStringExtra("orderid"))
                        startActivity(intent)
                        finish()

                    } else {
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()

                    }


                } catch (e: Exception) {
                    Log.e("upload_ex", e.toString())

                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("upload_error", t.toString())

            }
        })
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }


}