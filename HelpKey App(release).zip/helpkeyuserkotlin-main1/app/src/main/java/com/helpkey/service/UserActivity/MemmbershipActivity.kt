package com.helpkey.service.UserActivity

import android.app.Activity
import android.content.Intent
import android.content.RestrictionEntry
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.github.dhaval2404.imagepicker.ImagePicker
import com.helpkey.service.databinding.ActivityMemmbershipBinding

class MemmbershipActivity : AppCompatActivity() {
    lateinit var binding: ActivityMemmbershipBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMemmbershipBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.amount.isFocusable = true
        binding.amount.isFocusableInTouchMode = true
        binding.amount.inputType = RestrictionEntry.TYPE_NULL

        binding.uplaodImg.setOnClickListener {
            ImagePicker.with(this)
                .crop()                    //Crop image(Optional), Check Customization for more option
                .compress(1024)            //Final image size will be less than 1 MB(Optional)
                .maxResultSize(
                    1080,
                    1080
                )
                //Final image resolution will be less than 1080 x 1080(Optional)
                .start()
        }


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data!!
            binding.image.setImageURI(uri)
        } else if (resultCode == ImagePicker.RESULT_ERROR) {
            Toast.makeText(this, ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Task Cancelled", Toast.LENGTH_SHORT).show()
        }
    }

}