package com.helpkey.service.UserActivity

import Categorymodel
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import com.app.titoserviceapp.Adapter.AllCategoryAdapter
import com.app.titoserviceapp.Adapter.MostPoupularAdapter
import com.app.titoserviceapp.Adapter.NearbyvendorAdapter
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.helpkey.service.Adapter.TopVendorAdapter
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.MostPopularVendorsModel
import com.helpkey.service.Models.NearVendorsModel
import com.helpkey.service.Models.ToppointModel
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityCategoryviewallBinding
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class CategoryviewallActivity : AppCompatActivity() {


    var categorymodels: ArrayList<Categorymodel> = ArrayList()
    var topVendorsModel: ArrayList<ToppointModel> = ArrayList()
    var popularVendorsModel: ArrayList<MostPopularVendorsModel> = ArrayList()
    var nearVendorsModel: ArrayList<NearVendorsModel> = ArrayList()

    lateinit var binding: ActivityCategoryviewallBinding
    var address = ""
    var cat_id = ""

    companion object {
        lateinit var activity: CategoryviewallActivity
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCategoryviewallBinding.inflate(layoutInflater)
        setContentView(binding.root)
        activity = this
        address = intent.getStringExtra("address").toString()
        Constracter.addressl = "topvendor"
        cat_id = intent.getStringExtra("cat_id").toString()
        binding.mtoolbar.setNavigationOnClickListener(View.OnClickListener {
            Constracter.point = "0"
            finish()
        })
        when (address) {
            "category" -> {
                binding.mtoolbar.title = "Category's"
                binding.l1.visibility = View.GONE
                Category_user()
            }
            "nearvendor" -> {
                binding.mtoolbar.title = "Near By Point's"
                binding.l1.visibility = View.GONE
                nearvendor( Constracter.latitude, Constracter.longitude)
            }
            "popularvendor" -> {
                binding.mtoolbar.title = "Most Popular Services"
                binding.l1.visibility = View.GONE
                popularVendor()
            }
            "topvendor" -> {
                binding.mtoolbar.title = "Top Vendors"
                binding.l1.visibility = View.GONE
                TopVendors()
            }
            "recently" -> {
                binding.mtoolbar.title = "Recently View"
                binding.l1.visibility = View.GONE
            }
            "help" -> {
                binding.mtoolbar.title = "Help & Support"
                binding.l1.visibility = View.VISIBLE
                binding.l2.visibility = View.GONE
                binding.mainLayout.setBackgroundResource(R.drawable.login_background)
//                binding.txt1.paintFlags = binding.txt1.paintFlags or Paint.UNDERLINE_TEXT_FLAG
//                binding.txt2.paintFlags = binding.txt2.paintFlags or Paint.UNDERLINE_TEXT_FLAG
//                binding.txt3.paintFlags = binding.txt3.paintFlags or Paint.UNDERLINE_TEXT_FLAG
            }
            "point" -> {
                binding.mtoolbar.title = "Helpkey Points"
                binding.l1.visibility = View.GONE
                Category_user()
            }
            "service" -> {
                binding.mtoolbar.title = "Helpkey Services"
                binding.l1.visibility = View.GONE
                Category_user()
            }
        }

        binding.callHelp.setOnClickListener {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CALL_PHONE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CALL_PHONE),
                    100
                )
            } else {
                val intent = Intent(
                    Intent.ACTION_DIAL,
                    Uri.fromParts("tel", binding.call.text.toString(), null)
                )
                startActivity(intent)
            }
        }

        binding.whatsappHelp.setOnClickListener {
            val Callnumber = "7269040412"
            val phoneNumberWithCountryCode = "+91$Callnumber"
            val message = "Hello"
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse(
                        String.format(
                            "https://api.whatsapp.com/send?phone=%s&text=%s",
                            phoneNumberWithCountryCode,
                            message
                        )
                    )
                )
            )
        }

        binding.telegramHelp.setOnClickListener {
            try {
                val telegram =
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Helpkeyindia"))
                telegram.setPackage("org.telegram.messenger")
                startActivity(telegram)
            } catch (e: Exception) {
                Toast.makeText(this, "Telegram app is not installed", Toast.LENGTH_LONG).show()
            }
        }

        binding.mailHelp.setOnClickListener {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("mailto:" + "info@helpkey.in"))
                intent.putExtra(Intent.EXTRA_SUBJECT, "Complain")
                intent.putExtra(Intent.EXTRA_TEXT, "text")
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(
                    this@CategoryviewallActivity,
                    "Sorry...You don't have any mail app",
                    Toast.LENGTH_SHORT
                )
                    .show()
                e.printStackTrace()
            }
        }

        binding.call.setOnClickListener {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CALL_PHONE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CALL_PHONE),
                    100
                )
            } else {
                val intent = Intent(
                    Intent.ACTION_DIAL,
                    Uri.fromParts("tel", binding.call.text.toString(), null)
                )
                startActivity(intent)
            }
        }
    }

    fun Category_user() {
        binding.progress.visibility = View.VISIBLE
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonArray> = getDataService.catgeroy(cat_id)
        call.enqueue(object : Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        Log.e("category", response.body().toString())
                        binding.progress.visibility = View.GONE
                        val jsonObject2 = jsonObject.getJSONArray("data")
                        if (jsonObject2.length() > 0) {
                            for (i in 0 until jsonObject2.length()) {
                                val categorymodel: Categorymodel = Gson().fromJson(
                                    jsonObject2.getString(i).toString(),
                                    Categorymodel::class.java)
                                categorymodels.add(categorymodel)
                            }

                        } else {
                            binding.empaty.visibility = View.VISIBLE
                        }

                    } else {
                        binding.progress.visibility = View.GONE
                        binding.empaty.visibility = View.VISIBLE
                    }

                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("allcategory", e.toString())
                    binding.empaty.visibility = View.VISIBLE
                }


                val adpter1 = AllCategoryAdapter(categorymodels, applicationContext)
                val gridLayoutManager = GridLayoutManager(applicationContext, 3)
                binding.recylviewCategory.layoutManager = gridLayoutManager
                binding.recylviewCategory.setHasFixedSize(true)
                binding.recylviewCategory.itemAnimator = DefaultItemAnimator()
                binding.recylviewCategory.adapter = adpter1
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("allcategory_err", t.toString())
                binding.progress.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE

            }

        })

    }

    fun TopVendors() {
        binding.progress.visibility = View.VISIBLE
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.topvendor()

        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e("top_response", response.body().toString())
                    val jsonObject1 = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject1.getString("status")
                    if (res.equals("success")) {
                        binding.progress.visibility = View.GONE
                        val jsonObject2 = jsonObject1.getJSONArray("data")
                        Log.e("fd", jsonObject2.toString())
                        if (jsonObject2.length() > 0) {
                            for (i in 0 until jsonObject2.length()) {
                                val topvender: ToppointModel = Gson().fromJson(
                                    jsonObject2.getString(i).toString(),
                                    ToppointModel::class.java
                                )
                                topVendorsModel.add(topvender)
                            }

                        } else {
                            binding.progress.visibility = View.GONE
                            binding.empaty.visibility = View.VISIBLE
                        }

                    } else {

                        binding.empaty.visibility = View.VISIBLE
                    }
                    var topadapter = TopVendorAdapter(topVendorsModel, applicationContext)
                    val linearLayoutManager = GridLayoutManager(applicationContext, 3)
                    binding.recylviewCategory.layoutManager = linearLayoutManager
                    binding.recylviewCategory.setHasFixedSize(true)
                    binding.recylviewCategory.itemAnimator = DefaultItemAnimator()
                    binding.recylviewCategory.adapter = topadapter


                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("top_ex", e.toString())
                    binding.progress.visibility = View.GONE
                    binding.empaty.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("top_error", t.toString())
                binding.progress.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE
            }
        })
    }

    fun popularVendor() {
        binding.progress.visibility = View.VISIBLE
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.mostpopular()

        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e("popularVendor_response", response.body().toString())
                    val jsonObject1 = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject1.getString("status")
                    if (res.equals("success")) {
                        binding.progress.visibility = View.GONE
                        val jsonObject2 = jsonObject1.getJSONArray("data")
                        Log.e("fd", jsonObject2.toString())
                        if (jsonObject2.length() > 0) {
                            for (i in 0 until jsonObject2.length()) {
                                val popularvender: MostPopularVendorsModel = Gson().fromJson(
                                    jsonObject2.getString(i).toString(),
                                    MostPopularVendorsModel::class.java
                                )
                                popularVendorsModel.add(popularvender)
                            }

                        } else {
                            binding.empaty.visibility = View.VISIBLE
                            binding.progress.visibility = View.GONE
                        }

                    } else {
                    }
                    var adpter2 = MostPoupularAdapter(popularVendorsModel, applicationContext)
                    val linearLayoutManager = GridLayoutManager(applicationContext, 3)
                    binding.recylviewCategory.layoutManager = linearLayoutManager
                    binding.recylviewCategory.setHasFixedSize(true)
                    binding.recylviewCategory.itemAnimator = DefaultItemAnimator()
                    binding.recylviewCategory.adapter = adpter2


                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("popularVendor_ex", e.toString())
                    binding.progress.visibility = View.GONE
                    binding.empaty.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("popularVendor_error", t.toString())
                binding.progress.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE
            }
        })
    }

    fun nearvendor(latitude: String, longitude: String) {
        binding.progress.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.nearbyvendor(
                latitude, longitude
            )

        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e(
                        "nearvendor_response",
                        response.body().toString() + " " + call.request().url().toString()
                    )
                    val jsonObject1 = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject1.getString("status")
                    if (res.equals("success")) {
                        binding.progress.visibility = View.GONE
                        val jsonObject2 = jsonObject1.getJSONArray("data")
                        Log.e("fd", jsonObject2.toString())
                        if (jsonObject2.length() > 0) {
                            for (i in 0 until jsonObject2.length()) {
                                val nearvendor: NearVendorsModel = Gson().fromJson(
                                    jsonObject2.getString(i).toString(),
                                    NearVendorsModel::class.java
                                )
                                if (50 > nearvendor.id!!.toInt()) {
                                    Log.e("nearID", nearvendor.id.toString())
                                    nearVendorsModel.add(nearvendor)
                                }
                            }

                        } else {

                            binding.empaty.visibility = View.VISIBLE
                            binding.progress.visibility = View.GONE

                        }

                    } else {

                    }

                    var adpter3 = NearbyvendorAdapter(nearVendorsModel, applicationContext)
                    val layoutManager = GridLayoutManager(applicationContext, 3)
                    binding.recylviewCategory.layoutManager = layoutManager
                    binding.recylviewCategory.setHasFixedSize(true)
                    binding.recylviewCategory.adapter = adpter3

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("nearvendor_ex", e.toString())
                    binding.progress.visibility = View.GONE
                    binding.empaty.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("nearvendor_error", t.toString())
                binding.progress.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE
            }
        })
    }

    fun call() {
        if (ContextCompat.checkSelfPermission(
                this@CategoryviewallActivity,
                Manifest.permission.CALL_PHONE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this@CategoryviewallActivity,
                arrayOf(Manifest.permission.CALL_PHONE),
                100
            )
        } else {
            val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", Constracter.mobile, null))
            startActivity(intent)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        Constracter.point = "0"
    }
}