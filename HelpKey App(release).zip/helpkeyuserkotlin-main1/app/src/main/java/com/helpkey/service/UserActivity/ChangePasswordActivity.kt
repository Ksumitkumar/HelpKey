package com.helpkey.service.UserActivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.databinding.ActivityChangePasswordBinding
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response

class ChangePasswordActivity : AppCompatActivity() {
    lateinit var binding: ActivityChangePasswordBinding
    var prefrenceManager: PrefrenceManger1? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChangePasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefrenceManager = PrefrenceManger1(applicationContext)

        binding.change.setOnClickListener {
            if (binding.password.text.toString() == binding.confirmPassword.text.toString()){
                forgetPassword()
            } else {
                Toast.makeText(this@ChangePasswordActivity,"Please Enter Confirm Password",Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun forgetPassword() {
        binding.progress.visibility = View.VISIBLE
        val change: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> = change.chandepassword(prefrenceManager?.getmobilno(applicationContext).toString(),
            intent.getStringExtra("change").toString(),
            binding.confirmPassword.text.toString()
        )
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                try {
                    Log.e("change_res",response.body().toString())
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progress.visibility = View.GONE
                        startActivity(Intent(this@ChangePasswordActivity,SelectuserTypeActivity::class.java))
                        finishAffinity()
                    } else {
                        binding.progress.visibility = View.GONE
                        Toast.makeText(this@ChangePasswordActivity, "Password Not Change", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: JSONException) {
                    binding.progress.visibility = View.GONE
                    e.printStackTrace()
                    Log.e("change_exe",e.toString())
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                binding.progress.visibility = View.GONE
                Log.e("change_err",t.toString())
            }
        })
    }
}