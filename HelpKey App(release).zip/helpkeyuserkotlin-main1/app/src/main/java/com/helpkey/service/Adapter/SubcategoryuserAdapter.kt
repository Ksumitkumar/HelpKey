package com.helpkey.service.Adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Models.SubcategoryModel
import com.helpkey.service.UserActivity.SubcategoryuserActivity
import com.helpkey.service.UserActivity.VendorAcitivityUser
import com.helpkey.service.databinding.SubcategoryRecyivewBinding

class SubcategoryuserAdapter(val list:ArrayList<SubcategoryModel>,var context: Context) :
    RecyclerView.Adapter<SubcategoryuserAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var binding =
            SubcategoryRecyivewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)

    }

    override fun onBindViewHolder(holder: SubcategoryuserAdapter.ViewHolder, position: Int) {

        holder.binding.title.text = list[position].sub_category
        Picasso.get().load("https://panels.helpkey.in/images/subcategory/"+ list[position].image).into(holder.binding.imge)

        holder.binding.card.setOnClickListener {
            Constracter.subcategory_id = list[position].id.toString()
            val intent = Intent(context, VendorAcitivityUser::class.java)
            intent.putExtra("subcat_id", list[position].id.toString())
            intent.putExtra("cat_id",SubcategoryuserActivity.id)
            intent.putExtra("name",list[position].sub_category.toString())
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)

//            val intent = Intent(context, ProductActivity::class.java)
//            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class ViewHolder(var binding: SubcategoryRecyivewBinding) :
        RecyclerView.ViewHolder(binding.root)

}