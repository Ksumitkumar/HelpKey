package com.helpkey.service.Models

import com.google.gson.annotations.SerializedName
import com.google.gson.annotations.Expose

class WithdrawalHistoryModel {
    @SerializedName("id")
    @Expose
    var id: String? = null

    @SerializedName("user_id")
    @Expose
    var userId: String? = null

    @SerializedName("amount")
    @Expose
    var amount: String? = null

    @SerializedName("bank_name")
    @Expose
    var bankName: String? = null

    @SerializedName("branch_name")
    @Expose
    var branchName: String? = null

    @SerializedName("account_no")
    @Expose
    var accountNo: String? = null

    @SerializedName("account_holder_name")
    @Expose
    var accountHolderName: String? = null

    @SerializedName("ifsc_code")
    @Expose
    var ifscCode: String? = null

    @SerializedName("upi_address")
    @Expose
    var upiAddress: String? = null

    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null

    /**
     * No args constructor for use in serialization
     *
     */
    constructor() {}

    /**
     *
     * @param createdAt
     * @param amount
     * @param accountNo
     * @param branchName
     * @param bankName
     * @param upiAddress
     * @param id
     * @param userId
     * @param accountHolderName
     * @param ifscCode
     * @param status
     * @param updatedAt
     */
    constructor(
        id: String?,
        userId: String?,
        amount: String?,
        bankName: String?,
        branchName: String?,
        accountNo: String?,
        accountHolderName: String?,
        ifscCode: String?,
        upiAddress: String?,
        status: String?,
        createdAt: String?,
        updatedAt: String?
    ) : super() {
        this.id = id
        this.userId = userId
        this.amount = amount
        this.bankName = bankName
        this.branchName = branchName
        this.accountNo = accountNo
        this.accountHolderName = accountHolderName
        this.ifscCode = ifscCode
        this.upiAddress = upiAddress
        this.status = status
        this.createdAt = createdAt
        this.updatedAt = updatedAt
    }
}