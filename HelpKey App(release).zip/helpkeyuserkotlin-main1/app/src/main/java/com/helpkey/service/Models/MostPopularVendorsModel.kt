package com.helpkey.service.Models

import com.google.gson.annotations.SerializedName
import com.google.gson.annotations.Expose

class MostPopularVendorsModel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("vendorId")
    @Expose
    var vendorId: String? = null

    @SerializedName("servicename")
    @Expose
    var servicename: String? = null

    @SerializedName("vendor_name")
    @Expose
    var vendorName: String? = null

    @SerializedName("price")
    @Expose
    var price: String? = null

    @SerializedName("address")
    @Expose
    var address: String? = null

    @SerializedName("category")
    @Expose
    var category: String? = null

    @SerializedName("subcategory")
    @Expose
    var subcategory: String? = null

    @SerializedName("coverimage")
    @Expose
    var coverimage: String? = null

    @SerializedName("serviceimage")
    @Expose
    var serviceimage: String? = null

    @SerializedName("description")
    @Expose
    var description: Any? = null

    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("popular")
    @Expose
    var popular: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null

    @SerializedName("username")
    @Expose
    var username: String? = null

    @SerializedName("email")
    @Expose
    var email: String? = null

    @SerializedName("password")
    @Expose
    var password: Any? = null

    @SerializedName("mobile")
    @Expose
    var mobile: String? = null

    @SerializedName("gender")
    @Expose
    var gender: String? = null

    @SerializedName("pin_code")
    @Expose
    var pinCode: String? = null

    @SerializedName("country")
    @Expose
    var country: String? = null

    @SerializedName("state")
    @Expose
    var state: String? = null

    @SerializedName("city")
    @Expose
    var city: String? = null

    @SerializedName("image")
    @Expose
    var image: String? = null

    @SerializedName("type")
    @Expose
    var type: String? = null

    @SerializedName("otp")
    @Expose
    var otp: String? = null

    @SerializedName("otp_status")
    @Expose
    var otpStatus: String? = null

    @SerializedName("istop")
    @Expose
    var istop: String? = null

    @SerializedName("percentage")
    @Expose
    var discount: String? = null

    /**
     * No args constructor for use in serialization
     *
     */
    constructor() {}

    /**
     *
     * @param country
     * @param gender
     * @param city
     * @param vendorId
     * @param description
     * @param type
     * @param createdAt
     * @param password
     * @param price
     * @param istop
     * @param servicename
     * @param id
     * @param state
     * @param otpStatus
     * @param popular
     * @param email
     * @param updatedAt
     * @param image
     * @param address
     * @param mobile
     * @param otp
     * @param vendorName
     * @param coverimage
     * @param pinCode
     * @param serviceimage
     * @param category
     * @param subcategory
     * @param status
     * @param username
     * @param discount
     */
    constructor(
        id: Int?,
        vendorId: String?,
        servicename: String?,
        vendorName: String?,
        price: String?,
        address: String?,
        category: String?,
        subcategory: String?,
        coverimage: String?,
        serviceimage: String?,
        description: Any?,
        status: String?,
        popular: String?,
        createdAt: String?,
        updatedAt: String?,
        username: String?,
        email: String?,
        password: Any?,
        mobile: String?,
        gender: String?,
        pinCode: String?,
        country: String?,
        state: String?,
        city: String?,
        image: String?,
        type: String?,
        otp: String?,
        otpStatus: String?,
        discount: String?,
        istop: String?
    ) : super() {
        this.id = id
        this.vendorId = vendorId
        this.servicename = servicename
        this.vendorName = vendorName
        this.price = price
        this.address = address
        this.category = category
        this.subcategory = subcategory
        this.coverimage = coverimage
        this.serviceimage = serviceimage
        this.description = description
        this.status = status
        this.popular = popular
        this.createdAt = createdAt
        this.updatedAt = updatedAt
        this.username = username
        this.email = email
        this.password = password
        this.mobile = mobile
        this.gender = gender
        this.pinCode = pinCode
        this.country = country
        this.state = state
        this.city = city
        this.image = image
        this.type = type
        this.otp = otp
        this.otpStatus = otpStatus
        this.istop = istop
        this.discount = discount
    }
}