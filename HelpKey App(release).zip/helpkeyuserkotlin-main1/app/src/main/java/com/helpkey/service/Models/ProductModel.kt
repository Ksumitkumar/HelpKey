package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ProductModel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("vendorId")
    @Expose
    var vendorId: String? = null

    @SerializedName("servicename")
    @Expose
    var servicename: String? = null

    @SerializedName("vendor_name")
    @Expose
    var vendor_name: String? = null

    @SerializedName("price")
    @Expose
    var price: String? = null

    @SerializedName("address")
    @Expose
    var address: String? = null

    @SerializedName("category")
    @Expose
    var category: String? = null

    @SerializedName("subcategory")
    @Expose
    var subcategory: String? = null


    @SerializedName("coverimage")
    @Expose
    var coverimage: String? = null

    @SerializedName("serviceimage")
    @Expose
    var serviceimage: String? = null

    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("mobile")
    @Expose
    var mobile: String? = null

    @SerializedName("percentage")
    @Expose
    var percentage: String? = null

    constructor(
        id: Int?,
        vendorId: String?,
        servicename: String?,
        vendor_name: String?,
        price: String?,
        address: String?,
        category: String?,
        subcategory: String?,
        coverimage: String?,
        serviceimage: String?,
        description: String?,
        mobile: String?,
        percentage: String?
    ) {
        this.id = id
        this.vendorId = vendorId
        this.servicename = servicename
        this.vendor_name = vendor_name
        this.price = price
        this.address = address
        this.category = category
        this.subcategory = subcategory
        this.coverimage = coverimage
        this.serviceimage = serviceimage
        this.description = description
        this.mobile = mobile
        this.percentage = percentage
    }
}