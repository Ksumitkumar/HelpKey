
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Categorymodel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("cateName")
    @Expose
    var cateName: String? = null

    @SerializedName("image")
    @Expose
    var image: String? = null




    constructor(
        id: Int?,
        cateName: String?,
        image: String?,

    ) : super() {
        this.id = id
        this.cateName = cateName

        this.image = image
    }


}