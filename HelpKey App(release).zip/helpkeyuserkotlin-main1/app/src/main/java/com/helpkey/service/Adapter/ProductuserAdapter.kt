package com.helpkey.service.Adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.squareup.picasso.Picasso
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.ProductModel
import com.helpkey.service.R
import com.helpkey.service.UserActivity.CartActivity
import com.helpkey.service.UserActivity.ProductActivity
import com.helpkey.service.UserActivity.ProductFulldetailsActivity
import com.helpkey.service.databinding.ProductRecylviewBinding
import org.json.JSONArray
import retrofit2.Call
import retrofit2.Response

class ProductuserAdapter(var list: ArrayList<ProductModel>, var context: Context) :
    RecyclerView.Adapter<ProductuserAdapter.ViewHolder>() {
    var prefrenceManager: PrefrenceManger1? = null
    var number = ""

    inner class ViewHolder(var binding: ProductRecylviewBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ProductuserAdapter.ViewHolder {
        val binding =
            ProductRecylviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductuserAdapter.ViewHolder, position: Int) {


        number = list[position].price.toString()
        Picasso.get()
            .load("https://panels.helpkey.in/public/images/serviceimage/" + list.get(position).serviceimage)
            .placeholder(R.drawable.service)
            .into(holder.binding.img)
        holder.binding.title.text = list[position].servicename
        holder.binding.price.text = "₹ " + number
        if (number == "null") {
            holder.binding.price.text = "Point"
            holder.binding.addCart.visibility = View.GONE
        } else {
            holder.binding.price.text = "₹ "+number.toString()
        }

        holder.binding.addCart.setOnClickListener {
            add_cart(list[position].id.toString())
        }
        holder.binding.card.setOnClickListener {
            if (list[position].price.toString() == "null") {
                Constracter.point = "1"
                var intent = Intent(context, ProductActivity::class.java)
                Constracter.vendor_id = list[position].vendorId.toString()
                intent.putExtra("vendor_id",list[position].id.toString())
                intent.putExtra("name",list[position].servicename.toString())
                intent.putExtra("description",list[position].description.toString())
                intent.putExtra("mobile",list[position].mobile.toString())
                intent.putExtra("discount",list[position].percentage.toString())
                intent.putExtra("address",list[position].address.toString())
                intent.putExtra("cimg",list[position].coverimage.toString())
                intent.putExtra("simg",list[position].serviceimage.toString())
                intent.putExtra("address","vendorcat")
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
            } else {
                val intent = Intent(context, ProductFulldetailsActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                intent.putExtra("id",list[position].id.toString())
                intent.putExtra("img",list[position].serviceimage)
                intent.putExtra("productname",list[position].servicename)
                intent.putExtra("description",list[position].description)
                intent.putExtra("price",holder.binding.price.text)
                context.startActivity(intent)
            }

        }

    }

    override fun getItemCount(): Int {
        return list.size
    }

    fun add_cart(service_id: String) {
        prefrenceManager = PrefrenceManger1(context)
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonArray> = getDataService.add_to_cart(
            prefrenceManager?.getUserid(context),
            service_id
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e("addcart_res", response.body().toString()+"  "+ prefrenceManager?.getUserid(context))
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        Toast.makeText(
                            context,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()

                        val intent=Intent(context,CartActivity::class.java)
                        intent.flags=Intent.FLAG_ACTIVITY_NEW_TASK
                        context.startActivity(intent)

                    } else {
                        Toast.makeText(
                            context,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: Exception) {
                    Log.e("addcart_error", e.toString())
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("addcart_error", t.toString())
            }

        })

    }
}