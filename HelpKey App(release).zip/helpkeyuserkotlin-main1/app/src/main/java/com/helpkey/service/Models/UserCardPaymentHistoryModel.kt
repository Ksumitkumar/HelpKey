package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class UserCardPaymentHistoryModel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("vendor_service_id")
    @Expose
    var vendorServiceId: String? = null

    @SerializedName("user_id")
    @Expose
    var userId: String? = null

    @SerializedName("card_no")
    @Expose
    var cardNo: String? = null

    @SerializedName("total_amount")
    @Expose
    var totalAmount: String? = null

    @SerializedName("discount")
    @Expose
    var discount: String? = null

    @SerializedName("discounted_amount")
    @Expose
    var discountedAmount: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null

    @SerializedName("servicename")
    @Expose
    var servicename: String? = null

    @SerializedName("address")
    @Expose
    var address: String? = null

    /**
     * No args constructor for use in serialization
     *
     */
    constructor() {}

    /**
     *
     * @param discountedAmount
     * @param totalAmount
     * @param createdAt
     * @param address
     * @param vendorServiceId
     * @param discount
     * @param servicename
     * @param id
     * @param userId
     * @param cardNo
     * @param updatedAt
     */
    constructor(
        id: Int?,
        vendorServiceId: String?,
        userId: String?,
        cardNo: String?,
        totalAmount: String?,
        discount: String?,
        discountedAmount: String?,
        createdAt: String?,
        updatedAt: String?,
        servicename: String?,
        address: String?
    ) : super() {
        this.id = id
        this.vendorServiceId = vendorServiceId
        this.userId = userId
        this.cardNo = cardNo
        this.totalAmount = totalAmount
        this.discount = discount
        this.discountedAmount = discountedAmount
        this.createdAt = createdAt
        this.updatedAt = updatedAt
        this.servicename = servicename
        this.address = address
    }
}