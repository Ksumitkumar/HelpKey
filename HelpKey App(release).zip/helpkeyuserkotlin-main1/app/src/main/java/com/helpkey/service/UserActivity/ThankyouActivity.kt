package com.helpkey.service.UserActivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.helpkey.service.databinding.ActivityThankyouBinding

class ThankyouActivity : AppCompatActivity() {
    lateinit var binding: ActivityThankyouBinding
    var address = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityThankyouBinding.inflate(layoutInflater)
        setContentView(binding.root)

        address = intent.getStringExtra("book").toString()
        binding.odernumber.text = intent.getStringExtra("orderid")

        if (intent.getStringExtra("order_id") == "hello") {
            binding.orderno.visibility = View.GONE
            binding.txtbook.text = "Payment Failed"
        } else {
            when (address) {
                "product" -> {

                }
                "cardbook" -> {
                    binding.orderno.visibility = View.GONE
                    binding.txtbook.text = buildString {
                        append("Thank You\n Your Card Request Send")
                    }
                }
                else -> {
                    binding.orderno.visibility = View.GONE
                    binding.txtbook.text = buildString {
                        append("Thank You\n Your Card Request Send")
                    }
                }
            }
        }

        binding.thankBtn.setOnClickListener {
            val intent = Intent(this@ThankyouActivity, DashbordActivity::class.java)
            startActivity(intent)
            finishAffinity()
        }
    }
}