package com.helpkey.service.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.helpkey.service.Models.DeleteServiceModel
import com.helpkey.service.R
import com.helpkey.service.databinding.DeleteMyservicesLayoutBinding


class VendorMyDeleteServicesAdapter(
    var list: ArrayList<DeleteServiceModel>,
    var context: Context
) :
    RecyclerView.Adapter<VendorMyDeleteServicesAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): VendorMyDeleteServicesAdapter.MyViewHolder {
        val binding = DeleteMyservicesLayoutBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: VendorMyDeleteServicesAdapter.MyViewHolder, position: Int) {

        holder.binding.serviceName.text = "Service name: "+list[position].servicename
        holder.binding.id.text = "ID: HK0" + list[position].vendorserviceId.toString()
        holder.binding.status.text = "Delete Service Status:  " + list[position].status.toString()
        Picasso.get().load("https://panels.helpkey.in/public/images/coverimage/"+list[position].coverimage).placeholder(R.drawable.service).into(holder.binding.img)

    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class MyViewHolder(var binding: DeleteMyservicesLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {

    }

}