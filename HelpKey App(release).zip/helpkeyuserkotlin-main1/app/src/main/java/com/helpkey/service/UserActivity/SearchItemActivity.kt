package com.helpkey.service.UserActivity

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.helpkey.service.Adapter.SearchItemAdapter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.SearchItemModel
import com.helpkey.service.Models.ShowAddressModel
import com.helpkey.service.databinding.ActivitySearchItemBinding
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response

class SearchItemActivity : AppCompatActivity() {
    lateinit var binding: ActivitySearchItemBinding
    val modelList = ArrayList<ShowAddressModel>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchItemBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.back.setNavigationOnClickListener { finish() }
        binding.search.requestFocus()

        val imgr: InputMethodManager =
            this@SearchItemActivity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imgr.showSoftInput(binding.search, 0)

        binding.search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (s.length < 3) {
                } else {
                    search(s.toString())
                }
            }
            override fun afterTextChanged(s: Editable) {}
        })
    }

    fun search(s: String) {
        binding.empaty.visibility = View.GONE
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonObject> = getDataService.Search(s)
        call.enqueue(object : retrofit2.Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("search_res", response.body().toString())
                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                        var searchItemModel: ArrayList<SearchItemModel> = ArrayList()
                        val data = jsonObject.getJSONArray("data")
                    if (data.length() > 0) {
                        for (i in 0 until data.length()) {
                            val searchModel: SearchItemModel = Gson().fromJson(
                                data.getString(i).toString(),
                                SearchItemModel::class.java
                            )
                            searchItemModel.add(searchModel)
                        }

                    } else {
                        binding.empaty.visibility = View.VISIBLE
                    }

                    var adpter3 = SearchItemAdapter(searchItemModel, applicationContext)
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.searchRecy.layoutManager = layoutManager
                    binding.searchRecy.setHasFixedSize(true)
                    binding.searchRecy.adapter = adpter3


                } catch (e: Exception) {
                    Log.e("search_exe", e.toString())
                }

            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("search_err", t.toString())
            }

        })
    }
}