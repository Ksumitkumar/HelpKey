package com.helpkey.service.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.helpkey.service.Models.TransitionHistoryModel
import com.helpkey.service.databinding.WalletHistoryLayoutBinding

class WalletAdapter(var list: ArrayList<TransitionHistoryModel> ,var context: Context): RecyclerView.Adapter<WalletAdapter.ViewHolder>() {

    var amount = ""

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WalletAdapter.ViewHolder {
        val binding = WalletHistoryLayoutBinding.inflate(LayoutInflater.from(context),parent,false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: WalletAdapter.ViewHolder, position: Int) {
        holder.binding.money.text = list[position].amount
        holder.binding.date.text = list[position].createdAt
        amount = list[position].amount.toString()
        if (amount > 0.toString()) {
//            holder.binding.image.setImageResource(R.drawable.uparrow)
            holder.binding.up.visibility = View.GONE
            holder.binding.down.visibility = View.VISIBLE
            holder.binding.dabit.text = "Credit"
        } else {
            holder.binding.up.visibility = View.VISIBLE
            holder.binding.down.visibility = View.GONE

        }

    }

    override fun getItemCount(): Int {
     return list.size
    }

    inner class ViewHolder(var binding: WalletHistoryLayoutBinding): RecyclerView.ViewHolder(binding.root)
}