package com.helpkey.service.Models

import com.google.gson.annotations.SerializedName
import com.google.gson.annotations.Expose

class TransitionHistoryModel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("user_id")
    @Expose
    var userId: String? = null

    @SerializedName("amount")
    @Expose
    var amount: String? = null

    @SerializedName("by")
    @Expose
    var by: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null

    /**
     * No args constructor for use in serialization
     *
     */
    constructor() {}

    /**
     *
     * @param createdAt
     * @param amount
     * @param by
     * @param id
     * @param userId
     * @param updatedAt
     */
    constructor(
        id: Int?,
        userId: String?,
        amount: String?,
        by: String?,
        createdAt: String?,
        updatedAt: String?
    ) : super() {
        this.id = id
        this.userId = userId
        this.amount = amount
        this.by = by
        this.createdAt = createdAt
        this.updatedAt = updatedAt
    }
}