package com.app.titoserviceapp.Adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Models.NearVendorsModel
import com.helpkey.service.R
import com.helpkey.service.UserActivity.ProductActivity
import com.helpkey.service.databinding.VendorRecylviewBinding
import kotlin.math.min

class NearbyvendorAdapter(var list: ArrayList<NearVendorsModel>,var context: Context): RecyclerView.Adapter<NearbyvendorAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NearbyvendorAdapter.ViewHolder {
        val binding =
            VendorRecylviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.card.setOnClickListener {
            var intent = Intent(context, ProductActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            Constracter.point = "1"
            intent.putExtra("vendor_id",list[position].vendorId.toString())
            intent.putExtra("name",list[position].servicename.toString())
            intent.putExtra("mobile",list[position].mobile.toString())
            intent.putExtra("address",list[position].address.toString())
            intent.putExtra("discount",list[position].discount.toString())
            intent.putExtra("description",list[position].description.toString())
            intent.putExtra("cimg",list[position].coverimage.toString())
            intent.putExtra("simg",list[position].serviceimage.toString())
            intent.putExtra("discount",list[position].percentage.toString())
            context.startActivity(intent)
        }

       holder.binding.vendorName.text = list[position].servicename
        holder.binding.city.text = list[position].address
        Picasso.get().load("https://panels.helpkey.in/public/images/serviceimage/"+list[position].serviceimage).into(holder.binding.image)
        if (list[position].discount.toString() == "null"){
            holder.binding.discount.visibility = View.GONE
        } else {
            holder.binding.discount.text = buildString {
        append(list[position].discount.toString())
        append("% Off")
    }
        }
    }

    override fun getItemCount(): Int {
        return if (Constracter.addressl == "topvendor") {
            list.size
        } else {
            min(list.size, 10)
        }
    }

    inner class ViewHolder(var binding: VendorRecylviewBinding):RecyclerView.ViewHolder(binding.root)
}