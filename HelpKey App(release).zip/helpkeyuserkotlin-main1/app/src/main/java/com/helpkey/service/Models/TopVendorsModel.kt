package com.helpkey.service.Models

import com.google.gson.annotations.SerializedName
import com.google.gson.annotations.Expose

class TopVendorsModel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("username")
    @Expose
    var username: String? = null

    @SerializedName("email")
    @Expose
    var email: String? = null

    @SerializedName("password")
    @Expose
    var password: String? = null

    @SerializedName("mobile")
    @Expose
    var mobile: String? = null

    @SerializedName("gender")
    @Expose
    var gender: String? = null

    @SerializedName("address")
    @Expose
    var address: String? = null

    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("pin_code")
    @Expose
    var pinCode: String? = null

    @SerializedName("country")
    @Expose
    var country: String? = null

    @SerializedName("state")
    @Expose
    var state: String? = null

    @SerializedName("city")
    @Expose
    var city: String? = null

    @SerializedName("image")
    @Expose
    var image: String? = null

    @SerializedName("type")
    @Expose
    var type: String? = null

    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("otp")
    @Expose
    var otp: String? = null

    @SerializedName("otp_status")
    @Expose
    var otpStatus: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null

    @SerializedName("istop")
    @Expose
    var istop: String? = null
    @SerializedName("discount")
    @Expose
    var discount: String? = null

    /**
     * No args constructor for use in serialization
     *
     */
    constructor() {}

    /**
     *
     * @param country
     * @param image
     * @param address
     * @param gender
     * @param city
     * @param mobile
     * @param description
     * @param otp
     * @param type
     * @param createdAt
     * @param password
     * @param istop
     * @param pinCode
     * @param id
     * @param state
     * @param otpStatus
     * @param email
     * @param username
     * @param status
     * @param updatedAt
     * @param discount
     */
    constructor(
        id: Int?,
        username: String?,
        email: String?,
        password: String?,
        mobile: String?,
        gender: String?,
        address: String?,
        description: String?,
        pinCode: String?,
        country: String?,
        state: String?,
        city: String?,
        image: String?,
        type: String?,
        status: String?,
        otp: String?,
        otpStatus: String?,
        createdAt: String?,
        updatedAt: String?,
        istop: String?,
        discount: String?
    ) : super() {
        this.id = id
        this.username = username
        this.email = email
        this.password = password
        this.mobile = mobile
        this.gender = gender
        this.address = address
        this.description = description
        this.pinCode = pinCode
        this.country = country
        this.state = state
        this.city = city
        this.image = image
        this.type = type
        this.status = status
        this.otp = otp
        this.otpStatus = otpStatus
        this.createdAt = createdAt
        this.updatedAt = updatedAt
        this.istop = istop
        this.discount = discount
    }
}