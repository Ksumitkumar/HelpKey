package com.helpkey.service.UserActivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.helpkey.service.databinding.ActivityOrderSuccessBinding

class OrderSuccessActivity : AppCompatActivity() {
    lateinit var binding: ActivityOrderSuccessBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrderSuccessBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.orderId.text = intent.getStringExtra("orderid").toString()

        binding.back.setOnClickListener {
            startActivity(Intent(this@OrderSuccessActivity, DashbordActivity::class.java))
            finishAffinity()
        }

    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this@OrderSuccessActivity, DashbordActivity::class.java))
        finishAffinity()
    }
}