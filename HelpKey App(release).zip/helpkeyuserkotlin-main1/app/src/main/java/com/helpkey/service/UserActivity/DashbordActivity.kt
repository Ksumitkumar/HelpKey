package com.helpkey.service.UserActivity

import BannersModel
import Categorymodel
import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.app.titoserviceapp.Adapter.CategoryAdapter
import com.app.titoserviceapp.Adapter.MostPoupularAdapter
import com.app.titoserviceapp.Adapter.NearbyvendorAdapter
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.card.MaterialCardView
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.squareup.picasso.Picasso
import com.helpkey.service.Adapter.TopVendorAdapter
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.MostPopularVendorsModel
import com.helpkey.service.Models.NearVendorsModel
import com.helpkey.service.Models.ToppointModel
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityDashbordBinding
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*


class DashbordActivity : AppCompatActivity() {
    var regtationLayout = ""
    var referral_no = ""
    var bannersModels: ArrayList<BannersModel> = ArrayList()
    var categorymodels: ArrayList<Categorymodel> = ArrayList()
    var topVendorsModel: ArrayList<ToppointModel> = ArrayList()
    var popularVendorsModel: ArrayList<MostPopularVendorsModel> = ArrayList()
    var nearVendorsModel: ArrayList<NearVendorsModel> = ArrayList()
    var prefrenceManager: PrefrenceManger1? = null
    private lateinit var mFusedLocationClient: FusedLocationProviderClient
    private val permissionId = 2
    private var fusedLocationClient: FusedLocationProviderClient? = null
    private var lastLocation: Location? = null
    private val TAG = "LocationProvider"
    private val REQUEST_PERMISSIONS_REQUEST_CODE = 34

    lateinit var binding: ActivityDashbordBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashbordBinding.inflate(layoutInflater)
        setContentView(binding.root)
        regtationLayout = intent.getStringExtra("RegistrationLayout").toString()
        prefrenceManager = PrefrenceManger1(applicationContext)

        mFusedLocationClient =
            LocationServices.getFusedLocationProviderClient(this@DashbordActivity)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this@DashbordActivity)
        if (!checkPermissions(this)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions()
            }
        } else {
            getLastLocation()
        }

        binding.homelayou.opendrawer.setOnClickListener(View.OnClickListener {
            binding.drawerLayout.openDrawer(GravityCompat.START)
        })
        binding.homelayou.swipe.setOnRefreshListener(SwipeRefreshLayout.OnRefreshListener {
            profile_view()
            Category_user()
            cartCount()
            TopVendors()
            popularVendor()
            if (!checkPermissions(this)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions()
                }
            } else {
                getLastLocation()
            }

        })

        profile_view()
        banner()
        Category_user()
        cartCount()
        TopVendors()
        popularVendor()

        binding.homelayou.search.setOnClickListener {
            startActivity(Intent(this@DashbordActivity, SearchItemActivity::class.java))
        }

        binding.navbar.myWallet.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this, WalletActivity::class.java)
            startActivity(intent)
        }
        binding.navbar.virtualCard.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this, MyvirtualcardActivity::class.java)
            startActivity(intent)
        }
        binding.navbar.shareApp.setOnClickListener {

            binding.drawerLayout.closeDrawer(GravityCompat.START)
            shareDialog()
        }


        binding.navbar.cartNav.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this, CartActivity::class.java)
            startActivity(intent)
        }

        binding.navbar.about.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this@DashbordActivity, AboutWebviewActivity::class.java)
            startActivity(intent)
        }

        binding.navbar.profile.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            val intent = Intent(this, ProfileActivity::class.java)
            intent.putExtra("address", "user")
            startActivity(intent)
        }
        binding.navbar.logout.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            LogoutDialog()
        }

        binding.navbar.myOrder.setOnClickListener {
            val intent = Intent(this, OrderHistroryActivity::class.java)
            startActivity(intent)
        }

        binding.navbar.qrCode.setOnClickListener {
            val intent = Intent(this, QRCodeActivity::class.java)
            startActivity(intent)
        }

        binding.homelayou.carts.setOnClickListener {
            val intent = Intent(this, CartActivity::class.java)
            startActivity(intent)
        }

        binding.homelayou.helpkeyPoint.setOnClickListener {
            var intent = Intent(this, CategoryviewallActivity::class.java)
            intent.putExtra("address", "point")
            intent.putExtra("cat_id", "1")
            Constracter.point = "1"
            startActivity(intent)

        }

        binding.homelayou.helpkeyService.setOnClickListener {
            var intent = Intent(this, CategoryviewallActivity::class.java)
            intent.putExtra("address", "service")
            intent.putExtra("cat_id", "2")
            Constracter.point = "2"
            startActivity(intent)

        }

        binding.homelayou.categoryView.setOnClickListener {
            var intent = Intent(this, CategoryviewallActivity::class.java)
            intent.putExtra("address", "category")
            startActivity(intent)
        }

        binding.homelayou.nearvendorView.setOnClickListener {
            var intent = Intent(this, CategoryviewallActivity::class.java)
            intent.putExtra("address", "nearvendor")
            startActivity(intent)
        }

        binding.homelayou.popularView.setOnClickListener {
            var intent = Intent(this, CategoryviewallActivity::class.java)
            intent.putExtra("address", "popularvendor")
            startActivity(intent)
        }

        binding.homelayou.topvendorView.setOnClickListener {
            var intent = Intent(this, CategoryviewallActivity::class.java)
            intent.putExtra("address", "topvendor")
            startActivity(intent)
        }

        binding.homelayou.recentlyView.setOnClickListener {
            var intent = Intent(this, CategoryviewallActivity::class.java)
            intent.putExtra("address", "recently")
            startActivity(intent)
        }

        binding.navbar.help.setOnClickListener {
            var intent = Intent(this, CategoryviewallActivity::class.java)
            intent.putExtra("address", "help")
            startActivity(intent)
        }


    }

    private fun getLastLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        fusedLocationClient?.lastLocation!!.addOnCompleteListener(this) { task ->
            if (task.isSuccessful && task.result != null) {
                lastLocation = task.result
                Log.e("fdkj", (lastLocation)!!.latitude.toString())
                Log.e("fdkj", (lastLocation)!!.longitude.toString())

                Constracter.latitude = lastLocation!!.latitude.toString()
                Constracter.longitude = lastLocation!!.longitude.toString()
                nearvendor(
                    Constracter.latitude,
                    Constracter.longitude
                )
//                Constracter.lat = (lastLocation)!!.latitude.toString()
//                Constracter.log = (lastLocation)!!.longitude.toString()

                try {
                    val geocoder = Geocoder(this, Locale.getDefault())
                    val list: List<Address> =
                        geocoder.getFromLocation(
                            (lastLocation)!!.latitude,
                            (lastLocation)!!.longitude,
                            1
                        ) as List<Address>
                    binding.apply {
                        Log.e("jfks", list[0].getAddressLine(0))

//                    prefrenceManager?.setlatitude((lastLocation)!!.latitude.toString(),applicationContext)
//                    prefrenceManager?.setlongitude((lastLocation)!!.longitude.toString(),applicationContext)
                        binding.homelayou.address.setText(list[0].getAddressLine(0))


                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("location", e.toString())
                }


            } else {
                Log.w(TAG, "getLastLocation:exception", task.exception)
                //showMessage("No location detected. Make sure location is enabled on the device.")
            }
        }
    }

    private fun showSnackbar(
        mainTextStringId: String, actionStringId: String,
        listener: View.OnClickListener
    ) {
        Toast.makeText(this@DashbordActivity, mainTextStringId, Toast.LENGTH_LONG).show()
    }

    private fun checkPermissions(activity: Activity): Boolean {
        if (ActivityCompat.checkSelfPermission(
                activity,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                activity,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }

    private fun startLocationPermissionRequest() {
        ActivityCompat.requestPermissions(
            this@DashbordActivity,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            REQUEST_PERMISSIONS_REQUEST_CODE
        )
    }

    private fun requestPermissions() {
        val shouldProvideRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (shouldProvideRationale) {
            Log.i(TAG, "Displaying permission rationale to provide additional context.")
            showSnackbar("Location permission is needed for core functionality", "Okay",
                View.OnClickListener {
                    startLocationPermissionRequest()
                })
        } else {
            Log.i(TAG, "Requesting permission")
            startLocationPermissionRequest()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Log.i(TAG, "onRequestPermissionResult")
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            when {
                grantResults.isEmpty() -> {
                    // If user interaction was interrupted, the permission request is cancelled and you
                    // receive empty arrays.
                    Log.i(TAG, "User interaction was cancelled.")
                }
                grantResults[0] == PackageManager.PERMISSION_GRANTED -> {
                    // Permission granted.
                    getLastLocation()
                }
                else -> {
                    showSnackbar("Permission was denied", "Settings",
                        View.OnClickListener {
                            // Build intent that displays the App settings screen.
                            val intent = Intent()
                            intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                            val uri = Uri.fromParts(
                                "package",
                                Build.DISPLAY, null
                            )
                            intent.data = uri
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                        }
                    )
                }
            }
        }
    }

    private fun LogoutDialog() {
        val builder = AlertDialog.Builder(this)
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView: View =
            LayoutInflater.from(applicationContext).inflate(R.layout.exitdialog, viewGroup, false)
        builder.setView(dialogView)
        builder.setCancelable(true)
        val alertDialog = builder.create()
        ((alertDialog.window ?: return).attributes ?: return).gravity = Gravity.BOTTOM
        val exit = dialogView.findViewById<Button>(R.id.exit)
        val logout = dialogView.findViewById<Button>(R.id.logoutbtn)
        val noLogout=dialogView.findViewById<Button>(R.id.logoutNobtn)
        val txt = dialogView.findViewById<TextView>(R.id.txt)
        exit.visibility = View.GONE

        txt.text = "Are you sure to want to logout from this app?"

        logout.setOnClickListener {
            alertDialog.dismiss()
            (prefrenceManager ?: return@setOnClickListener).clearSharedPreference()
            var intent = Intent(this@DashbordActivity, SelectuserTypeActivity::class.java)
            startActivity(intent)
            super.onBackPressed()
            finishAffinity()
        }
        noLogout.setOnClickListener {
           alertDialog.dismiss()
        }
        alertDialog.show()
    }

    private fun shareDialog() {

        val mdliog = LayoutInflater.from(this@DashbordActivity)
            .inflate(R.layout.shareapp_aleartdialog, null)
        val muBulder = AlertDialog.Builder(this@DashbordActivity)
            .setView(mdliog)
        val maliert = muBulder.show()
        maliert.setCancelable(false)
        val yes = mdliog.findViewById<MaterialCardView>(R.id.oky)
        val back = mdliog.findViewById<TextView>(R.id.back)
        val txt = mdliog.findViewById<TextView>(R.id.reffral)
        txt.text = referral_no
        yes.setOnClickListener {
            val intent = Intent()
            intent.action = Intent.ACTION_SEND
            intent.putExtra(
                Intent.EXTRA_TEXT,
                "Hey, I'm here to help you save money with Helpkey! Use my link and become a HelpKey customer!  \uD83C\uDF89\uD83C\uDF89 Let me know if you need assistance with your HelpKey Card order.\n" +
                        "Install this app:" + " " + "https://play.google.com/store/apps/details?id=com.helpkey.service" + " " + "Referral ID:- " + referral_no
            )
            intent.type = "text/plain"
            startActivity(Intent.createChooser(intent, "Share To:"))
            maliert.dismiss()

        }
        back.setOnClickListener { maliert.dismiss() }
    }

    override fun onBackPressed() {
        exitshowDialog()
    }

    private fun exitshowDialog() {
        val builder = AlertDialog.Builder(this)
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView: View = LayoutInflater.from(applicationContext)
            .inflate(R.layout.exitdialog, viewGroup, false)
        builder.setView(dialogView)
        builder.setCancelable(true)
        val alertDialog = builder.create()
        val logout = dialogView.findViewById<Button>(R.id.logoutbtn)
        val logoutNo = dialogView.findViewById<Button>(R.id.logoutNobtn)
        logout.visibility = View.VISIBLE
        logoutNo.visibility=View.VISIBLE


        logout.setOnClickListener {
            alertDialog.dismiss()
            super.onBackPressed()
            val a = Intent(Intent.ACTION_MAIN)
            a.addCategory(Intent.CATEGORY_HOME)
            a.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(a)
            finishAffinity()
        }
        logoutNo.setOnClickListener {
            alertDialog.dismiss()
        }
        alertDialog.show()
    }

    fun banner() {
        bannersModels.clear()
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataService.banner()
        call.enqueue(object : Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                binding.homelayou.swipe.isRefreshing = false
                try {
                    Log.e("banner_res", response.body().toString())
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.optString("status")
                    if (res.equals("success")) {
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Log.e("fddd", jsonArray1.toString())
                        for (i in 0 until jsonArray1.length()) {
                            val bannersModel: BannersModel = Gson().fromJson(
                                jsonArray1.optString(i).toString(),
                                BannersModel::class.java
                            )
                            bannersModels.add(bannersModel)
                        }

                    } else {

                    }

                    val adpter = com.helpkey.service.Adapter.BannerSliderAdapter(
                        bannersModels,
                        applicationContext
                    )
                    binding.homelayou.sider.startAutoScroll(2000)
                    binding.homelayou.sider.adapter = adpter

                    val banneradpter = com.helpkey.service.Adapter.BannerSliderAdapter(
                        bannersModels,
                        applicationContext
                    )
                    binding.homelayou.sider1.startAutoScroll(2000)
                    binding.homelayou.sider1.adapter = banneradpter

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("banner_ex", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("banner_res", t.toString())
            }
        })
    }


    fun Category_user() {
        categorymodels.clear()
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonArray> = getDataService.catgeroy("1")
        call.enqueue(object : Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                binding.homelayou.swipe.isRefreshing = false
                Log.e("category_response", response.body().toString())
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.optString("status")
                    if (res.equals("success")) {
                        binding.homelayou.progressBar.visibility = View.GONE
                        val jsonObject2 = jsonObject.getJSONArray("data")
                        for (i in 0 until jsonObject2.length()) {
                            val categorymodel: Categorymodel = Gson().fromJson(
                                jsonObject2.optString(i).toString(),
                                Categorymodel::class.java
                            )
                            categorymodels.add(categorymodel)
                        }
                    } else {

                    }

                    var adpter1 = CategoryAdapter(categorymodels, applicationContext)
                    val gridLayoutManager = GridLayoutManager(applicationContext, 4)
                    binding.homelayou.recylview.layoutManager = gridLayoutManager
                    binding.homelayou.recylview.setHasFixedSize(true)
                    binding.homelayou.recylview.itemAnimator = DefaultItemAnimator()
                    binding.homelayou.recylview.adapter = adpter1
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("category_exe", response.body().toString())
                    binding.homelayou.progressBar.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("category_error", t.toString())
                binding.homelayou.progressBar.visibility = View.GONE
            }

        })

    }


    fun TopVendors() {
        topVendorsModel.clear()
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.topvendor()

        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                binding.homelayou.swipe.isRefreshing = false
                try {
                    Log.e("top_response", response.body().toString())
                    val jsonObject1 = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject1.optString("status")
                    if (res.equals("success")) {
                        val jsonObject2 = jsonObject1.getJSONArray("data")
                        Log.e("fd", jsonObject2.toString())
                        if (jsonObject2.length() > 0) {
                            for (i in 0 until jsonObject2.length()) {
                                val topvender: ToppointModel = Gson().fromJson(
                                    jsonObject2.optString(i).toString(),
                                    ToppointModel::class.java
                                )
                                topVendorsModel.add(topvender)
                            }

                        } else {

                            Toast.makeText(
                                applicationContext,
                                "Top vendor Not Found",
                                Toast.LENGTH_SHORT
                            )
                                .show()

                        }


                    } else {
                    }
                    var topadapter = TopVendorAdapter(topVendorsModel, applicationContext)
                    val linearLayoutManager = LinearLayoutManager(applicationContext)
                    linearLayoutManager.orientation = LinearLayoutManager.HORIZONTAL
                    binding.homelayou.topvendorRecy.layoutManager = linearLayoutManager
                    binding.homelayou.topvendorRecy.setHasFixedSize(true)
                    binding.homelayou.topvendorRecy.itemAnimator = DefaultItemAnimator()
                    binding.homelayou.topvendorRecy.adapter = topadapter


                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("top_ex", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("top_error", t.toString())
            }
        })
    }

    fun popularVendor() {
        popularVendorsModel.clear()
        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.mostpopular()

        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                binding.homelayou.swipe.isRefreshing = false
                try {
                    Log.e("popularVendor_response", response.body().toString())
                    val jsonObject1 = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject1.optString("status")
                    if (res.equals("success")) {
                        val jsonObject2 = jsonObject1.getJSONArray("data")
                        Log.e("fd", jsonObject2.toString())
                        if (jsonObject2.length() > 0) {
                            for (i in 0 until jsonObject2.length()) {
                                val popularvender: MostPopularVendorsModel = Gson().fromJson(
                                    jsonObject2.optString(i).toString(),
                                    MostPopularVendorsModel::class.java
                                )
                                popularVendorsModel.add(popularvender)
                            }

                        } else {

                            Toast.makeText(
                                applicationContext,
                                "Top vendor Not Found",
                                Toast.LENGTH_SHORT
                            )
                                .show()

                        }


                    } else {
                        Toast.makeText(this@DashbordActivity, "Data  Not Available", Toast.LENGTH_SHORT).show()
                    }
                    val popularAdapter = MostPoupularAdapter(popularVendorsModel, applicationContext)
                    val linearLayoutManager = LinearLayoutManager(applicationContext)
                    linearLayoutManager.orientation = LinearLayoutManager.HORIZONTAL
                    binding.homelayou.popularvendorRecy.layoutManager = linearLayoutManager
                    binding.homelayou.popularvendorRecy.setHasFixedSize(true)
                    binding.homelayou.popularvendorRecy.itemAnimator = DefaultItemAnimator()
                    binding.homelayou.popularvendorRecy.adapter = popularAdapter

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("popularVendor_ex", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("popularVendor_error", t.toString())
            }
        })
    }

    fun cartCount() {
        categorymodels.clear()
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.cart_count(prefrenceManager?.getUserid(applicationContext))
        call.enqueue(object : Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                try {
                    binding.homelayou.swipe.isRefreshing = false
                    Log.e(
                        "cartcount_res",
                        response.body()
                            .toString() + "" + prefrenceManager?.getUserid(applicationContext))
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.optString("status")
                    if (res.equals("success")) {
                        binding.homelayou.cartCount.text = jsonObject.optString("data")
                        binding.homelayou.cartCount.visibility = View.VISIBLE
                    } else {
                        binding.homelayou.cartCount.visibility = View.GONE
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("cartCount_err",e.toString())
                }
                val categoryAdapter = CategoryAdapter(categorymodels, applicationContext)
                val gridLayoutManager = GridLayoutManager(applicationContext, 4)
                binding.homelayou.recylview.layoutManager = gridLayoutManager
                binding.homelayou.recylview.setHasFixedSize(true)
                binding.homelayou.recylview.itemAnimator = DefaultItemAnimator()
                binding.homelayou.recylview.adapter = categoryAdapter
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("cartCount_err", t.toString())
            }

        })

    }
    fun profile_view() {
        val getDataServices: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataServices.view_profile(
            prefrenceManager?.getUserid(applicationContext)
        )
        Log.e("userid", prefrenceManager?.getUserid(applicationContext).toString())
        call.enqueue(object : Callback<JsonArray> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                binding.homelayou.swipe.isRefreshing = false
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e("profile_res", response.body().toString())
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.optString("status")
                    if (res.equals("success")) {
                        val jsonArray1 = jsonObject.getJSONObject("data")
                        binding.navbar.name.text = jsonArray1.optString("username")
                        binding.navbar.email.text = jsonArray1.optString("email")
                        referral_no = jsonArray1.optString("referral_no")
                        prefrenceManager?.setName(
                            jsonArray1.optString("username"),
                            applicationContext
                        )
                        prefrenceManager?.setemail(
                            jsonArray1.optString("email"),
                            applicationContext
                        )
                        Picasso.get()
                            .load(
                                "https://panels.helpkey.in/public/images/profileImage/" + jsonArray1.optString(
                                    "image"
                                )
                            )
                            .placeholder(R.drawable.ic_baseline_person_24)
                            .into(binding.navbar.profileImage)
                        if (!jsonArray1.optString("username").equals("") || !jsonArray1.optString("gender").equals("")) {
                            binding.navbar.qrCode.visibility = View.VISIBLE
                            binding.navbar.view1.visibility = View.VISIBLE
                            binding.navbar.virtualCard.visibility = View.VISIBLE
                            binding.navbar.virtualView.visibility = View.VISIBLE
                        } else {
                            binding.navbar.qrCode.visibility = View.GONE
                            binding.navbar.view1.visibility = View.GONE
                            binding.navbar.virtualCard.visibility = View.GONE
                            binding.navbar.virtualView.visibility = View.GONE
                        }

                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("profile_exe", e.toString())
                    if (e.toString() == "org.json.JSONException: No value for username") {
//                        binding.navbar.qrCode.visibility = View.GONE
                        binding.navbar.view1.visibility = View.GONE
                    }

                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("profile_err", t.toString())

            }

        })

    }

    fun nearvendor(latitude: String, longitude: String) {
        nearVendorsModel.clear()
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.nearbyvendor(
                latitude, longitude
            )
        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                binding.homelayou.swipe.isRefreshing = false
                try {
                    Log.e(
                        "nearVendor_res",
                        response.body().toString() + " " + call.request().url().toString() + " " +
                                longitude + " " +
                                latitude
                    )
                    val jsonObject1 = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject1.optString("status")
                    if (res.equals("success")) {
                        val jsonObject2 = jsonObject1.getJSONArray("data")
                        if (jsonObject2.length() > 0) {
                            binding.homelayou.nearvendorView.visibility = View.VISIBLE
                            for (i in 0 until jsonObject2.length()) {
                                val nearvendor: NearVendorsModel = Gson().fromJson(
                                    jsonObject2.optString(i).toString(),
                                    NearVendorsModel::class.java
                                )
                                if (200 > nearvendor.distance!!.toInt()) {
                                Log.e("nearID", nearvendor.distance.toString()+" "+jsonObject2.length())
                                nearVendorsModel.add(nearvendor)
                                }
                                if (nearVendorsModel.isEmpty()) {
                                    binding.homelayou.nearvendorView.visibility = View.GONE
                                } else {
                                    binding.homelayou.nearvendorView.visibility = View.VISIBLE
                                }
                            }
                        } else {
                            binding.homelayou.nearvendorView.visibility = View.GONE
                            Toast.makeText(
                                applicationContext,
                                "Near Vendor Not Found",
                                Toast.LENGTH_SHORT
                            )
                                .show()
                        }

                    } else {
                        binding.homelayou.nearvendorView.visibility = View.GONE
                    }

                    val nearbyVendor = NearbyvendorAdapter(nearVendorsModel, applicationContext)
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.HORIZONTAL
                    binding.homelayou.vendorRecyl.layoutManager = layoutManager
                    binding.homelayou.vendorRecyl.setHasFixedSize(true)
                    binding.homelayou.vendorRecyl.adapter = nearbyVendor

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("nearVendor_exe", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.i("nearVendor_err", t.toString())
            }
        })
    }

    override fun onRestart() {
        super.onRestart()
        cartCount()
        profile_view()
        Category_user()
    }

}