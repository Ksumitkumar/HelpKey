package com.helpkey.service.Adapter

import android.content.Context
import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.helpkey.service.Models.UserCardPaymentHistoryModel
import com.helpkey.service.databinding.UsercardHistoryLayoutBinding

class UserCardPaymentHistoryAdapter(
    var list: ArrayList<UserCardPaymentHistoryModel>,
    var context: Context
) : RecyclerView.Adapter<UserCardPaymentHistoryAdapter.ViewHolder>() {

    var amount = ""

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): UserCardPaymentHistoryAdapter.ViewHolder {
        val binding =
            UsercardHistoryLayoutBinding.inflate(LayoutInflater.from(context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UserCardPaymentHistoryAdapter.ViewHolder, position: Int) {
        holder.binding.servicename.text = buildString {
            append(": ")
            append(list[position].servicename.toString())
        }
        holder.binding.cardNo.text = buildString {
            append(": ")
            append(list[position].cardNo.toString())
        }
        holder.binding.address.text = buildString {
            append(": ")
            append(list[position].address.toString())
        }
        holder.binding.discount.text = buildString {
            append(": ")
            append(list[position].discount.toString())
        }
        holder.binding.totalAmount.text = buildString {
            append(": ₹ ")
            append(list[position].totalAmount.toString())
        }
        holder.binding.totalAmount.paintFlags = Paint.STRIKE_THRU_TEXT_FLAG
        holder.binding.discountedAmount.text = buildString {
            append(": ₹ ")
            append(list[position].discountedAmount.toString())
        }
        holder.binding.date.text = buildString {
            append(": ")
            append(list[position].createdAt.toString())
        }

    }
    override fun getItemCount(): Int {
        return list.size
    }
    inner class ViewHolder(var binding: UsercardHistoryLayoutBinding) :
        RecyclerView.ViewHolder(binding.root)
}