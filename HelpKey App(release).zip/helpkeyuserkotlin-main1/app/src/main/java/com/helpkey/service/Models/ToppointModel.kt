package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ToppointModel {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("vendorId")
    @Expose
    var vendorId: String? = null

    @SerializedName("servicename")
    @Expose
    var servicename: String? = null

    @SerializedName("vendor_name")
    @Expose
    var vendorName: String? = null

    @SerializedName("price")
    @Expose
    var price: Any? = null

    @SerializedName("address")
    @Expose
    var address: String? = null

    @SerializedName("category")
    @Expose
    var category: String? = null

    @SerializedName("subcategory")
    @Expose
    var subcategory: String? = null

    @SerializedName("coverimage")
    @Expose
    var coverimage: String? = null

    @SerializedName("serviceimage")
    @Expose
    var serviceimage: String? = null

    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("discount")
    @Expose
    var discount: Any? = null

    @SerializedName("mobile")
    @Expose
    var mobile: String? = null

    @SerializedName("email")
    @Expose
    var email: String? = null

    @SerializedName("document")
    @Expose
    var document: String? = null

    @SerializedName("type")
    @Expose
    var type: String? = null

    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("agreement")
    @Expose
    var agreement: String? = null

    @SerializedName("percentage")
    @Expose
    var percentage: String? = null

    @SerializedName("percentage_status")
    @Expose
    var percentageStatus: String? = null

    @SerializedName("popular")
    @Expose
    var popular: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null

    @SerializedName("username")
    @Expose
    var username: String? = null

    /**
     * No args constructor for use in serialization
     *
     */
    constructor() {}

    /**
     *
     * @param address
     * @param agreement
     * @param document
     * @param mobile
     * @param vendorId
     * @param description
     * @param discount
     * @param vendorName
     * @param type
     * @param percentageStatus
     * @param createdAt
     * @param coverimage
     * @param price
     * @param percentage
     * @param serviceimage
     * @param servicename
     * @param id
     * @param category
     * @param subcategory
     * @param popular
     * @param email
     * @param status
     * @param updatedAt
     * @param username
     */
    constructor(
        id: Int?,
        vendorId: String?,
        servicename: String?,
        vendorName: String?,
        price: Any?,
        address: String?,
        category: String?,
        subcategory: String?,
        coverimage: String?,
        serviceimage: String?,
        description: String?,
        discount: Any?,
        mobile: String?,
        email: String?,
        document: String?,
        type: String?,
        status: String?,
        agreement: String?,
        percentage: String?,
        percentageStatus: String?,
        popular: String?,
        createdAt: String?,
        updatedAt: String?,
        username: String?
    ) : super() {
        this.id = id
        this.vendorId = vendorId
        this.servicename = servicename
        this.vendorName = vendorName
        this.price = price
        this.address = address
        this.category = category
        this.subcategory = subcategory
        this.coverimage = coverimage
        this.serviceimage = serviceimage
        this.description = description
        this.discount = discount
        this.mobile = mobile
        this.email = email
        this.document = document
        this.type = type
        this.status = status
        this.agreement = agreement
        this.percentage = percentage
        this.percentageStatus = percentageStatus
        this.popular = popular
        this.createdAt = createdAt
        this.updatedAt = updatedAt
        this.username = username
    }
}