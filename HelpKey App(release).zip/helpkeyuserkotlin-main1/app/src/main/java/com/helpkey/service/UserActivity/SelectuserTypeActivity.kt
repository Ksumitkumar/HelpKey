package com.helpkey.service.UserActivity

import android.content.Intent
import android.os.Bundle
import android.view.View

import androidx.appcompat.app.AppCompatActivity
import br.com.helpdev.sms.helper.PrefrenceManger1

import com.helpkey.service.databinding.ActivitySelectuserTypeBinding

class SelectuserTypeActivity : AppCompatActivity() {

    var address = ""
    lateinit var binding: ActivitySelectuserTypeBinding
    var prefrenceManager: PrefrenceManger1? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectuserTypeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefrenceManager = PrefrenceManger1(applicationContext)

        address = intent.getStringExtra("address").toString()

        when (address) {
            "main" -> {
                binding.mainlayout2.visibility = View.VISIBLE
                binding.done.setOnClickListener {
                    (prefrenceManager ?: return@setOnClickListener).clearSharedPreference()
                    val a = Intent(Intent.ACTION_MAIN)
                    a.addCategory(Intent.CATEGORY_HOME)
                    a.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(a)
                    finishAffinity()
                }
            }
            "vendorre" -> {
                binding.mainlayout2.visibility = View.VISIBLE
                binding.done.setOnClickListener {
                    (prefrenceManager ?: return@setOnClickListener).clearSharedPreference()
                    val a = Intent(Intent.ACTION_MAIN)
                    a.addCategory(Intent.CATEGORY_HOME)
                    a.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(a)
                    finishAffinity()
                }
            }
            "vendorlogin" -> {
                binding.mainlayout2.visibility = View.VISIBLE
                binding.done.setOnClickListener {
                    (prefrenceManager ?: return@setOnClickListener).clearSharedPreference()
                    val a = Intent(Intent.ACTION_MAIN)
                    a.addCategory(Intent.CATEGORY_HOME)
                    a.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(a)
                    finishAffinity()
                }
            }
        }

        binding.user.setOnClickListener {
            prefrenceManager?.settype("user",applicationContext)
            var mainintati = Intent(this, NumberInputActivity::class.java)
            mainintati.putExtra("selectuser","User")
            startActivity(mainintati)
        }
        binding.vendor.setOnClickListener {
            prefrenceManager?.settype("vendor",applicationContext)
            var mainintati = Intent(this, NumberInputActivity::class.java)
            mainintati.putExtra("selectuser","vendor")
            startActivity(mainintati)
        }
    }
}