package com.helpkey.service.UserActivity

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.ernestoyaquello.dragdropswiperecyclerview.DragDropSwipeRecyclerView
import com.ernestoyaquello.dragdropswiperecyclerview.listener.OnItemSwipeListener
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.helpkey.service.Adapter.CartAdapter
import com.helpkey.service.Helper.Constracter

import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.CartModel
import com.helpkey.service.R
import com.helpkey.service.databinding.ActivityCartBinding
import org.json.JSONArray
import org.json.JSONException
import retrofit2.Call
import retrofit2.Response

class CartActivity : AppCompatActivity(),
    CartAdapter.CartDelete {
    var prefrenceManager: PrefrenceManger1? = null
    var cartModels: ArrayList<CartModel> = ArrayList()
    var itemCount = ""
    lateinit var binding: ActivityCartBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefrenceManager = PrefrenceManger1(applicationContext)

        binding.back.setOnClickListener { finish() }

        binding.buynow.setOnClickListener {
            profile_view()
        }
        cart_data()
    }

    fun cart_data() {
        cartModels.clear()
        binding.progress.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataService.view_cart(
            prefrenceManager?.getUserid(applicationContext)
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e("cart_res", response.body().toString())
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progress.visibility = View.GONE
                        binding.totals.visibility = View.VISIBLE
                        Constracter.amont = jsonObject.getString("totalPrice")
                        binding.totalamoutn.text = Constracter.amont
                        val jsonObject2 = jsonObject.getJSONArray("data")
                        for (i in 0 until jsonObject2.length()) {
                            val cartModel: CartModel = Gson().fromJson(
                                jsonObject2.getString(i).toString(),
                                CartModel::class.java

                            )
                            cartModels.add(cartModel)


                        }
                        Constracter.itemcount = cartModels.count().toString()

                    } else {

                        binding.totals.visibility = View.GONE
                        binding.progress.visibility = View.GONE
                        binding.empaty.visibility = View.VISIBLE
                        binding.totalamoutn.text = "00"

                    }

                    var cardater = CartAdapter(
                        cartModels,
                        this@CartActivity
                    )
                    binding.recylviewCart.layoutManager = LinearLayoutManager(applicationContext)
                    binding.recylviewCart.longPressToStartDragging = true
                    binding.recylviewCart.disableSwipeDirection(DragDropSwipeRecyclerView.ListOrientation.DirectionFlag.RIGHT)
                    binding.recylviewCart.reduceItemAlphaOnSwiping = true
                    binding.recylviewCart.behindSwipedItemBackgroundColor = Color.RED
                    binding.recylviewCart.behindSwipedItemIconDrawableId = R.drawable.delete
                    binding.recylviewCart.behindSwipedItemIconMargin = 60f
                    binding.recylviewCart.adapter = cardater
                    try {
                        val onItemSwipeListener = object : OnItemSwipeListener<CartModel> {
                            override fun onItemSwiped(
                                position: Int,
                                direction: OnItemSwipeListener.SwipeDirection,
                                item: CartModel
                            ): Boolean {
                                // Delete api call
                                cart_Delete(cartModels[position].cart_id.toString())
                                return true
                            }
                        }
                        binding.recylviewCart.swipeListener = onItemSwipeListener
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                } catch (e: Exception) {
                    Log.e("cart_error", e.toString())
                    binding.progress.visibility = View.GONE
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("cart_error", t.toString())
                binding.progress.visibility = View.GONE
            }

        })

    }

    fun cart_Delete(cart_id: String) {

        var getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        var call: Call<JsonArray> = getDataService.delete_cart(cart_id)
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e("cartdelet_res", response.body().toString())
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        Toast.makeText(
                            this@CartActivity,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                        cart_data()


                    } else {
                        Toast.makeText(
                            this@CartActivity,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: Exception) {
                    Log.e("cartdelet_ex", e.toString())
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("cartdelet_error", t.toString())
            }

        })

    }

    fun profile_view() {
        binding.progress.visibility = View.VISIBLE
        val getDataServices: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataServices.view_profile(
            prefrenceManager?.getUserid(applicationContext)
        )
        Log.e("userid", prefrenceManager?.getUserid(applicationContext).toString())
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {

                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e("profile_response", jsonArray.toString())
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progress.visibility = View.GONE
                        val jsonArray1 = jsonObject.getJSONObject("data")
                        val name = jsonArray1.getString("username")

                        val intent = Intent(this@CartActivity, PlaceHolderActivity::class.java)
                        startActivity(intent)

                    } else {

                    }
                } catch (e: JSONException) {
                    binding.progress.visibility = View.GONE
                    e.printStackTrace()
                    Log.e("profile_error", e.toString())
                    Toast.makeText(this@CartActivity, "Please Update Profile", Toast.LENGTH_SHORT)
                        .show()
                    if (e.toString() == "org.json.JSONException: No value for username") {
                        showDialog()
                    } else {

                    }
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                binding.progress.visibility = View.GONE
                Log.e("profile_error", t.toString())

            }

        })

    }

    private fun showDialog() {
        val builder = AlertDialog.Builder(this@CartActivity)
        val viewGroup = this@CartActivity.findViewById<ViewGroup>(android.R.id.content)
        val dialogView: View = LayoutInflater.from(this@CartActivity)
            .inflate(R.layout.bookedservices_aleartdialog, viewGroup, false)
        builder.setView(dialogView)
        builder.setCancelable(true)
        val alertDialog = builder.create()
        val yes = dialogView.findViewById<TextView>(R.id.yes)
        val gotoCart = dialogView.findViewById<TextView>(R.id.goto_cart)

        yes.setOnClickListener {
            var intent = Intent(this@CartActivity, DashbordActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            alertDialog.dismiss()
        }

        gotoCart.setOnClickListener {
            var intent = Intent(this@CartActivity, EditeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            alertDialog.dismiss()
        }

        alertDialog.show()
    }

    override fun cardItemDelete(position: Int) {
        try {
            cart_Delete(cartModels[position].cart_id.toString())
        }catch (e:Exception){
            e.localizedMessage
        }


    }
}