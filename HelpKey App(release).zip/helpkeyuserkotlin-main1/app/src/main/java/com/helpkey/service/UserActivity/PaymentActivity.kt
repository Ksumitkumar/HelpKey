package com.helpkey.service.UserActivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.helpkey.service.R

class PaymentActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

//        val siDetails  = PayUSIParams.Builder()
//            .setIsFreeTrial(true) //set it to true for free trial. Default value is false
//            .setBillingAmount("1.0")
//            .setBillingCycle(PayUBillingCycle.ONCE)
//            .setBillingCurrency("INR")
//            .setBillingInterval(1)
//            .setPaymentStartDate("2021-12-24")
//            .setPaymentEndDate("2021-12-31")
//            .setBillingRule(PayuBillingRule.MAX)
//            .setBillingLimit(PayuBillingLimit.ON)
//            .setRemarks("SI Txn")
//            .build()
    }
}