package com.helpkey.service.UserActivity


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.helpkey.service.Adapter.SubcategoryuserAdapter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.SubcategoryModel
import com.helpkey.service.databinding.ActivitySubcategoryuserBinding
import org.json.JSONArray
import org.json.JSONException
import retrofit2.Call
import retrofit2.Response


class SubcategoryuserActivity : AppCompatActivity() {
    companion object{
        var  id=""
    }

    lateinit var binding: ActivitySubcategoryuserBinding
    var subcategoryModels: ArrayList<SubcategoryModel> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySubcategoryuserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tital.text = intent.getStringExtra("name")

        id=  intent.getStringExtra("id").toString()

        binding.back.setOnClickListener { finish() }
        sub_category()

    }

    fun sub_category() {
        binding.progress.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> = getDataService.fetch_category(intent.getStringExtra("id"))
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                binding.progress.visibility = View.GONE
                try {
                    Log.e("subcat_res", response.body().toString()+" "+call.request().url().toString())
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Log.e("fddd", jsonArray1.toString())
                        if (jsonArray1.length() > 0) {

                            for (i in 0 until jsonArray1.length()) {
                                val subcategoryModel: SubcategoryModel = Gson().fromJson(
                                    jsonArray1.getString(i).toString(),
                                    SubcategoryModel::class.java
                                )
                                subcategoryModels.add(subcategoryModel)
                            }

                        } else {
                            binding.empaty.visibility = View.VISIBLE
                        }

                    } else {

                        binding.empaty.visibility = View.VISIBLE
                    }

                    var adpter3 = SubcategoryuserAdapter(subcategoryModels, applicationContext)
                    val layoutManager = LinearLayoutManager(applicationContext)
                    layoutManager.orientation = LinearLayoutManager.VERTICAL
                    binding.subcategory.layoutManager = layoutManager
                    binding.subcategory.setHasFixedSize(true)
                    binding.subcategory.adapter = adpter3

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("subcat_ex", e.toString())
                    binding.progress.visibility = View.GONE
                    binding.empaty.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("subcat_res", t.toString())
                binding.progress.visibility = View.GONE
                binding.empaty.visibility = View.VISIBLE
            }
        })
    }
}