package com.helpkey.service.UserActivity

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.VendorActivity.VendorDashbordActivity
import com.helpkey.service.databinding.ActivityOtpBinding
import org.json.JSONArray
import org.json.JSONException
import retrofit2.Call
import retrofit2.Response
import retrofit2.create

class OtpActivity : AppCompatActivity() {
    var otps = ""
    var mobilenumber = ""
    var message = ""
    var prefrenceManager: PrefrenceManger1? = null

    lateinit var binding: ActivityOtpBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOtpBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefrenceManager = PrefrenceManger1(applicationContext)
        message = intent.getStringExtra("message").toString()
        otps = intent.getStringExtra("otp").toString()
        mobilenumber = intent.getStringExtra("mobile").toString()
        prefrenceManager!!.setMobileno(
            mobilenumber,
            applicationContext
        )
        prefrenceManager!!.setUserId(
            intent.getStringExtra("id").toString(),
            applicationContext
        )
      //  Toast.makeText(applicationContext, "Your OTP :- $otps", Toast.LENGTH_SHORT).show()
        binding.submitOtp.setOnClickListener {

            if (prefrenceManager?.gettype(applicationContext).equals("user")) {

                otp_verification()

            } else if (prefrenceManager?.gettype(applicationContext).equals("vendor")) {

                vendor_otp_verification()
            }
        }

        object : CountDownTimer(30000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                binding.resendOtp.text = "" + millisUntilFinished / 1000 + " sec"
            }

            override fun onFinish() {
                binding.resendOtp.text = "resend otp"
            }
        }.start()


        binding.resendOtp.setOnClickListener {

            object : CountDownTimer(30000, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    binding.resendOtp.text = "" + millisUntilFinished / 1000 + " sec"
                }

                override fun onFinish() {
                    binding.resendOtp.text = "resend otp"
                }
            }.start()

        }

    }


    fun otp_verification() {
        binding.progress.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.verify_otp(
                "user",
                binding.otpView.otp, prefrenceManager?.getmobilno(applicationContext)
            )
        Log.e("userdetail", binding.otpView.otp.toString() + " " + mobilenumber)
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e(
                    "number_res",
                    response.body().toString() + " " + call.request().url().toString()
                )

                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progress.visibility = View.GONE
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()

                        if (intent.getStringExtra("forget") == "password") {
                            var intent =
                                Intent(this@OtpActivity, ChangePasswordActivity::class.java)
                            intent.putExtra("change", "user")
                            startActivity(intent)
                            finishAffinity()
                        } else {
                            prefrenceManager!!.settype(
                                "user",
                                applicationContext
                            )
                            var intent = Intent(this@OtpActivity, DashbordActivity::class.java)
                            intent.putExtra("RegistrationLayout", "members")
                            startActivity(intent)
                            finishAffinity()
                        }


                    } else {
                        binding.progress.visibility = View.GONE
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: JSONException) {
                    binding.progress.visibility = View.GONE
                    e.printStackTrace()
                    Log.e("otp_ex", e.toString())


                }
            }


            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                binding.progress.visibility = View.GONE
                Log.e("otp_error", t.toString())

            }
        })
    }

    fun vendor_otp_verification() {
        binding.progress.visibility = View.VISIBLE
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.verify_otp(
                "vendor",
                binding.otpView.otp, mobilenumber
            )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e(
                    "vendornumber_res",
                    response.body().toString() + " " + call.request().url().toString()
                )
                Log.e("userdetail", binding.otpView.otp.toString() + " " + mobilenumber)

                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        binding.progress.visibility = View.GONE
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        val jsonObject1 = jsonArray1.getJSONObject(0)
                        val status = jsonObject1.getString("status")
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                        if (intent.getStringExtra("forget") == "password") {
                            val intent =
                                Intent(this@OtpActivity, ChangePasswordActivity::class.java)
                            intent.putExtra("change", "vendor")
                            startActivity(intent)
                            finishAffinity()
                        } else {
                            if (message == ("OTP sent on your registered mobile number")) {
                                if (status == "Deactive") {
                                    intent = Intent(
                                        applicationContext,
                                        SelectuserTypeActivity::class.java
                                    )
                                    intent.putExtra("address", "vendorlogin")
                                    startActivity(intent)
                                    finish()
                                } else {
                                    val intent =
                                        Intent(this@OtpActivity, VendorDashbordActivity::class.java)
                                    intent.putExtra("RegistrationLayout", "members")
                                    startActivity(intent)
                                    finishAffinity()
                                }

                            } else {
                                intent =
                                    Intent(applicationContext, VendorDashbordActivity::class.java)
                                startActivity(intent)
                            }
                        }

                    } else {
                        binding.progress.visibility = View.GONE
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: JSONException) {
                    binding.progress.visibility = View.GONE
                    e.printStackTrace()
                    Log.e("vendorotp_ex", e.toString())


                }
            }


            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                binding.progress.visibility = View.GONE
                Log.e("vendorotp_error", t.toString())

            }

        })
    }

}