package com.helpkey.service.Adapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.Models.VendorAllOrderRequestModel
import com.helpkey.service.R
import com.helpkey.service.VendorActivity.VendorTodayOrderActivity
import com.helpkey.service.databinding.VendortodayorderRecylviewBinding
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class VendorTodayorderAdapter(
    var list: ArrayList<VendorAllOrderRequestModel>,
    var context: Context
) : RecyclerView.Adapter<VendorTodayorderAdapter.ViewHoder>() {


    inner class ViewHoder(var binding: VendortodayorderRecylviewBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHoder {
        val binding = VendortodayorderRecylviewBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHoder(binding)

    }

    @SuppressLint("ResourceAsColor")
    override fun onBindViewHolder(holder: ViewHoder, position: Int) {

        holder.binding.itemname.text = list[position].servicename
        holder.binding.productname.text = list[position].servicename
        holder.binding.price.text = "₹ " + list[position].serviceCost
        holder.binding.date.text = list[position].createdAt
        holder.binding.orderid.text = list[position].orderNo
        holder.binding.address.text = list[position].deliveryAddress
        holder.binding.userName.text = list[position].username
        holder.binding.orderStatus.text = list[position].orderStatus
        holder.binding.addtype.text = list[position].addressType
        holder.binding.mobile.text = "+91 ${list[position].mobile}"



        holder.binding.call.setOnClickListener {
            Constracter.mobile = "+91 ${list[position].mobile.toString()}"
            VendorTodayOrderActivity.activity.call()
        }

        if (Constracter.manegestatus == "1") {
            holder.binding.conform.visibility = View.VISIBLE
        } else {
            holder.binding.conform.visibility = View.GONE
        }

        if (list[position].paymentStatus == "false") {
            holder.binding.payStatus.text = "Failed"
            holder.binding.payStatus.setTextColor(Color.parseColor("#e10028"))
        } else {
            holder.binding.payStatus.text = "Success"
            holder.binding.payStatus.setTextColor(Color.parseColor("#008640"))
        }

        if (list[position].paymentMethod == "cod") {
            holder.binding.paytype.text = "Cash On Delivery"
        } else {
            holder.binding.paytype.text = "PayU Online"
        }


        if (list[position].orderStatus.equals("Pending") || list[position].orderStatus.equals("Processing")){
            holder.binding.conform.visibility=View.VISIBLE
        } else{
            holder.binding.conform.visibility=View.GONE
        }

        holder.binding.conform.setOnClickListener {
            try {
                var order_sta = "Pending"
                val mdliog = LayoutInflater.from(context)
                    .inflate(R.layout.service_status, null)
                val muBulder = AlertDialog.Builder(context)
                    .setView(mdliog)
                muBulder.setCancelable(false)
                val maliert = muBulder.show()
                val yes = mdliog.findViewById<TextView>(R.id.yes)
                val no = mdliog.findViewById<TextView>(R.id.no)
                val txt = mdliog.findViewById<TextView>(R.id.txt)
                val radioButton = mdliog.findViewById<RadioGroup>(R.id.radiogroupstatus)
                // val radioButton1 = mdliog.findViewById<RadioGroup>(R.id.radiogroupstatus1)

                radioButton.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
                    val radio: RadioButton = group.findViewById(checkedId)
                    order_sta = radio.text.toString()
                    Log.e("status", order_sta)

                })

//            radioButton1.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
//                val radio: RadioButton = group.findViewById(checkedId)
//                order_sta = radio.text.toString()
//                Log.e("status",order_sta.toString())
//            })
                yes.setOnClickListener {
                    Order_status(list[position].orderNo.toString(), order_sta, position)
                    maliert.dismiss()
                }

                no.setOnClickListener { maliert.dismiss() }
            }
            catch (e: Exception) {
                e.localizedMessage
            }

        }


    }

    override fun getItemCount(): Int {
        return list.size
    }

    fun Order_status(ids: String, status: String, position: Int) {
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonObject> =
            getDataService.booked_order_status(ids, status)
        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                Log.e("status_res", response.body().toString() + " " + ids)

                try {
                    val jsonObject = JSONObject(Gson().toJson(response.body()))
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        list.removeAt(position)
                        notifyItemRemoved(position)
                        notifyItemRangeChanged(position, list.size)
                        Toast.makeText(context, jsonObject.getString("msg"), Toast.LENGTH_SHORT)
                            .show()

                    } else {
                        Toast.makeText(context, jsonObject.getString("msg"), Toast.LENGTH_SHORT)
                            .show()

                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("status_ex", e.toString())
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.e("status_error", t.toString())
            }

        })

    }
}


