package com.helpkey.service.Adapter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.squareup.picasso.Picasso
import com.helpkey.service.Models.FamliyCardModel
import com.helpkey.service.R
import com.helpkey.service.databinding.FamliycardRecylviewBinding

class FamliycardAdapter(val list: ArrayList<FamliyCardModel>, var context: Context) :
    RecyclerView.Adapter<FamliycardAdapter.ViewHolder>() {
    inner class ViewHolder(var binding: FamliycardRecylviewBinding) :
        RecyclerView.ViewHolder(binding.root)

    var prefrenceManager: PrefrenceManger1? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        prefrenceManager = PrefrenceManger1(context)
        var binding =
            FamliycardRecylviewBinding.inflate(LayoutInflater.from(context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.cardName.text = buildString {
        append(list[position].name)
    }
        var s = ""
        val s2 = list[position].virtual_card_no?.toCharArray()
        if (s2 != null) {
            for (i in s2.indices) {
                when (i) {
                    3 -> {
                        s += s2[i] + "   "
                    }
                    7 -> {
                        s += s2[i] + "   "
                    }
                    11 -> {
                        s += s2[i] + "   "
                    }
                    else -> {
                        s += s2[i]
                    }
                }
            }
        }
        val qrCodeWriter = QRCodeWriter()
        val bitMatrix =
            qrCodeWriter.encode(
                "https://panels.helpkey.in/user_cart/${list[position].id}/card", BarcodeFormat.QR_CODE, 200, 200
            )
        val bitmap = Bitmap.createBitmap(200, 200, Bitmap.Config.RGB_565)
        for (x in 0..199) {
            for (y in 0..199) {
                bitmap.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
            }
        }
        holder.binding.familyQr.setImageBitmap(bitmap)
       // holder.binding.cardNo.text = s

        if (list[position].card_status.equals("Pending")){
            holder.binding.cardNo.text = "Pending"
            holder.binding.familyQrLayout.visibility = View.INVISIBLE
        }else{
            holder.binding.cardNo.text = s
        }

        holder.binding.address.text = buildString {
            append("Address:- ")
            append(list[position].address)
        }
        holder.binding.exDate.text = list[position].card_validity
        Picasso.get().load("https://panels.helpkey.in/images/documentimages/" + list[position].photo)
            .placeholder(R.drawable.persion)
            .into(holder.binding.image)
        holder.binding.familyWork.text = list[position].work

    }

    override fun getItemCount(): Int {
        return list.size
    }
}