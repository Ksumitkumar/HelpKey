package com.app.titoserviceapp.Adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.Models.MostPopularVendorsModel
import com.helpkey.service.R
import com.helpkey.service.UserActivity.ProductFulldetailsActivity
import com.helpkey.service.UserActivity.SubcategoryuserActivity
import com.helpkey.service.databinding.MostpopularRecyBinding
import kotlin.math.min

class MostPoupularAdapter(var list: ArrayList<MostPopularVendorsModel>, var context: Context) :
    RecyclerView.Adapter<MostPoupularAdapter.ViewHolder>() {

    var number: Double? = null
    var price = ""

    inner class ViewHolder(var binding: MostpopularRecyBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            MostpopularRecyBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        number = list[position].price?.toDouble()
        if (number!! <= 0) {
            price = "Book Appointment"
        } else {
            price = "₹ " + number.toString()
        }
        holder.binding.card.setOnClickListener {

            var intent = Intent(context, ProductFulldetailsActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            intent.putExtra("id", list[position].id.toString())
            intent.putExtra("name", list[position].username.toString())
            intent.putExtra("mobile", list[position].mobile.toString())
            intent.putExtra("address", list[position].address.toString())
            intent.putExtra("productname", list[position].servicename.toString())
            intent.putExtra("price", list[position].price.toString())
            intent.putExtra("description", list[position].description.toString())
            intent.putExtra("img", list[position].serviceimage.toString())
            intent.putExtra("discount", holder.binding.discount.text.toString())
            context.startActivity(intent)
        }
        if (list[position].discount.toString() == "null") {
            holder.binding.discount.visibility = View.GONE
        } else {
            holder.binding.discount.text = buildString {
                append(list[position].discount.toString())
                append("% off")
            }
        }
        holder.binding.vendorName.text = list[position].servicename.toString()
        holder.binding.vendorLocation.text = list[position].address.toString()
        Picasso.get()
            .load("https://panels.helpkey.in/public/images/serviceimage/" + list[position].serviceimage)
            .placeholder(R.drawable.vendor)
            .into(holder.binding.img)
    }

    override fun getItemCount(): Int {
        return if (Constracter.addressl == "topvendor") {
            list.size
        } else {
            min(list.size, 10)
        }
    }


}