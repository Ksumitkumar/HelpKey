package com.helpkey.service.Models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ShowAddressModel {

    @SerializedName("id")
    @Expose
    var id: String? = null

    @SerializedName("user_id")
    @Expose
    var user_id: String? = null

    @SerializedName("address")
    @Expose
    var address: String? = null

    constructor(id: String, user_id: String, address: String?) {
        this.id = id
        this.user_id = user_id
        this.address = address
    }
}