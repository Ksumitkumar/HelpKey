package com.app.titoserviceapp.Adapter

import Categorymodel
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.helpkey.service.Helper.Constracter
import com.helpkey.service.UserActivity.SubcategoryuserActivity
import com.helpkey.service.UserActivity.VendorAcitivityUser
import com.helpkey.service.databinding.AllcategoryBinding
import com.helpkey.service.databinding.CategoryRecylviewBinding


class AllCategoryAdapter(var list: ArrayList<Categorymodel>, var context: Context) :
    RecyclerView.Adapter<AllCategoryAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): AllCategoryAdapter.MyViewHolder {
        val binding =
            AllcategoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AllCategoryAdapter.MyViewHolder, position: Int) {

        holder.binding.categoryName.text = buildString {
            append(list[position].cateName?.substring(0, 1)?.uppercase())
            append(list[position].cateName?.substring(1)?.lowercase())
        }
        Picasso.get().load("https://panels.helpkey.in/images/category/" + list[position].image)
            .into(holder.binding.img)
        holder.binding.card.setOnClickListener {
            var intent = Intent(context, SubcategoryuserActivity::class.java)
            Constracter.category_id = list[position].id.toString()
            intent.putExtra("id", list[position].id.toString())
            intent.putExtra("name", holder.binding.categoryName.text.toString())
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class MyViewHolder(val binding: AllcategoryBinding) :
        RecyclerView.ViewHolder(binding.root)
}