package com.helpkey.service.VendorActivity

import android.Manifest
import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import br.com.helpdev.sms.helper.PrefrenceManger1
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.helpkey.service.Helper.GetDataService
import com.helpkey.service.Helper.RetrofitClintanse
import com.helpkey.service.UserActivity.SelectuserTypeActivity
import com.helpkey.service.databinding.ActivityVendorRegistrationBinding
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.json.JSONArray
import org.json.JSONException
import retrofit2.Call
import retrofit2.Response
import java.io.File
import java.util.*

class VendorRegistrationActivity : AppCompatActivity() {
    lateinit var binding: ActivityVendorRegistrationBinding

    var addresss = ""
    var latitude = ""
    var longitude = ""
    var id = ""
    var mobile = ""
    var gender = "Male"
    var prefrenceManager: PrefrenceManger1? = null
    var uri = Uri.parse("")
    var image = ""
    internal val TAG = "LocationProvider"
    internal val REQUEST_PERMISSIONS_REQUEST_CODE = 34
    var localaddress = ""
    private lateinit var mFusedLocationClient: FusedLocationProviderClient
    private var lastLocation: Location? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding= ActivityVendorRegistrationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        prefrenceManager = PrefrenceManger1(applicationContext)

        id = (prefrenceManager?.getUserid(applicationContext) ?: return)
        binding.vendorMobile.setText(prefrenceManager?.getmobilno(applicationContext))

        binding.radiogroup.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->

            val radio: RadioButton = group.findViewById(checkedId)

            gender = radio.text.toString()


        })

        binding.signUp.setOnClickListener {
             if (validation()) {
                if (uri.path.equals("")) {
                   Toast.makeText(this@VendorRegistrationActivity,"Please Upload Profile Image",Toast.LENGTH_SHORT).show()
                } else {
                        Vendor_regiter()
                }

            } else {

            }
        }

        binding.profileImage.setOnClickListener {
            ImagePicker.with(this)
                .crop()                    //Crop image(Optional), Check Customization for more option
                .compress(1024)            //Final image size will be less than 1 MB(Optional)
                .maxResultSize(
                    1080,
                    1080
                )
                //Final image resolution will be less than 1080 x 1080(Optional)
                .start()
        }

        if (!checkPermissions()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions()
            }
        } else {
            getLastLocation()
        }

    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (resultCode) {
            Activity.RESULT_OK -> {
                uri = data?.data
                binding.profileImage.setImageURI(uri)
                uri = data?.data
                try {
                    if (uri.equals("")) {

                        Toast.makeText(
                            this@VendorRegistrationActivity,
                            "Please Select Profile Image",
                            Toast.LENGTH_SHORT
                        )
                            .show()
                    } else {
                        binding.signUp.isEnabled = true
                    }
                } catch (e: Exception) {

                }


            }
            ImagePicker.RESULT_ERROR -> {
                Toast.makeText(this, ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
            }
            else -> {
                Toast.makeText(this, "Task Cancelled", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun Vendor_regiter() {
        val progress = ProgressDialog(this)
        progress.setMessage("Loading...")
        progress.setCancelable(false)
        progress.show()
        val file = File(uri.path)
        val requestFile = RequestBody.create(MediaType.parse("*/*"), file)
        val profile_img = MultipartBody.Part.createFormData("image", uri.path, requestFile)
        val getDataService: GetDataService =
            RetrofitClintanse.getInstance().create(GetDataService::class.java)
        val call: Call<JsonArray> =
            getDataService.vendor_register(id,
                profile_img,
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.vendorName.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    prefrenceManager?.getmobilno(applicationContext)
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.vendorCity.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    "0"
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    "0"
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.vendorPassword.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.vendorEmail.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    gender
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.vendorAddress.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    binding.vendorPincode.text.toString()
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    "Vendor"
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    "Service Provider"
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    latitude
                ),
                RequestBody.create(
                    MediaType.parse("multipart/form-data"),
                    longitude
                )
            )
        Log.e(
            "vendorregister", binding.vendorName.text.toString() + " "
                    + prefrenceManager?.getmobilno(applicationContext) + " "
                    + binding.vendorCity.text.toString() + " "
                    + " "
                    + binding.vendorPassword.text.toString() + " " +
                    latitude + " " +
                    longitude
        )
        call.enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                Log.e("vendorRegistraiton_res", response.body().toString())
                try {
                    val jsonArray = JSONArray(Gson().toJson(response.body()))
                    Log.e("vendorRagister_response", jsonArray.toString())
                    val jsonObject = jsonArray.getJSONObject(0)
                    val res = jsonObject.getString("status")
                    if (res.equals("success")) {
                        val jsonArray1 = jsonObject.getJSONArray("data")
                        val jsonObject1 = jsonArray1.getJSONObject(0)
                        val status = jsonObject1.getString("status")
                        progress.dismiss()
                        Toast.makeText(
                            applicationContext,
                            "" + jsonObject.getString("message"),
                            Toast.LENGTH_SHORT
                        )
                            .show()
                        if (status == "Deactive") {
                            intent = Intent(applicationContext, SelectuserTypeActivity::class.java)
                            intent.putExtra("address", "vendorre")
                            startActivity(intent)
                            finish()
                        } else {
                            intent = Intent(applicationContext, VendorDashbordActivity::class.java)
                            startActivity(intent)
                            finish()
                        }

                    } else {
                        progress.dismiss()
                        Toast.makeText(
                            applicationContext,
                            "Email Id already exists\nPlease Enter Your Email Id",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                    }

                } catch (e: JSONException) {
                    e.printStackTrace()
                    Log.e("vendorRegister_error", e.toString())
                    progress.dismiss()
                }

            }

            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                Log.e("vendorRegistraiton_eror", t.toString())
                progress.dismiss()
            }

        })

    }

    fun validation(): Boolean {
        if (binding.vendorName.text.toString().trim().isEmpty()) {
            binding.vendorName.error = "Enter The Name"
            binding.vendorName.requestFocus()
        } else if (binding.vendorEmail.text.toString().trim().isEmpty()) {
            binding.vendorEmail.error = "Enter The Email"
            binding.vendorEmail.requestFocus()
        } else if (binding.vendorAddress.text.toString().trim().isEmpty()) {
            binding.vendorAddress.error = "Enter The Address"
            binding.vendorAddress.requestFocus()
        }  else if (binding.vendorPassword.text.toString().trim().isEmpty()) {
            binding.vendorPassword.error = "Enter The Password"
            binding.vendorPassword.requestFocus()
        }  else {
            return true
        }
        return false
    }

    private fun getLastLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        mFusedLocationClient.lastLocation.addOnCompleteListener(this) { task ->
            if (task.isSuccessful && task.result != null) {
                lastLocation = task.result
                Log.e("fdkj", (lastLocation)!!.latitude.toString())
                Log.e("fdkj", (lastLocation)!!.longitude.toString())

                latitude = (lastLocation)!!.latitude.toString()
                longitude = (lastLocation)!!.longitude.toString()

//                preferencesManegar?.setlatitude((lastLocation)!!.latitude.toString(), applicationContext)
//                preferencesManegar?.setlongitude((lastLocation)!!.longitude.toString(), applicationContext)

                val geocoder = Geocoder(this, Locale.getDefault())
                val list: List<Address> =
                    geocoder.getFromLocation(
                        (lastLocation)!!.latitude,
                        (lastLocation)!!.longitude,
                        1
                    )!!
                binding.apply {
                    Log.e("jfks", list[0].getAddressLine(0))

//                    localaddress = address.setText(list[0].getAddressLine(0)).toString()
////                    binding.userAddress.setText(list[0].getAddressLine(0))
//                    binding.pincode.setText(list[0].postalCode)
//                    binding.state.setText(list[0].adminArea)
//                    binding.city.setText(list[0].locality)
//                    binding.userLandmark.setText(list[0].featureName)
                }
            } else {
                Log.w(TAG, "getLastLocation:exception", task.exception)
                //showMessage("No location detected. Make sure location is enabled on the device.")
            }
        }
    }

    private fun showSnackbar(
        mainTextStringId: String, actionStringId: String,
        listener: View.OnClickListener
    ) {
        Toast.makeText(this, mainTextStringId, Toast.LENGTH_LONG).show()
    }

    private fun checkPermissions(): Boolean {
        val permissionState = ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        return permissionState == PackageManager.PERMISSION_GRANTED
    }

    private fun startLocationPermissionRequest() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION),
            REQUEST_PERMISSIONS_REQUEST_CODE
        )
    }

    private fun requestPermissions() {
        val shouldProvideRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (shouldProvideRationale) {
            Log.i(TAG, "Displaying permission rationale to provide additional context.")
            showSnackbar("Location permission is needed for core functionality", "Okay",
                View.OnClickListener {
                    startLocationPermissionRequest()
                })
        } else {
            Log.i(TAG, "Requesting permission")
            startLocationPermissionRequest()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Log.i(TAG, "onRequestPermissionResult")
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            when {
                grantResults.isEmpty() -> {
                    // If user interaction was interrupted, the permission request is cancelled and you
                    // receive empty arrays.
                    Log.i(TAG, "User interaction was cancelled.")
                }
                grantResults[0] == PackageManager.PERMISSION_GRANTED -> {
                    // Permission granted.
                    getLastLocation()
                }
                else -> {
                    showSnackbar("Permission was denied", "Settings",
                        View.OnClickListener {
                            // Build intent that displays the App settings screen.
                            val intent = Intent()
                            intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                            val uri = Uri.fromParts(
                                "package",
                                Build.DISPLAY, null
                            )
                            intent.data = uri
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                        }
                    )
                }
            }
        }
    }
}